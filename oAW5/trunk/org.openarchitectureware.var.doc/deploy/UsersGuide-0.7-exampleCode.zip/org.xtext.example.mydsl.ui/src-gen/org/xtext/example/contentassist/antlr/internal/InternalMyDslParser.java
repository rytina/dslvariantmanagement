package org.xtext.example.contentassist.antlr.internal; 

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.xtext.parsetree.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ui.common.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.xtext.example.services.MyDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class InternalMyDslParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'*'", "'entity'", "'{'", "'}'", "':'", "'featureAndList'", "'('", "')'", "','", "'featureOrList'", "'featureExp'", "'feature'", "'or'", "'and'", "'featuremodel'", "'tags'", "'aspect'", "'name'", "'='", "'startswith'", "'endswith'", "'tag'", "'retain'", "'not'"
    };
    public static final int RULE_ID=4;
    public static final int RULE_STRING=5;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_INT=6;
    public static final int RULE_WS=9;
    public static final int RULE_SL_COMMENT=8;
    public static final int EOF=-1;
    public static final int RULE_ML_COMMENT=7;

        public InternalMyDslParser(TokenStream input) {
            super(input);
        }
        

    public String[] getTokenNames() { return tokenNames; }
    public String getGrammarFileName() { return "../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g"; }


     
     	private MyDslGrammarAccess grammarAccess;
     	
        public void setGrammarAccess(MyDslGrammarAccess grammarAccess) {
        	this.grammarAccess = grammarAccess;
        }
        
        @Override
        protected Grammar getGrammar() {
        	return grammarAccess.getGrammar();
        }




    // $ANTLR start entryRuleSystem
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:55:1: entryRuleSystem : ruleSystem EOF ;
    public final void entryRuleSystem() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:55:17: ( ruleSystem EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:56:1: ruleSystem EOF
            {
             before(grammarAccess.getSystemRule()); 
            pushFollow(FOLLOW_ruleSystem_in_entryRuleSystem60);
            ruleSystem();
            _fsp--;

             after(grammarAccess.getSystemRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleSystem67); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleSystem


    // $ANTLR start ruleSystem
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:63:1: ruleSystem : ( ( rule__System__Group__0 ) ) ;
    public final void ruleSystem() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:67:2: ( ( ( rule__System__Group__0 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:68:1: ( ( rule__System__Group__0 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:68:1: ( ( rule__System__Group__0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:69:1: ( rule__System__Group__0 )
            {
             before(grammarAccess.getSystemAccess().getGroup()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:70:1: ( rule__System__Group__0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:70:2: rule__System__Group__0
            {
            pushFollow(FOLLOW_rule__System__Group__0_in_ruleSystem94);
            rule__System__Group__0();
            _fsp--;


            }

             after(grammarAccess.getSystemAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleSystem


    // $ANTLR start entryRuleEntity
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:82:1: entryRuleEntity : ruleEntity EOF ;
    public final void entryRuleEntity() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:82:17: ( ruleEntity EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:83:1: ruleEntity EOF
            {
             before(grammarAccess.getEntityRule()); 
            pushFollow(FOLLOW_ruleEntity_in_entryRuleEntity120);
            ruleEntity();
            _fsp--;

             after(grammarAccess.getEntityRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleEntity127); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleEntity


    // $ANTLR start ruleEntity
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:90:1: ruleEntity : ( ( rule__Entity__Group__0 ) ) ;
    public final void ruleEntity() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:94:2: ( ( ( rule__Entity__Group__0 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:95:1: ( ( rule__Entity__Group__0 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:95:1: ( ( rule__Entity__Group__0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:96:1: ( rule__Entity__Group__0 )
            {
             before(grammarAccess.getEntityAccess().getGroup()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:97:1: ( rule__Entity__Group__0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:97:2: rule__Entity__Group__0
            {
            pushFollow(FOLLOW_rule__Entity__Group__0_in_ruleEntity154);
            rule__Entity__Group__0();
            _fsp--;


            }

             after(grammarAccess.getEntityAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleEntity


    // $ANTLR start entryRuleAttribute
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:109:1: entryRuleAttribute : ruleAttribute EOF ;
    public final void entryRuleAttribute() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:109:20: ( ruleAttribute EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:110:1: ruleAttribute EOF
            {
             before(grammarAccess.getAttributeRule()); 
            pushFollow(FOLLOW_ruleAttribute_in_entryRuleAttribute180);
            ruleAttribute();
            _fsp--;

             after(grammarAccess.getAttributeRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleAttribute187); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleAttribute


    // $ANTLR start ruleAttribute
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:117:1: ruleAttribute : ( ( rule__Attribute__Group__0 ) ) ;
    public final void ruleAttribute() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:121:2: ( ( ( rule__Attribute__Group__0 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:122:1: ( ( rule__Attribute__Group__0 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:122:1: ( ( rule__Attribute__Group__0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:123:1: ( rule__Attribute__Group__0 )
            {
             before(grammarAccess.getAttributeAccess().getGroup()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:124:1: ( rule__Attribute__Group__0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:124:2: rule__Attribute__Group__0
            {
            pushFollow(FOLLOW_rule__Attribute__Group__0_in_ruleAttribute214);
            rule__Attribute__Group__0();
            _fsp--;


            }

             after(grammarAccess.getAttributeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleAttribute


    // $ANTLR start entryRuleFeatureClause
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:136:1: entryRuleFeatureClause : ruleFeatureClause EOF ;
    public final void entryRuleFeatureClause() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:136:24: ( ruleFeatureClause EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:137:1: ruleFeatureClause EOF
            {
             before(grammarAccess.getFeatureClauseRule()); 
            pushFollow(FOLLOW_ruleFeatureClause_in_entryRuleFeatureClause240);
            ruleFeatureClause();
            _fsp--;

             after(grammarAccess.getFeatureClauseRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeatureClause247); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleFeatureClause


    // $ANTLR start ruleFeatureClause
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:144:1: ruleFeatureClause : ( ( rule__FeatureClause__Alternatives ) ) ;
    public final void ruleFeatureClause() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:148:2: ( ( ( rule__FeatureClause__Alternatives ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:149:1: ( ( rule__FeatureClause__Alternatives ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:149:1: ( ( rule__FeatureClause__Alternatives ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:150:1: ( rule__FeatureClause__Alternatives )
            {
             before(grammarAccess.getFeatureClauseAccess().getAlternatives()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:151:1: ( rule__FeatureClause__Alternatives )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:151:2: rule__FeatureClause__Alternatives
            {
            pushFollow(FOLLOW_rule__FeatureClause__Alternatives_in_ruleFeatureClause274);
            rule__FeatureClause__Alternatives();
            _fsp--;


            }

             after(grammarAccess.getFeatureClauseAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleFeatureClause


    // $ANTLR start entryRuleFeatureAndList
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:163:1: entryRuleFeatureAndList : ruleFeatureAndList EOF ;
    public final void entryRuleFeatureAndList() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:163:25: ( ruleFeatureAndList EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:164:1: ruleFeatureAndList EOF
            {
             before(grammarAccess.getFeatureAndListRule()); 
            pushFollow(FOLLOW_ruleFeatureAndList_in_entryRuleFeatureAndList300);
            ruleFeatureAndList();
            _fsp--;

             after(grammarAccess.getFeatureAndListRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeatureAndList307); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleFeatureAndList


    // $ANTLR start ruleFeatureAndList
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:171:1: ruleFeatureAndList : ( ( rule__FeatureAndList__Group__0 ) ) ;
    public final void ruleFeatureAndList() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:175:2: ( ( ( rule__FeatureAndList__Group__0 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:176:1: ( ( rule__FeatureAndList__Group__0 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:176:1: ( ( rule__FeatureAndList__Group__0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:177:1: ( rule__FeatureAndList__Group__0 )
            {
             before(grammarAccess.getFeatureAndListAccess().getGroup()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:178:1: ( rule__FeatureAndList__Group__0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:178:2: rule__FeatureAndList__Group__0
            {
            pushFollow(FOLLOW_rule__FeatureAndList__Group__0_in_ruleFeatureAndList334);
            rule__FeatureAndList__Group__0();
            _fsp--;


            }

             after(grammarAccess.getFeatureAndListAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleFeatureAndList


    // $ANTLR start entryRuleFeatureOrList
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:190:1: entryRuleFeatureOrList : ruleFeatureOrList EOF ;
    public final void entryRuleFeatureOrList() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:190:24: ( ruleFeatureOrList EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:191:1: ruleFeatureOrList EOF
            {
             before(grammarAccess.getFeatureOrListRule()); 
            pushFollow(FOLLOW_ruleFeatureOrList_in_entryRuleFeatureOrList360);
            ruleFeatureOrList();
            _fsp--;

             after(grammarAccess.getFeatureOrListRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeatureOrList367); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleFeatureOrList


    // $ANTLR start ruleFeatureOrList
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:198:1: ruleFeatureOrList : ( ( rule__FeatureOrList__Group__0 ) ) ;
    public final void ruleFeatureOrList() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:202:2: ( ( ( rule__FeatureOrList__Group__0 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:203:1: ( ( rule__FeatureOrList__Group__0 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:203:1: ( ( rule__FeatureOrList__Group__0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:204:1: ( rule__FeatureOrList__Group__0 )
            {
             before(grammarAccess.getFeatureOrListAccess().getGroup()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:205:1: ( rule__FeatureOrList__Group__0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:205:2: rule__FeatureOrList__Group__0
            {
            pushFollow(FOLLOW_rule__FeatureOrList__Group__0_in_ruleFeatureOrList394);
            rule__FeatureOrList__Group__0();
            _fsp--;


            }

             after(grammarAccess.getFeatureOrListAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleFeatureOrList


    // $ANTLR start entryRuleFeatureExpression
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:217:1: entryRuleFeatureExpression : ruleFeatureExpression EOF ;
    public final void entryRuleFeatureExpression() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:217:28: ( ruleFeatureExpression EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:218:1: ruleFeatureExpression EOF
            {
             before(grammarAccess.getFeatureExpressionRule()); 
            pushFollow(FOLLOW_ruleFeatureExpression_in_entryRuleFeatureExpression420);
            ruleFeatureExpression();
            _fsp--;

             after(grammarAccess.getFeatureExpressionRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeatureExpression427); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleFeatureExpression


    // $ANTLR start ruleFeatureExpression
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:225:1: ruleFeatureExpression : ( ( rule__FeatureExpression__Group__0 ) ) ;
    public final void ruleFeatureExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:229:2: ( ( ( rule__FeatureExpression__Group__0 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:230:1: ( ( rule__FeatureExpression__Group__0 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:230:1: ( ( rule__FeatureExpression__Group__0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:231:1: ( rule__FeatureExpression__Group__0 )
            {
             before(grammarAccess.getFeatureExpressionAccess().getGroup()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:232:1: ( rule__FeatureExpression__Group__0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:232:2: rule__FeatureExpression__Group__0
            {
            pushFollow(FOLLOW_rule__FeatureExpression__Group__0_in_ruleFeatureExpression454);
            rule__FeatureExpression__Group__0();
            _fsp--;


            }

             after(grammarAccess.getFeatureExpressionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleFeatureExpression


    // $ANTLR start entryRuleFeature
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:244:1: entryRuleFeature : ruleFeature EOF ;
    public final void entryRuleFeature() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:244:18: ( ruleFeature EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:245:1: ruleFeature EOF
            {
             before(grammarAccess.getFeatureRule()); 
            pushFollow(FOLLOW_ruleFeature_in_entryRuleFeature480);
            ruleFeature();
            _fsp--;

             after(grammarAccess.getFeatureRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeature487); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleFeature


    // $ANTLR start ruleFeature
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:252:1: ruleFeature : ( ( rule__Feature__Group__0 ) ) ;
    public final void ruleFeature() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:256:2: ( ( ( rule__Feature__Group__0 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:257:1: ( ( rule__Feature__Group__0 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:257:1: ( ( rule__Feature__Group__0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:258:1: ( rule__Feature__Group__0 )
            {
             before(grammarAccess.getFeatureAccess().getGroup()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:259:1: ( rule__Feature__Group__0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:259:2: rule__Feature__Group__0
            {
            pushFollow(FOLLOW_rule__Feature__Group__0_in_ruleFeature514);
            rule__Feature__Group__0();
            _fsp--;


            }

             after(grammarAccess.getFeatureAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleFeature


    // $ANTLR start entryRuleOrExpression
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:271:1: entryRuleOrExpression : ruleOrExpression EOF ;
    public final void entryRuleOrExpression() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:271:23: ( ruleOrExpression EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:272:1: ruleOrExpression EOF
            {
             before(grammarAccess.getOrExpressionRule()); 
            pushFollow(FOLLOW_ruleOrExpression_in_entryRuleOrExpression540);
            ruleOrExpression();
            _fsp--;

             after(grammarAccess.getOrExpressionRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleOrExpression547); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleOrExpression


    // $ANTLR start ruleOrExpression
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:279:1: ruleOrExpression : ( ( rule__OrExpression__Group__0 ) ) ;
    public final void ruleOrExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:283:2: ( ( ( rule__OrExpression__Group__0 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:284:1: ( ( rule__OrExpression__Group__0 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:284:1: ( ( rule__OrExpression__Group__0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:285:1: ( rule__OrExpression__Group__0 )
            {
             before(grammarAccess.getOrExpressionAccess().getGroup()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:286:1: ( rule__OrExpression__Group__0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:286:2: rule__OrExpression__Group__0
            {
            pushFollow(FOLLOW_rule__OrExpression__Group__0_in_ruleOrExpression574);
            rule__OrExpression__Group__0();
            _fsp--;


            }

             after(grammarAccess.getOrExpressionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleOrExpression


    // $ANTLR start entryRuleAndExpression
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:298:1: entryRuleAndExpression : ruleAndExpression EOF ;
    public final void entryRuleAndExpression() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:298:24: ( ruleAndExpression EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:299:1: ruleAndExpression EOF
            {
             before(grammarAccess.getAndExpressionRule()); 
            pushFollow(FOLLOW_ruleAndExpression_in_entryRuleAndExpression600);
            ruleAndExpression();
            _fsp--;

             after(grammarAccess.getAndExpressionRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleAndExpression607); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleAndExpression


    // $ANTLR start ruleAndExpression
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:306:1: ruleAndExpression : ( ( rule__AndExpression__Group__0 ) ) ;
    public final void ruleAndExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:310:2: ( ( ( rule__AndExpression__Group__0 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:311:1: ( ( rule__AndExpression__Group__0 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:311:1: ( ( rule__AndExpression__Group__0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:312:1: ( rule__AndExpression__Group__0 )
            {
             before(grammarAccess.getAndExpressionAccess().getGroup()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:313:1: ( rule__AndExpression__Group__0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:313:2: rule__AndExpression__Group__0
            {
            pushFollow(FOLLOW_rule__AndExpression__Group__0_in_ruleAndExpression634);
            rule__AndExpression__Group__0();
            _fsp--;


            }

             after(grammarAccess.getAndExpressionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleAndExpression


    // $ANTLR start entryRuleOperand
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:325:1: entryRuleOperand : ruleOperand EOF ;
    public final void entryRuleOperand() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:325:18: ( ruleOperand EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:326:1: ruleOperand EOF
            {
             before(grammarAccess.getOperandRule()); 
            pushFollow(FOLLOW_ruleOperand_in_entryRuleOperand660);
            ruleOperand();
            _fsp--;

             after(grammarAccess.getOperandRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleOperand667); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleOperand


    // $ANTLR start ruleOperand
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:333:1: ruleOperand : ( ( rule__Operand__Group__0 ) ) ;
    public final void ruleOperand() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:337:2: ( ( ( rule__Operand__Group__0 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:338:1: ( ( rule__Operand__Group__0 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:338:1: ( ( rule__Operand__Group__0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:339:1: ( rule__Operand__Group__0 )
            {
             before(grammarAccess.getOperandAccess().getGroup()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:340:1: ( rule__Operand__Group__0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:340:2: rule__Operand__Group__0
            {
            pushFollow(FOLLOW_rule__Operand__Group__0_in_ruleOperand694);
            rule__Operand__Group__0();
            _fsp--;


            }

             after(grammarAccess.getOperandAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleOperand


    // $ANTLR start entryRuleAtom
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:352:1: entryRuleAtom : ruleAtom EOF ;
    public final void entryRuleAtom() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:352:15: ( ruleAtom EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:353:1: ruleAtom EOF
            {
             before(grammarAccess.getAtomRule()); 
            pushFollow(FOLLOW_ruleAtom_in_entryRuleAtom720);
            ruleAtom();
            _fsp--;

             after(grammarAccess.getAtomRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleAtom727); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleAtom


    // $ANTLR start ruleAtom
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:360:1: ruleAtom : ( ( rule__Atom__Alternatives ) ) ;
    public final void ruleAtom() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:364:2: ( ( ( rule__Atom__Alternatives ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:365:1: ( ( rule__Atom__Alternatives ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:365:1: ( ( rule__Atom__Alternatives ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:366:1: ( rule__Atom__Alternatives )
            {
             before(grammarAccess.getAtomAccess().getAlternatives()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:367:1: ( rule__Atom__Alternatives )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:367:2: rule__Atom__Alternatives
            {
            pushFollow(FOLLOW_rule__Atom__Alternatives_in_ruleAtom754);
            rule__Atom__Alternatives();
            _fsp--;


            }

             after(grammarAccess.getAtomAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleAtom


    // $ANTLR start entryRuleFeatureModelImport
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:379:1: entryRuleFeatureModelImport : ruleFeatureModelImport EOF ;
    public final void entryRuleFeatureModelImport() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:379:29: ( ruleFeatureModelImport EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:380:1: ruleFeatureModelImport EOF
            {
             before(grammarAccess.getFeatureModelImportRule()); 
            pushFollow(FOLLOW_ruleFeatureModelImport_in_entryRuleFeatureModelImport780);
            ruleFeatureModelImport();
            _fsp--;

             after(grammarAccess.getFeatureModelImportRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeatureModelImport787); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleFeatureModelImport


    // $ANTLR start ruleFeatureModelImport
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:387:1: ruleFeatureModelImport : ( ( rule__FeatureModelImport__Group__0 ) ) ;
    public final void ruleFeatureModelImport() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:391:2: ( ( ( rule__FeatureModelImport__Group__0 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:392:1: ( ( rule__FeatureModelImport__Group__0 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:392:1: ( ( rule__FeatureModelImport__Group__0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:393:1: ( rule__FeatureModelImport__Group__0 )
            {
             before(grammarAccess.getFeatureModelImportAccess().getGroup()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:394:1: ( rule__FeatureModelImport__Group__0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:394:2: rule__FeatureModelImport__Group__0
            {
            pushFollow(FOLLOW_rule__FeatureModelImport__Group__0_in_ruleFeatureModelImport814);
            rule__FeatureModelImport__Group__0();
            _fsp--;


            }

             after(grammarAccess.getFeatureModelImportAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleFeatureModelImport


    // $ANTLR start entryRuleTagsClause
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:406:1: entryRuleTagsClause : ruleTagsClause EOF ;
    public final void entryRuleTagsClause() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:406:21: ( ruleTagsClause EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:407:1: ruleTagsClause EOF
            {
             before(grammarAccess.getTagsClauseRule()); 
            pushFollow(FOLLOW_ruleTagsClause_in_entryRuleTagsClause840);
            ruleTagsClause();
            _fsp--;

             after(grammarAccess.getTagsClauseRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleTagsClause847); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleTagsClause


    // $ANTLR start ruleTagsClause
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:414:1: ruleTagsClause : ( ( rule__TagsClause__Group__0 ) ) ;
    public final void ruleTagsClause() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:418:2: ( ( ( rule__TagsClause__Group__0 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:419:1: ( ( rule__TagsClause__Group__0 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:419:1: ( ( rule__TagsClause__Group__0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:420:1: ( rule__TagsClause__Group__0 )
            {
             before(grammarAccess.getTagsClauseAccess().getGroup()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:421:1: ( rule__TagsClause__Group__0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:421:2: rule__TagsClause__Group__0
            {
            pushFollow(FOLLOW_rule__TagsClause__Group__0_in_ruleTagsClause874);
            rule__TagsClause__Group__0();
            _fsp--;


            }

             after(grammarAccess.getTagsClauseAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleTagsClause


    // $ANTLR start entryRuleTag
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:433:1: entryRuleTag : ruleTag EOF ;
    public final void entryRuleTag() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:433:14: ( ruleTag EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:434:1: ruleTag EOF
            {
             before(grammarAccess.getTagRule()); 
            pushFollow(FOLLOW_ruleTag_in_entryRuleTag900);
            ruleTag();
            _fsp--;

             after(grammarAccess.getTagRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleTag907); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleTag


    // $ANTLR start ruleTag
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:441:1: ruleTag : ( ( rule__Tag__NameAssignment ) ) ;
    public final void ruleTag() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:445:2: ( ( ( rule__Tag__NameAssignment ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:446:1: ( ( rule__Tag__NameAssignment ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:446:1: ( ( rule__Tag__NameAssignment ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:447:1: ( rule__Tag__NameAssignment )
            {
             before(grammarAccess.getTagAccess().getNameAssignment()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:448:1: ( rule__Tag__NameAssignment )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:448:2: rule__Tag__NameAssignment
            {
            pushFollow(FOLLOW_rule__Tag__NameAssignment_in_ruleTag934);
            rule__Tag__NameAssignment();
            _fsp--;


            }

             after(grammarAccess.getTagAccess().getNameAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleTag


    // $ANTLR start entryRulePointcut
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:460:1: entryRulePointcut : rulePointcut EOF ;
    public final void entryRulePointcut() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:460:19: ( rulePointcut EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:461:1: rulePointcut EOF
            {
             before(grammarAccess.getPointcutRule()); 
            pushFollow(FOLLOW_rulePointcut_in_entryRulePointcut960);
            rulePointcut();
            _fsp--;

             after(grammarAccess.getPointcutRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRulePointcut967); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRulePointcut


    // $ANTLR start rulePointcut
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:468:1: rulePointcut : ( ( rule__Pointcut__Group__0 ) ) ;
    public final void rulePointcut() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:472:2: ( ( ( rule__Pointcut__Group__0 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:473:1: ( ( rule__Pointcut__Group__0 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:473:1: ( ( rule__Pointcut__Group__0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:474:1: ( rule__Pointcut__Group__0 )
            {
             before(grammarAccess.getPointcutAccess().getGroup()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:475:1: ( rule__Pointcut__Group__0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:475:2: rule__Pointcut__Group__0
            {
            pushFollow(FOLLOW_rule__Pointcut__Group__0_in_rulePointcut994);
            rule__Pointcut__Group__0();
            _fsp--;


            }

             after(grammarAccess.getPointcutAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rulePointcut


    // $ANTLR start entryRuleMatch
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:487:1: entryRuleMatch : ruleMatch EOF ;
    public final void entryRuleMatch() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:487:16: ( ruleMatch EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:488:1: ruleMatch EOF
            {
             before(grammarAccess.getMatchRule()); 
            pushFollow(FOLLOW_ruleMatch_in_entryRuleMatch1020);
            ruleMatch();
            _fsp--;

             after(grammarAccess.getMatchRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleMatch1027); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleMatch


    // $ANTLR start ruleMatch
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:495:1: ruleMatch : ( ( rule__Match__Alternatives ) ) ;
    public final void ruleMatch() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:499:2: ( ( ( rule__Match__Alternatives ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:500:1: ( ( rule__Match__Alternatives ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:500:1: ( ( rule__Match__Alternatives ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:501:1: ( rule__Match__Alternatives )
            {
             before(grammarAccess.getMatchAccess().getAlternatives()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:502:1: ( rule__Match__Alternatives )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:502:2: rule__Match__Alternatives
            {
            pushFollow(FOLLOW_rule__Match__Alternatives_in_ruleMatch1054);
            rule__Match__Alternatives();
            _fsp--;


            }

             after(grammarAccess.getMatchAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleMatch


    // $ANTLR start entryRuleAllMatch
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:514:1: entryRuleAllMatch : ruleAllMatch EOF ;
    public final void entryRuleAllMatch() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:514:19: ( ruleAllMatch EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:515:1: ruleAllMatch EOF
            {
             before(grammarAccess.getAllMatchRule()); 
            pushFollow(FOLLOW_ruleAllMatch_in_entryRuleAllMatch1080);
            ruleAllMatch();
            _fsp--;

             after(grammarAccess.getAllMatchRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleAllMatch1087); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleAllMatch


    // $ANTLR start ruleAllMatch
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:522:1: ruleAllMatch : ( '*' ) ;
    public final void ruleAllMatch() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:526:2: ( ( '*' ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:527:1: ( '*' )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:527:1: ( '*' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:528:1: '*'
            {
             before(grammarAccess.getAllMatchAccess().getAsteriskKeyword()); 
            match(input,11,FOLLOW_11_in_ruleAllMatch1115); 
             after(grammarAccess.getAllMatchAccess().getAsteriskKeyword()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleAllMatch


    // $ANTLR start entryRuleExactNameMatch
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:543:1: entryRuleExactNameMatch : ruleExactNameMatch EOF ;
    public final void entryRuleExactNameMatch() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:543:25: ( ruleExactNameMatch EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:544:1: ruleExactNameMatch EOF
            {
             before(grammarAccess.getExactNameMatchRule()); 
            pushFollow(FOLLOW_ruleExactNameMatch_in_entryRuleExactNameMatch1142);
            ruleExactNameMatch();
            _fsp--;

             after(grammarAccess.getExactNameMatchRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleExactNameMatch1149); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleExactNameMatch


    // $ANTLR start ruleExactNameMatch
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:551:1: ruleExactNameMatch : ( ( rule__ExactNameMatch__Group__0 ) ) ;
    public final void ruleExactNameMatch() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:555:2: ( ( ( rule__ExactNameMatch__Group__0 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:556:1: ( ( rule__ExactNameMatch__Group__0 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:556:1: ( ( rule__ExactNameMatch__Group__0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:557:1: ( rule__ExactNameMatch__Group__0 )
            {
             before(grammarAccess.getExactNameMatchAccess().getGroup()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:558:1: ( rule__ExactNameMatch__Group__0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:558:2: rule__ExactNameMatch__Group__0
            {
            pushFollow(FOLLOW_rule__ExactNameMatch__Group__0_in_ruleExactNameMatch1176);
            rule__ExactNameMatch__Group__0();
            _fsp--;


            }

             after(grammarAccess.getExactNameMatchAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleExactNameMatch


    // $ANTLR start entryRuleStartsWithNameMatch
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:570:1: entryRuleStartsWithNameMatch : ruleStartsWithNameMatch EOF ;
    public final void entryRuleStartsWithNameMatch() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:570:30: ( ruleStartsWithNameMatch EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:571:1: ruleStartsWithNameMatch EOF
            {
             before(grammarAccess.getStartsWithNameMatchRule()); 
            pushFollow(FOLLOW_ruleStartsWithNameMatch_in_entryRuleStartsWithNameMatch1202);
            ruleStartsWithNameMatch();
            _fsp--;

             after(grammarAccess.getStartsWithNameMatchRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleStartsWithNameMatch1209); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleStartsWithNameMatch


    // $ANTLR start ruleStartsWithNameMatch
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:578:1: ruleStartsWithNameMatch : ( ( rule__StartsWithNameMatch__Group__0 ) ) ;
    public final void ruleStartsWithNameMatch() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:582:2: ( ( ( rule__StartsWithNameMatch__Group__0 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:583:1: ( ( rule__StartsWithNameMatch__Group__0 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:583:1: ( ( rule__StartsWithNameMatch__Group__0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:584:1: ( rule__StartsWithNameMatch__Group__0 )
            {
             before(grammarAccess.getStartsWithNameMatchAccess().getGroup()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:585:1: ( rule__StartsWithNameMatch__Group__0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:585:2: rule__StartsWithNameMatch__Group__0
            {
            pushFollow(FOLLOW_rule__StartsWithNameMatch__Group__0_in_ruleStartsWithNameMatch1236);
            rule__StartsWithNameMatch__Group__0();
            _fsp--;


            }

             after(grammarAccess.getStartsWithNameMatchAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleStartsWithNameMatch


    // $ANTLR start entryRuleEndsWithNameMatch
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:597:1: entryRuleEndsWithNameMatch : ruleEndsWithNameMatch EOF ;
    public final void entryRuleEndsWithNameMatch() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:597:28: ( ruleEndsWithNameMatch EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:598:1: ruleEndsWithNameMatch EOF
            {
             before(grammarAccess.getEndsWithNameMatchRule()); 
            pushFollow(FOLLOW_ruleEndsWithNameMatch_in_entryRuleEndsWithNameMatch1262);
            ruleEndsWithNameMatch();
            _fsp--;

             after(grammarAccess.getEndsWithNameMatchRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleEndsWithNameMatch1269); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleEndsWithNameMatch


    // $ANTLR start ruleEndsWithNameMatch
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:605:1: ruleEndsWithNameMatch : ( ( rule__EndsWithNameMatch__Group__0 ) ) ;
    public final void ruleEndsWithNameMatch() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:609:2: ( ( ( rule__EndsWithNameMatch__Group__0 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:610:1: ( ( rule__EndsWithNameMatch__Group__0 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:610:1: ( ( rule__EndsWithNameMatch__Group__0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:611:1: ( rule__EndsWithNameMatch__Group__0 )
            {
             before(grammarAccess.getEndsWithNameMatchAccess().getGroup()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:612:1: ( rule__EndsWithNameMatch__Group__0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:612:2: rule__EndsWithNameMatch__Group__0
            {
            pushFollow(FOLLOW_rule__EndsWithNameMatch__Group__0_in_ruleEndsWithNameMatch1296);
            rule__EndsWithNameMatch__Group__0();
            _fsp--;


            }

             after(grammarAccess.getEndsWithNameMatchAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleEndsWithNameMatch


    // $ANTLR start entryRuleTagMatch
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:624:1: entryRuleTagMatch : ruleTagMatch EOF ;
    public final void entryRuleTagMatch() throws RecognitionException {
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:624:19: ( ruleTagMatch EOF )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:625:1: ruleTagMatch EOF
            {
             before(grammarAccess.getTagMatchRule()); 
            pushFollow(FOLLOW_ruleTagMatch_in_entryRuleTagMatch1322);
            ruleTagMatch();
            _fsp--;

             after(grammarAccess.getTagMatchRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleTagMatch1329); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end entryRuleTagMatch


    // $ANTLR start ruleTagMatch
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:632:1: ruleTagMatch : ( ( rule__TagMatch__Group__0 ) ) ;
    public final void ruleTagMatch() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:636:2: ( ( ( rule__TagMatch__Group__0 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:637:1: ( ( rule__TagMatch__Group__0 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:637:1: ( ( rule__TagMatch__Group__0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:638:1: ( rule__TagMatch__Group__0 )
            {
             before(grammarAccess.getTagMatchAccess().getGroup()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:639:1: ( rule__TagMatch__Group__0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:639:2: rule__TagMatch__Group__0
            {
            pushFollow(FOLLOW_rule__TagMatch__Group__0_in_ruleTagMatch1356);
            rule__TagMatch__Group__0();
            _fsp--;


            }

             after(grammarAccess.getTagMatchAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end ruleTagMatch


    // $ANTLR start rule__FeatureClause__Alternatives
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:651:1: rule__FeatureClause__Alternatives : ( ( ruleFeatureAndList ) | ( ruleFeatureOrList ) | ( ruleFeatureExpression ) | ( ruleFeature ) );
    public final void rule__FeatureClause__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:655:1: ( ( ruleFeatureAndList ) | ( ruleFeatureOrList ) | ( ruleFeatureExpression ) | ( ruleFeature ) )
            int alt1=4;
            switch ( input.LA(1) ) {
            case 16:
                {
                alt1=1;
                }
                break;
            case 20:
                {
                alt1=2;
                }
                break;
            case 21:
                {
                alt1=3;
                }
                break;
            case 22:
                {
                alt1=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("651:1: rule__FeatureClause__Alternatives : ( ( ruleFeatureAndList ) | ( ruleFeatureOrList ) | ( ruleFeatureExpression ) | ( ruleFeature ) );", 1, 0, input);

                throw nvae;
            }

            switch (alt1) {
                case 1 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:656:1: ( ruleFeatureAndList )
                    {
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:656:1: ( ruleFeatureAndList )
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:657:1: ruleFeatureAndList
                    {
                     before(grammarAccess.getFeatureClauseAccess().getFeatureAndListParserRuleCall_0()); 
                    pushFollow(FOLLOW_ruleFeatureAndList_in_rule__FeatureClause__Alternatives1392);
                    ruleFeatureAndList();
                    _fsp--;

                     after(grammarAccess.getFeatureClauseAccess().getFeatureAndListParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:662:6: ( ruleFeatureOrList )
                    {
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:662:6: ( ruleFeatureOrList )
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:663:1: ruleFeatureOrList
                    {
                     before(grammarAccess.getFeatureClauseAccess().getFeatureOrListParserRuleCall_1()); 
                    pushFollow(FOLLOW_ruleFeatureOrList_in_rule__FeatureClause__Alternatives1409);
                    ruleFeatureOrList();
                    _fsp--;

                     after(grammarAccess.getFeatureClauseAccess().getFeatureOrListParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:668:6: ( ruleFeatureExpression )
                    {
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:668:6: ( ruleFeatureExpression )
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:669:1: ruleFeatureExpression
                    {
                     before(grammarAccess.getFeatureClauseAccess().getFeatureExpressionParserRuleCall_2()); 
                    pushFollow(FOLLOW_ruleFeatureExpression_in_rule__FeatureClause__Alternatives1426);
                    ruleFeatureExpression();
                    _fsp--;

                     after(grammarAccess.getFeatureClauseAccess().getFeatureExpressionParserRuleCall_2()); 

                    }


                    }
                    break;
                case 4 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:674:6: ( ruleFeature )
                    {
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:674:6: ( ruleFeature )
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:675:1: ruleFeature
                    {
                     before(grammarAccess.getFeatureClauseAccess().getFeatureParserRuleCall_3()); 
                    pushFollow(FOLLOW_ruleFeature_in_rule__FeatureClause__Alternatives1443);
                    ruleFeature();
                    _fsp--;

                     after(grammarAccess.getFeatureClauseAccess().getFeatureParserRuleCall_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureClause__Alternatives


    // $ANTLR start rule__Atom__Alternatives
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:685:1: rule__Atom__Alternatives : ( ( ( rule__Atom__FeatureAssignment_0 ) ) | ( ( rule__Atom__Group_1__0 ) ) );
    public final void rule__Atom__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:689:1: ( ( ( rule__Atom__FeatureAssignment_0 ) ) | ( ( rule__Atom__Group_1__0 ) ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==RULE_ID) ) {
                alt2=1;
            }
            else if ( (LA2_0==17) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("685:1: rule__Atom__Alternatives : ( ( ( rule__Atom__FeatureAssignment_0 ) ) | ( ( rule__Atom__Group_1__0 ) ) );", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:690:1: ( ( rule__Atom__FeatureAssignment_0 ) )
                    {
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:690:1: ( ( rule__Atom__FeatureAssignment_0 ) )
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:691:1: ( rule__Atom__FeatureAssignment_0 )
                    {
                     before(grammarAccess.getAtomAccess().getFeatureAssignment_0()); 
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:692:1: ( rule__Atom__FeatureAssignment_0 )
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:692:2: rule__Atom__FeatureAssignment_0
                    {
                    pushFollow(FOLLOW_rule__Atom__FeatureAssignment_0_in_rule__Atom__Alternatives1475);
                    rule__Atom__FeatureAssignment_0();
                    _fsp--;


                    }

                     after(grammarAccess.getAtomAccess().getFeatureAssignment_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:696:6: ( ( rule__Atom__Group_1__0 ) )
                    {
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:696:6: ( ( rule__Atom__Group_1__0 ) )
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:697:1: ( rule__Atom__Group_1__0 )
                    {
                     before(grammarAccess.getAtomAccess().getGroup_1()); 
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:698:1: ( rule__Atom__Group_1__0 )
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:698:2: rule__Atom__Group_1__0
                    {
                    pushFollow(FOLLOW_rule__Atom__Group_1__0_in_rule__Atom__Alternatives1493);
                    rule__Atom__Group_1__0();
                    _fsp--;


                    }

                     after(grammarAccess.getAtomAccess().getGroup_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Atom__Alternatives


    // $ANTLR start rule__Match__Alternatives
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:707:1: rule__Match__Alternatives : ( ( ruleAllMatch ) | ( ruleExactNameMatch ) | ( ruleStartsWithNameMatch ) | ( ruleEndsWithNameMatch ) | ( ruleTagMatch ) );
    public final void rule__Match__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:711:1: ( ( ruleAllMatch ) | ( ruleExactNameMatch ) | ( ruleStartsWithNameMatch ) | ( ruleEndsWithNameMatch ) | ( ruleTagMatch ) )
            int alt3=5;
            switch ( input.LA(1) ) {
            case 11:
                {
                alt3=1;
                }
                break;
            case 28:
                {
                switch ( input.LA(2) ) {
                case 31:
                    {
                    alt3=4;
                    }
                    break;
                case 29:
                    {
                    alt3=2;
                    }
                    break;
                case 30:
                    {
                    alt3=3;
                    }
                    break;
                default:
                    NoViableAltException nvae =
                        new NoViableAltException("707:1: rule__Match__Alternatives : ( ( ruleAllMatch ) | ( ruleExactNameMatch ) | ( ruleStartsWithNameMatch ) | ( ruleEndsWithNameMatch ) | ( ruleTagMatch ) );", 3, 2, input);

                    throw nvae;
                }

                }
                break;
            case 32:
                {
                alt3=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("707:1: rule__Match__Alternatives : ( ( ruleAllMatch ) | ( ruleExactNameMatch ) | ( ruleStartsWithNameMatch ) | ( ruleEndsWithNameMatch ) | ( ruleTagMatch ) );", 3, 0, input);

                throw nvae;
            }

            switch (alt3) {
                case 1 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:712:1: ( ruleAllMatch )
                    {
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:712:1: ( ruleAllMatch )
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:713:1: ruleAllMatch
                    {
                     before(grammarAccess.getMatchAccess().getAllMatchParserRuleCall_0()); 
                    pushFollow(FOLLOW_ruleAllMatch_in_rule__Match__Alternatives1526);
                    ruleAllMatch();
                    _fsp--;

                     after(grammarAccess.getMatchAccess().getAllMatchParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:718:6: ( ruleExactNameMatch )
                    {
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:718:6: ( ruleExactNameMatch )
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:719:1: ruleExactNameMatch
                    {
                     before(grammarAccess.getMatchAccess().getExactNameMatchParserRuleCall_1()); 
                    pushFollow(FOLLOW_ruleExactNameMatch_in_rule__Match__Alternatives1543);
                    ruleExactNameMatch();
                    _fsp--;

                     after(grammarAccess.getMatchAccess().getExactNameMatchParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:724:6: ( ruleStartsWithNameMatch )
                    {
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:724:6: ( ruleStartsWithNameMatch )
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:725:1: ruleStartsWithNameMatch
                    {
                     before(grammarAccess.getMatchAccess().getStartsWithNameMatchParserRuleCall_2()); 
                    pushFollow(FOLLOW_ruleStartsWithNameMatch_in_rule__Match__Alternatives1560);
                    ruleStartsWithNameMatch();
                    _fsp--;

                     after(grammarAccess.getMatchAccess().getStartsWithNameMatchParserRuleCall_2()); 

                    }


                    }
                    break;
                case 4 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:730:6: ( ruleEndsWithNameMatch )
                    {
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:730:6: ( ruleEndsWithNameMatch )
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:731:1: ruleEndsWithNameMatch
                    {
                     before(grammarAccess.getMatchAccess().getEndsWithNameMatchParserRuleCall_3()); 
                    pushFollow(FOLLOW_ruleEndsWithNameMatch_in_rule__Match__Alternatives1577);
                    ruleEndsWithNameMatch();
                    _fsp--;

                     after(grammarAccess.getMatchAccess().getEndsWithNameMatchParserRuleCall_3()); 

                    }


                    }
                    break;
                case 5 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:736:6: ( ruleTagMatch )
                    {
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:736:6: ( ruleTagMatch )
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:737:1: ruleTagMatch
                    {
                     before(grammarAccess.getMatchAccess().getTagMatchParserRuleCall_4()); 
                    pushFollow(FOLLOW_ruleTagMatch_in_rule__Match__Alternatives1594);
                    ruleTagMatch();
                    _fsp--;

                     after(grammarAccess.getMatchAccess().getTagMatchParserRuleCall_4()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Match__Alternatives


    // $ANTLR start rule__System__Group__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:749:1: rule__System__Group__0 : ( ( rule__System__FeatureModelAssignment_0 )? ) rule__System__Group__1 ;
    public final void rule__System__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:753:1: ( ( ( rule__System__FeatureModelAssignment_0 )? ) rule__System__Group__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:754:1: ( ( rule__System__FeatureModelAssignment_0 )? ) rule__System__Group__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:754:1: ( ( rule__System__FeatureModelAssignment_0 )? )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:755:1: ( rule__System__FeatureModelAssignment_0 )?
            {
             before(grammarAccess.getSystemAccess().getFeatureModelAssignment_0()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:756:1: ( rule__System__FeatureModelAssignment_0 )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==25) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:756:2: rule__System__FeatureModelAssignment_0
                    {
                    pushFollow(FOLLOW_rule__System__FeatureModelAssignment_0_in_rule__System__Group__01628);
                    rule__System__FeatureModelAssignment_0();
                    _fsp--;


                    }
                    break;

            }

             after(grammarAccess.getSystemAccess().getFeatureModelAssignment_0()); 

            }

            pushFollow(FOLLOW_rule__System__Group__1_in_rule__System__Group__01638);
            rule__System__Group__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__System__Group__0


    // $ANTLR start rule__System__Group__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:767:1: rule__System__Group__1 : ( ( rule__System__EntitiesAssignment_1 )* ) ;
    public final void rule__System__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:771:1: ( ( ( rule__System__EntitiesAssignment_1 )* ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:772:1: ( ( rule__System__EntitiesAssignment_1 )* )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:772:1: ( ( rule__System__EntitiesAssignment_1 )* )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:773:1: ( rule__System__EntitiesAssignment_1 )*
            {
             before(grammarAccess.getSystemAccess().getEntitiesAssignment_1()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:774:1: ( rule__System__EntitiesAssignment_1 )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==12||LA5_0==27) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:774:2: rule__System__EntitiesAssignment_1
            	    {
            	    pushFollow(FOLLOW_rule__System__EntitiesAssignment_1_in_rule__System__Group__11666);
            	    rule__System__EntitiesAssignment_1();
            	    _fsp--;


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

             after(grammarAccess.getSystemAccess().getEntitiesAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__System__Group__1


    // $ANTLR start rule__Entity__Group__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:788:1: rule__Entity__Group__0 : ( ( rule__Entity__PointcutAssignment_0 )? ) rule__Entity__Group__1 ;
    public final void rule__Entity__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:792:1: ( ( ( rule__Entity__PointcutAssignment_0 )? ) rule__Entity__Group__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:793:1: ( ( rule__Entity__PointcutAssignment_0 )? ) rule__Entity__Group__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:793:1: ( ( rule__Entity__PointcutAssignment_0 )? )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:794:1: ( rule__Entity__PointcutAssignment_0 )?
            {
             before(grammarAccess.getEntityAccess().getPointcutAssignment_0()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:795:1: ( rule__Entity__PointcutAssignment_0 )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==27) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:795:2: rule__Entity__PointcutAssignment_0
                    {
                    pushFollow(FOLLOW_rule__Entity__PointcutAssignment_0_in_rule__Entity__Group__01705);
                    rule__Entity__PointcutAssignment_0();
                    _fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEntityAccess().getPointcutAssignment_0()); 

            }

            pushFollow(FOLLOW_rule__Entity__Group__1_in_rule__Entity__Group__01715);
            rule__Entity__Group__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Entity__Group__0


    // $ANTLR start rule__Entity__Group__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:806:1: rule__Entity__Group__1 : ( 'entity' ) rule__Entity__Group__2 ;
    public final void rule__Entity__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:810:1: ( ( 'entity' ) rule__Entity__Group__2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:811:1: ( 'entity' ) rule__Entity__Group__2
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:811:1: ( 'entity' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:812:1: 'entity'
            {
             before(grammarAccess.getEntityAccess().getEntityKeyword_1()); 
            match(input,12,FOLLOW_12_in_rule__Entity__Group__11744); 
             after(grammarAccess.getEntityAccess().getEntityKeyword_1()); 

            }

            pushFollow(FOLLOW_rule__Entity__Group__2_in_rule__Entity__Group__11754);
            rule__Entity__Group__2();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Entity__Group__1


    // $ANTLR start rule__Entity__Group__2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:826:1: rule__Entity__Group__2 : ( ( rule__Entity__NameAssignment_2 ) ) rule__Entity__Group__3 ;
    public final void rule__Entity__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:830:1: ( ( ( rule__Entity__NameAssignment_2 ) ) rule__Entity__Group__3 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:831:1: ( ( rule__Entity__NameAssignment_2 ) ) rule__Entity__Group__3
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:831:1: ( ( rule__Entity__NameAssignment_2 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:832:1: ( rule__Entity__NameAssignment_2 )
            {
             before(grammarAccess.getEntityAccess().getNameAssignment_2()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:833:1: ( rule__Entity__NameAssignment_2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:833:2: rule__Entity__NameAssignment_2
            {
            pushFollow(FOLLOW_rule__Entity__NameAssignment_2_in_rule__Entity__Group__21782);
            rule__Entity__NameAssignment_2();
            _fsp--;


            }

             after(grammarAccess.getEntityAccess().getNameAssignment_2()); 

            }

            pushFollow(FOLLOW_rule__Entity__Group__3_in_rule__Entity__Group__21791);
            rule__Entity__Group__3();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Entity__Group__2


    // $ANTLR start rule__Entity__Group__3
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:844:1: rule__Entity__Group__3 : ( ( rule__Entity__TagsAssignment_3 )? ) rule__Entity__Group__4 ;
    public final void rule__Entity__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:848:1: ( ( ( rule__Entity__TagsAssignment_3 )? ) rule__Entity__Group__4 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:849:1: ( ( rule__Entity__TagsAssignment_3 )? ) rule__Entity__Group__4
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:849:1: ( ( rule__Entity__TagsAssignment_3 )? )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:850:1: ( rule__Entity__TagsAssignment_3 )?
            {
             before(grammarAccess.getEntityAccess().getTagsAssignment_3()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:851:1: ( rule__Entity__TagsAssignment_3 )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==26) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:851:2: rule__Entity__TagsAssignment_3
                    {
                    pushFollow(FOLLOW_rule__Entity__TagsAssignment_3_in_rule__Entity__Group__31819);
                    rule__Entity__TagsAssignment_3();
                    _fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEntityAccess().getTagsAssignment_3()); 

            }

            pushFollow(FOLLOW_rule__Entity__Group__4_in_rule__Entity__Group__31829);
            rule__Entity__Group__4();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Entity__Group__3


    // $ANTLR start rule__Entity__Group__4
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:862:1: rule__Entity__Group__4 : ( ( rule__Entity__FeatureClauseAssignment_4 )? ) rule__Entity__Group__5 ;
    public final void rule__Entity__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:866:1: ( ( ( rule__Entity__FeatureClauseAssignment_4 )? ) rule__Entity__Group__5 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:867:1: ( ( rule__Entity__FeatureClauseAssignment_4 )? ) rule__Entity__Group__5
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:867:1: ( ( rule__Entity__FeatureClauseAssignment_4 )? )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:868:1: ( rule__Entity__FeatureClauseAssignment_4 )?
            {
             before(grammarAccess.getEntityAccess().getFeatureClauseAssignment_4()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:869:1: ( rule__Entity__FeatureClauseAssignment_4 )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==16||(LA8_0>=20 && LA8_0<=22)) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:869:2: rule__Entity__FeatureClauseAssignment_4
                    {
                    pushFollow(FOLLOW_rule__Entity__FeatureClauseAssignment_4_in_rule__Entity__Group__41857);
                    rule__Entity__FeatureClauseAssignment_4();
                    _fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEntityAccess().getFeatureClauseAssignment_4()); 

            }

            pushFollow(FOLLOW_rule__Entity__Group__5_in_rule__Entity__Group__41867);
            rule__Entity__Group__5();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Entity__Group__4


    // $ANTLR start rule__Entity__Group__5
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:880:1: rule__Entity__Group__5 : ( '{' ) rule__Entity__Group__6 ;
    public final void rule__Entity__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:884:1: ( ( '{' ) rule__Entity__Group__6 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:885:1: ( '{' ) rule__Entity__Group__6
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:885:1: ( '{' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:886:1: '{'
            {
             before(grammarAccess.getEntityAccess().getLeftCurlyBracketKeyword_5()); 
            match(input,13,FOLLOW_13_in_rule__Entity__Group__51896); 
             after(grammarAccess.getEntityAccess().getLeftCurlyBracketKeyword_5()); 

            }

            pushFollow(FOLLOW_rule__Entity__Group__6_in_rule__Entity__Group__51906);
            rule__Entity__Group__6();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Entity__Group__5


    // $ANTLR start rule__Entity__Group__6
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:900:1: rule__Entity__Group__6 : ( ( rule__Entity__AttributesAssignment_6 )* ) rule__Entity__Group__7 ;
    public final void rule__Entity__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:904:1: ( ( ( rule__Entity__AttributesAssignment_6 )* ) rule__Entity__Group__7 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:905:1: ( ( rule__Entity__AttributesAssignment_6 )* ) rule__Entity__Group__7
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:905:1: ( ( rule__Entity__AttributesAssignment_6 )* )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:906:1: ( rule__Entity__AttributesAssignment_6 )*
            {
             before(grammarAccess.getEntityAccess().getAttributesAssignment_6()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:907:1: ( rule__Entity__AttributesAssignment_6 )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==RULE_ID) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:907:2: rule__Entity__AttributesAssignment_6
            	    {
            	    pushFollow(FOLLOW_rule__Entity__AttributesAssignment_6_in_rule__Entity__Group__61934);
            	    rule__Entity__AttributesAssignment_6();
            	    _fsp--;


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

             after(grammarAccess.getEntityAccess().getAttributesAssignment_6()); 

            }

            pushFollow(FOLLOW_rule__Entity__Group__7_in_rule__Entity__Group__61944);
            rule__Entity__Group__7();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Entity__Group__6


    // $ANTLR start rule__Entity__Group__7
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:918:1: rule__Entity__Group__7 : ( '}' ) ;
    public final void rule__Entity__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:922:1: ( ( '}' ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:923:1: ( '}' )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:923:1: ( '}' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:924:1: '}'
            {
             before(grammarAccess.getEntityAccess().getRightCurlyBracketKeyword_7()); 
            match(input,14,FOLLOW_14_in_rule__Entity__Group__71973); 
             after(grammarAccess.getEntityAccess().getRightCurlyBracketKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Entity__Group__7


    // $ANTLR start rule__Attribute__Group__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:953:1: rule__Attribute__Group__0 : ( ( rule__Attribute__NameAssignment_0 ) ) rule__Attribute__Group__1 ;
    public final void rule__Attribute__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:957:1: ( ( ( rule__Attribute__NameAssignment_0 ) ) rule__Attribute__Group__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:958:1: ( ( rule__Attribute__NameAssignment_0 ) ) rule__Attribute__Group__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:958:1: ( ( rule__Attribute__NameAssignment_0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:959:1: ( rule__Attribute__NameAssignment_0 )
            {
             before(grammarAccess.getAttributeAccess().getNameAssignment_0()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:960:1: ( rule__Attribute__NameAssignment_0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:960:2: rule__Attribute__NameAssignment_0
            {
            pushFollow(FOLLOW_rule__Attribute__NameAssignment_0_in_rule__Attribute__Group__02024);
            rule__Attribute__NameAssignment_0();
            _fsp--;


            }

             after(grammarAccess.getAttributeAccess().getNameAssignment_0()); 

            }

            pushFollow(FOLLOW_rule__Attribute__Group__1_in_rule__Attribute__Group__02033);
            rule__Attribute__Group__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Attribute__Group__0


    // $ANTLR start rule__Attribute__Group__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:971:1: rule__Attribute__Group__1 : ( ':' ) rule__Attribute__Group__2 ;
    public final void rule__Attribute__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:975:1: ( ( ':' ) rule__Attribute__Group__2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:976:1: ( ':' ) rule__Attribute__Group__2
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:976:1: ( ':' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:977:1: ':'
            {
             before(grammarAccess.getAttributeAccess().getColonKeyword_1()); 
            match(input,15,FOLLOW_15_in_rule__Attribute__Group__12062); 
             after(grammarAccess.getAttributeAccess().getColonKeyword_1()); 

            }

            pushFollow(FOLLOW_rule__Attribute__Group__2_in_rule__Attribute__Group__12072);
            rule__Attribute__Group__2();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Attribute__Group__1


    // $ANTLR start rule__Attribute__Group__2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:991:1: rule__Attribute__Group__2 : ( ( rule__Attribute__TypeAssignment_2 ) ) rule__Attribute__Group__3 ;
    public final void rule__Attribute__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:995:1: ( ( ( rule__Attribute__TypeAssignment_2 ) ) rule__Attribute__Group__3 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:996:1: ( ( rule__Attribute__TypeAssignment_2 ) ) rule__Attribute__Group__3
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:996:1: ( ( rule__Attribute__TypeAssignment_2 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:997:1: ( rule__Attribute__TypeAssignment_2 )
            {
             before(grammarAccess.getAttributeAccess().getTypeAssignment_2()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:998:1: ( rule__Attribute__TypeAssignment_2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:998:2: rule__Attribute__TypeAssignment_2
            {
            pushFollow(FOLLOW_rule__Attribute__TypeAssignment_2_in_rule__Attribute__Group__22100);
            rule__Attribute__TypeAssignment_2();
            _fsp--;


            }

             after(grammarAccess.getAttributeAccess().getTypeAssignment_2()); 

            }

            pushFollow(FOLLOW_rule__Attribute__Group__3_in_rule__Attribute__Group__22109);
            rule__Attribute__Group__3();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Attribute__Group__2


    // $ANTLR start rule__Attribute__Group__3
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1009:1: rule__Attribute__Group__3 : ( ( rule__Attribute__FeatureClauseAssignment_3 )? ) ;
    public final void rule__Attribute__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1013:1: ( ( ( rule__Attribute__FeatureClauseAssignment_3 )? ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1014:1: ( ( rule__Attribute__FeatureClauseAssignment_3 )? )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1014:1: ( ( rule__Attribute__FeatureClauseAssignment_3 )? )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1015:1: ( rule__Attribute__FeatureClauseAssignment_3 )?
            {
             before(grammarAccess.getAttributeAccess().getFeatureClauseAssignment_3()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1016:1: ( rule__Attribute__FeatureClauseAssignment_3 )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==16||(LA10_0>=20 && LA10_0<=22)) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1016:2: rule__Attribute__FeatureClauseAssignment_3
                    {
                    pushFollow(FOLLOW_rule__Attribute__FeatureClauseAssignment_3_in_rule__Attribute__Group__32137);
                    rule__Attribute__FeatureClauseAssignment_3();
                    _fsp--;


                    }
                    break;

            }

             after(grammarAccess.getAttributeAccess().getFeatureClauseAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Attribute__Group__3


    // $ANTLR start rule__FeatureAndList__Group__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1034:1: rule__FeatureAndList__Group__0 : ( 'featureAndList' ) rule__FeatureAndList__Group__1 ;
    public final void rule__FeatureAndList__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1038:1: ( ( 'featureAndList' ) rule__FeatureAndList__Group__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1039:1: ( 'featureAndList' ) rule__FeatureAndList__Group__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1039:1: ( 'featureAndList' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1040:1: 'featureAndList'
            {
             before(grammarAccess.getFeatureAndListAccess().getFeatureAndListKeyword_0()); 
            match(input,16,FOLLOW_16_in_rule__FeatureAndList__Group__02181); 
             after(grammarAccess.getFeatureAndListAccess().getFeatureAndListKeyword_0()); 

            }

            pushFollow(FOLLOW_rule__FeatureAndList__Group__1_in_rule__FeatureAndList__Group__02191);
            rule__FeatureAndList__Group__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureAndList__Group__0


    // $ANTLR start rule__FeatureAndList__Group__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1054:1: rule__FeatureAndList__Group__1 : ( ( rule__FeatureAndList__RetainedAssignment_1 )? ) rule__FeatureAndList__Group__2 ;
    public final void rule__FeatureAndList__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1058:1: ( ( ( rule__FeatureAndList__RetainedAssignment_1 )? ) rule__FeatureAndList__Group__2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1059:1: ( ( rule__FeatureAndList__RetainedAssignment_1 )? ) rule__FeatureAndList__Group__2
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1059:1: ( ( rule__FeatureAndList__RetainedAssignment_1 )? )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1060:1: ( rule__FeatureAndList__RetainedAssignment_1 )?
            {
             before(grammarAccess.getFeatureAndListAccess().getRetainedAssignment_1()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1061:1: ( rule__FeatureAndList__RetainedAssignment_1 )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==33) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1061:2: rule__FeatureAndList__RetainedAssignment_1
                    {
                    pushFollow(FOLLOW_rule__FeatureAndList__RetainedAssignment_1_in_rule__FeatureAndList__Group__12219);
                    rule__FeatureAndList__RetainedAssignment_1();
                    _fsp--;


                    }
                    break;

            }

             after(grammarAccess.getFeatureAndListAccess().getRetainedAssignment_1()); 

            }

            pushFollow(FOLLOW_rule__FeatureAndList__Group__2_in_rule__FeatureAndList__Group__12229);
            rule__FeatureAndList__Group__2();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureAndList__Group__1


    // $ANTLR start rule__FeatureAndList__Group__2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1072:1: rule__FeatureAndList__Group__2 : ( '(' ) rule__FeatureAndList__Group__3 ;
    public final void rule__FeatureAndList__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1076:1: ( ( '(' ) rule__FeatureAndList__Group__3 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1077:1: ( '(' ) rule__FeatureAndList__Group__3
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1077:1: ( '(' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1078:1: '('
            {
             before(grammarAccess.getFeatureAndListAccess().getLeftParenthesisKeyword_2()); 
            match(input,17,FOLLOW_17_in_rule__FeatureAndList__Group__22258); 
             after(grammarAccess.getFeatureAndListAccess().getLeftParenthesisKeyword_2()); 

            }

            pushFollow(FOLLOW_rule__FeatureAndList__Group__3_in_rule__FeatureAndList__Group__22268);
            rule__FeatureAndList__Group__3();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureAndList__Group__2


    // $ANTLR start rule__FeatureAndList__Group__3
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1092:1: rule__FeatureAndList__Group__3 : ( ( rule__FeatureAndList__FeatureListAssignment_3 ) ) rule__FeatureAndList__Group__4 ;
    public final void rule__FeatureAndList__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1096:1: ( ( ( rule__FeatureAndList__FeatureListAssignment_3 ) ) rule__FeatureAndList__Group__4 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1097:1: ( ( rule__FeatureAndList__FeatureListAssignment_3 ) ) rule__FeatureAndList__Group__4
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1097:1: ( ( rule__FeatureAndList__FeatureListAssignment_3 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1098:1: ( rule__FeatureAndList__FeatureListAssignment_3 )
            {
             before(grammarAccess.getFeatureAndListAccess().getFeatureListAssignment_3()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1099:1: ( rule__FeatureAndList__FeatureListAssignment_3 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1099:2: rule__FeatureAndList__FeatureListAssignment_3
            {
            pushFollow(FOLLOW_rule__FeatureAndList__FeatureListAssignment_3_in_rule__FeatureAndList__Group__32296);
            rule__FeatureAndList__FeatureListAssignment_3();
            _fsp--;


            }

             after(grammarAccess.getFeatureAndListAccess().getFeatureListAssignment_3()); 

            }

            pushFollow(FOLLOW_rule__FeatureAndList__Group__4_in_rule__FeatureAndList__Group__32305);
            rule__FeatureAndList__Group__4();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureAndList__Group__3


    // $ANTLR start rule__FeatureAndList__Group__4
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1110:1: rule__FeatureAndList__Group__4 : ( ( rule__FeatureAndList__Group_4__0 )* ) rule__FeatureAndList__Group__5 ;
    public final void rule__FeatureAndList__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1114:1: ( ( ( rule__FeatureAndList__Group_4__0 )* ) rule__FeatureAndList__Group__5 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1115:1: ( ( rule__FeatureAndList__Group_4__0 )* ) rule__FeatureAndList__Group__5
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1115:1: ( ( rule__FeatureAndList__Group_4__0 )* )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1116:1: ( rule__FeatureAndList__Group_4__0 )*
            {
             before(grammarAccess.getFeatureAndListAccess().getGroup_4()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1117:1: ( rule__FeatureAndList__Group_4__0 )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==19) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1117:2: rule__FeatureAndList__Group_4__0
            	    {
            	    pushFollow(FOLLOW_rule__FeatureAndList__Group_4__0_in_rule__FeatureAndList__Group__42333);
            	    rule__FeatureAndList__Group_4__0();
            	    _fsp--;


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

             after(grammarAccess.getFeatureAndListAccess().getGroup_4()); 

            }

            pushFollow(FOLLOW_rule__FeatureAndList__Group__5_in_rule__FeatureAndList__Group__42343);
            rule__FeatureAndList__Group__5();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureAndList__Group__4


    // $ANTLR start rule__FeatureAndList__Group__5
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1128:1: rule__FeatureAndList__Group__5 : ( ')' ) ;
    public final void rule__FeatureAndList__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1132:1: ( ( ')' ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1133:1: ( ')' )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1133:1: ( ')' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1134:1: ')'
            {
             before(grammarAccess.getFeatureAndListAccess().getRightParenthesisKeyword_5()); 
            match(input,18,FOLLOW_18_in_rule__FeatureAndList__Group__52372); 
             after(grammarAccess.getFeatureAndListAccess().getRightParenthesisKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureAndList__Group__5


    // $ANTLR start rule__FeatureAndList__Group_4__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1159:1: rule__FeatureAndList__Group_4__0 : ( ',' ) rule__FeatureAndList__Group_4__1 ;
    public final void rule__FeatureAndList__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1163:1: ( ( ',' ) rule__FeatureAndList__Group_4__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1164:1: ( ',' ) rule__FeatureAndList__Group_4__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1164:1: ( ',' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1165:1: ','
            {
             before(grammarAccess.getFeatureAndListAccess().getCommaKeyword_4_0()); 
            match(input,19,FOLLOW_19_in_rule__FeatureAndList__Group_4__02420); 
             after(grammarAccess.getFeatureAndListAccess().getCommaKeyword_4_0()); 

            }

            pushFollow(FOLLOW_rule__FeatureAndList__Group_4__1_in_rule__FeatureAndList__Group_4__02430);
            rule__FeatureAndList__Group_4__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureAndList__Group_4__0


    // $ANTLR start rule__FeatureAndList__Group_4__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1179:1: rule__FeatureAndList__Group_4__1 : ( ( rule__FeatureAndList__FeatureListAssignment_4_1 ) ) ;
    public final void rule__FeatureAndList__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1183:1: ( ( ( rule__FeatureAndList__FeatureListAssignment_4_1 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1184:1: ( ( rule__FeatureAndList__FeatureListAssignment_4_1 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1184:1: ( ( rule__FeatureAndList__FeatureListAssignment_4_1 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1185:1: ( rule__FeatureAndList__FeatureListAssignment_4_1 )
            {
             before(grammarAccess.getFeatureAndListAccess().getFeatureListAssignment_4_1()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1186:1: ( rule__FeatureAndList__FeatureListAssignment_4_1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1186:2: rule__FeatureAndList__FeatureListAssignment_4_1
            {
            pushFollow(FOLLOW_rule__FeatureAndList__FeatureListAssignment_4_1_in_rule__FeatureAndList__Group_4__12458);
            rule__FeatureAndList__FeatureListAssignment_4_1();
            _fsp--;


            }

             after(grammarAccess.getFeatureAndListAccess().getFeatureListAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureAndList__Group_4__1


    // $ANTLR start rule__FeatureOrList__Group__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1200:1: rule__FeatureOrList__Group__0 : ( 'featureOrList' ) rule__FeatureOrList__Group__1 ;
    public final void rule__FeatureOrList__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1204:1: ( ( 'featureOrList' ) rule__FeatureOrList__Group__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1205:1: ( 'featureOrList' ) rule__FeatureOrList__Group__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1205:1: ( 'featureOrList' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1206:1: 'featureOrList'
            {
             before(grammarAccess.getFeatureOrListAccess().getFeatureOrListKeyword_0()); 
            match(input,20,FOLLOW_20_in_rule__FeatureOrList__Group__02497); 
             after(grammarAccess.getFeatureOrListAccess().getFeatureOrListKeyword_0()); 

            }

            pushFollow(FOLLOW_rule__FeatureOrList__Group__1_in_rule__FeatureOrList__Group__02507);
            rule__FeatureOrList__Group__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureOrList__Group__0


    // $ANTLR start rule__FeatureOrList__Group__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1220:1: rule__FeatureOrList__Group__1 : ( ( rule__FeatureOrList__RetainedAssignment_1 )? ) rule__FeatureOrList__Group__2 ;
    public final void rule__FeatureOrList__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1224:1: ( ( ( rule__FeatureOrList__RetainedAssignment_1 )? ) rule__FeatureOrList__Group__2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1225:1: ( ( rule__FeatureOrList__RetainedAssignment_1 )? ) rule__FeatureOrList__Group__2
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1225:1: ( ( rule__FeatureOrList__RetainedAssignment_1 )? )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1226:1: ( rule__FeatureOrList__RetainedAssignment_1 )?
            {
             before(grammarAccess.getFeatureOrListAccess().getRetainedAssignment_1()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1227:1: ( rule__FeatureOrList__RetainedAssignment_1 )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==33) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1227:2: rule__FeatureOrList__RetainedAssignment_1
                    {
                    pushFollow(FOLLOW_rule__FeatureOrList__RetainedAssignment_1_in_rule__FeatureOrList__Group__12535);
                    rule__FeatureOrList__RetainedAssignment_1();
                    _fsp--;


                    }
                    break;

            }

             after(grammarAccess.getFeatureOrListAccess().getRetainedAssignment_1()); 

            }

            pushFollow(FOLLOW_rule__FeatureOrList__Group__2_in_rule__FeatureOrList__Group__12545);
            rule__FeatureOrList__Group__2();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureOrList__Group__1


    // $ANTLR start rule__FeatureOrList__Group__2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1238:1: rule__FeatureOrList__Group__2 : ( '(' ) rule__FeatureOrList__Group__3 ;
    public final void rule__FeatureOrList__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1242:1: ( ( '(' ) rule__FeatureOrList__Group__3 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1243:1: ( '(' ) rule__FeatureOrList__Group__3
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1243:1: ( '(' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1244:1: '('
            {
             before(grammarAccess.getFeatureOrListAccess().getLeftParenthesisKeyword_2()); 
            match(input,17,FOLLOW_17_in_rule__FeatureOrList__Group__22574); 
             after(grammarAccess.getFeatureOrListAccess().getLeftParenthesisKeyword_2()); 

            }

            pushFollow(FOLLOW_rule__FeatureOrList__Group__3_in_rule__FeatureOrList__Group__22584);
            rule__FeatureOrList__Group__3();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureOrList__Group__2


    // $ANTLR start rule__FeatureOrList__Group__3
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1258:1: rule__FeatureOrList__Group__3 : ( ( rule__FeatureOrList__FeatureListAssignment_3 ) ) rule__FeatureOrList__Group__4 ;
    public final void rule__FeatureOrList__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1262:1: ( ( ( rule__FeatureOrList__FeatureListAssignment_3 ) ) rule__FeatureOrList__Group__4 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1263:1: ( ( rule__FeatureOrList__FeatureListAssignment_3 ) ) rule__FeatureOrList__Group__4
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1263:1: ( ( rule__FeatureOrList__FeatureListAssignment_3 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1264:1: ( rule__FeatureOrList__FeatureListAssignment_3 )
            {
             before(grammarAccess.getFeatureOrListAccess().getFeatureListAssignment_3()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1265:1: ( rule__FeatureOrList__FeatureListAssignment_3 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1265:2: rule__FeatureOrList__FeatureListAssignment_3
            {
            pushFollow(FOLLOW_rule__FeatureOrList__FeatureListAssignment_3_in_rule__FeatureOrList__Group__32612);
            rule__FeatureOrList__FeatureListAssignment_3();
            _fsp--;


            }

             after(grammarAccess.getFeatureOrListAccess().getFeatureListAssignment_3()); 

            }

            pushFollow(FOLLOW_rule__FeatureOrList__Group__4_in_rule__FeatureOrList__Group__32621);
            rule__FeatureOrList__Group__4();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureOrList__Group__3


    // $ANTLR start rule__FeatureOrList__Group__4
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1276:1: rule__FeatureOrList__Group__4 : ( ( rule__FeatureOrList__Group_4__0 )* ) rule__FeatureOrList__Group__5 ;
    public final void rule__FeatureOrList__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1280:1: ( ( ( rule__FeatureOrList__Group_4__0 )* ) rule__FeatureOrList__Group__5 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1281:1: ( ( rule__FeatureOrList__Group_4__0 )* ) rule__FeatureOrList__Group__5
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1281:1: ( ( rule__FeatureOrList__Group_4__0 )* )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1282:1: ( rule__FeatureOrList__Group_4__0 )*
            {
             before(grammarAccess.getFeatureOrListAccess().getGroup_4()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1283:1: ( rule__FeatureOrList__Group_4__0 )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==19) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1283:2: rule__FeatureOrList__Group_4__0
            	    {
            	    pushFollow(FOLLOW_rule__FeatureOrList__Group_4__0_in_rule__FeatureOrList__Group__42649);
            	    rule__FeatureOrList__Group_4__0();
            	    _fsp--;


            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);

             after(grammarAccess.getFeatureOrListAccess().getGroup_4()); 

            }

            pushFollow(FOLLOW_rule__FeatureOrList__Group__5_in_rule__FeatureOrList__Group__42659);
            rule__FeatureOrList__Group__5();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureOrList__Group__4


    // $ANTLR start rule__FeatureOrList__Group__5
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1294:1: rule__FeatureOrList__Group__5 : ( ')' ) ;
    public final void rule__FeatureOrList__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1298:1: ( ( ')' ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1299:1: ( ')' )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1299:1: ( ')' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1300:1: ')'
            {
             before(grammarAccess.getFeatureOrListAccess().getRightParenthesisKeyword_5()); 
            match(input,18,FOLLOW_18_in_rule__FeatureOrList__Group__52688); 
             after(grammarAccess.getFeatureOrListAccess().getRightParenthesisKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureOrList__Group__5


    // $ANTLR start rule__FeatureOrList__Group_4__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1325:1: rule__FeatureOrList__Group_4__0 : ( ',' ) rule__FeatureOrList__Group_4__1 ;
    public final void rule__FeatureOrList__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1329:1: ( ( ',' ) rule__FeatureOrList__Group_4__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1330:1: ( ',' ) rule__FeatureOrList__Group_4__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1330:1: ( ',' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1331:1: ','
            {
             before(grammarAccess.getFeatureOrListAccess().getCommaKeyword_4_0()); 
            match(input,19,FOLLOW_19_in_rule__FeatureOrList__Group_4__02736); 
             after(grammarAccess.getFeatureOrListAccess().getCommaKeyword_4_0()); 

            }

            pushFollow(FOLLOW_rule__FeatureOrList__Group_4__1_in_rule__FeatureOrList__Group_4__02746);
            rule__FeatureOrList__Group_4__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureOrList__Group_4__0


    // $ANTLR start rule__FeatureOrList__Group_4__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1345:1: rule__FeatureOrList__Group_4__1 : ( ( rule__FeatureOrList__FeatureListAssignment_4_1 ) ) ;
    public final void rule__FeatureOrList__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1349:1: ( ( ( rule__FeatureOrList__FeatureListAssignment_4_1 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1350:1: ( ( rule__FeatureOrList__FeatureListAssignment_4_1 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1350:1: ( ( rule__FeatureOrList__FeatureListAssignment_4_1 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1351:1: ( rule__FeatureOrList__FeatureListAssignment_4_1 )
            {
             before(grammarAccess.getFeatureOrListAccess().getFeatureListAssignment_4_1()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1352:1: ( rule__FeatureOrList__FeatureListAssignment_4_1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1352:2: rule__FeatureOrList__FeatureListAssignment_4_1
            {
            pushFollow(FOLLOW_rule__FeatureOrList__FeatureListAssignment_4_1_in_rule__FeatureOrList__Group_4__12774);
            rule__FeatureOrList__FeatureListAssignment_4_1();
            _fsp--;


            }

             after(grammarAccess.getFeatureOrListAccess().getFeatureListAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureOrList__Group_4__1


    // $ANTLR start rule__FeatureExpression__Group__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1366:1: rule__FeatureExpression__Group__0 : ( 'featureExp' ) rule__FeatureExpression__Group__1 ;
    public final void rule__FeatureExpression__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1370:1: ( ( 'featureExp' ) rule__FeatureExpression__Group__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1371:1: ( 'featureExp' ) rule__FeatureExpression__Group__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1371:1: ( 'featureExp' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1372:1: 'featureExp'
            {
             before(grammarAccess.getFeatureExpressionAccess().getFeatureExpKeyword_0()); 
            match(input,21,FOLLOW_21_in_rule__FeatureExpression__Group__02813); 
             after(grammarAccess.getFeatureExpressionAccess().getFeatureExpKeyword_0()); 

            }

            pushFollow(FOLLOW_rule__FeatureExpression__Group__1_in_rule__FeatureExpression__Group__02823);
            rule__FeatureExpression__Group__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureExpression__Group__0


    // $ANTLR start rule__FeatureExpression__Group__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1386:1: rule__FeatureExpression__Group__1 : ( ( rule__FeatureExpression__RetainedAssignment_1 )? ) rule__FeatureExpression__Group__2 ;
    public final void rule__FeatureExpression__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1390:1: ( ( ( rule__FeatureExpression__RetainedAssignment_1 )? ) rule__FeatureExpression__Group__2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1391:1: ( ( rule__FeatureExpression__RetainedAssignment_1 )? ) rule__FeatureExpression__Group__2
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1391:1: ( ( rule__FeatureExpression__RetainedAssignment_1 )? )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1392:1: ( rule__FeatureExpression__RetainedAssignment_1 )?
            {
             before(grammarAccess.getFeatureExpressionAccess().getRetainedAssignment_1()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1393:1: ( rule__FeatureExpression__RetainedAssignment_1 )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==33) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1393:2: rule__FeatureExpression__RetainedAssignment_1
                    {
                    pushFollow(FOLLOW_rule__FeatureExpression__RetainedAssignment_1_in_rule__FeatureExpression__Group__12851);
                    rule__FeatureExpression__RetainedAssignment_1();
                    _fsp--;


                    }
                    break;

            }

             after(grammarAccess.getFeatureExpressionAccess().getRetainedAssignment_1()); 

            }

            pushFollow(FOLLOW_rule__FeatureExpression__Group__2_in_rule__FeatureExpression__Group__12861);
            rule__FeatureExpression__Group__2();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureExpression__Group__1


    // $ANTLR start rule__FeatureExpression__Group__2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1404:1: rule__FeatureExpression__Group__2 : ( '(' ) rule__FeatureExpression__Group__3 ;
    public final void rule__FeatureExpression__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1408:1: ( ( '(' ) rule__FeatureExpression__Group__3 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1409:1: ( '(' ) rule__FeatureExpression__Group__3
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1409:1: ( '(' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1410:1: '('
            {
             before(grammarAccess.getFeatureExpressionAccess().getLeftParenthesisKeyword_2()); 
            match(input,17,FOLLOW_17_in_rule__FeatureExpression__Group__22890); 
             after(grammarAccess.getFeatureExpressionAccess().getLeftParenthesisKeyword_2()); 

            }

            pushFollow(FOLLOW_rule__FeatureExpression__Group__3_in_rule__FeatureExpression__Group__22900);
            rule__FeatureExpression__Group__3();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureExpression__Group__2


    // $ANTLR start rule__FeatureExpression__Group__3
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1424:1: rule__FeatureExpression__Group__3 : ( ( rule__FeatureExpression__ExpressionAssignment_3 ) ) rule__FeatureExpression__Group__4 ;
    public final void rule__FeatureExpression__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1428:1: ( ( ( rule__FeatureExpression__ExpressionAssignment_3 ) ) rule__FeatureExpression__Group__4 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1429:1: ( ( rule__FeatureExpression__ExpressionAssignment_3 ) ) rule__FeatureExpression__Group__4
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1429:1: ( ( rule__FeatureExpression__ExpressionAssignment_3 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1430:1: ( rule__FeatureExpression__ExpressionAssignment_3 )
            {
             before(grammarAccess.getFeatureExpressionAccess().getExpressionAssignment_3()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1431:1: ( rule__FeatureExpression__ExpressionAssignment_3 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1431:2: rule__FeatureExpression__ExpressionAssignment_3
            {
            pushFollow(FOLLOW_rule__FeatureExpression__ExpressionAssignment_3_in_rule__FeatureExpression__Group__32928);
            rule__FeatureExpression__ExpressionAssignment_3();
            _fsp--;


            }

             after(grammarAccess.getFeatureExpressionAccess().getExpressionAssignment_3()); 

            }

            pushFollow(FOLLOW_rule__FeatureExpression__Group__4_in_rule__FeatureExpression__Group__32937);
            rule__FeatureExpression__Group__4();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureExpression__Group__3


    // $ANTLR start rule__FeatureExpression__Group__4
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1442:1: rule__FeatureExpression__Group__4 : ( ')' ) ;
    public final void rule__FeatureExpression__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1446:1: ( ( ')' ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1447:1: ( ')' )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1447:1: ( ')' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1448:1: ')'
            {
             before(grammarAccess.getFeatureExpressionAccess().getRightParenthesisKeyword_4()); 
            match(input,18,FOLLOW_18_in_rule__FeatureExpression__Group__42966); 
             after(grammarAccess.getFeatureExpressionAccess().getRightParenthesisKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureExpression__Group__4


    // $ANTLR start rule__Feature__Group__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1471:1: rule__Feature__Group__0 : ( 'feature' ) rule__Feature__Group__1 ;
    public final void rule__Feature__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1475:1: ( ( 'feature' ) rule__Feature__Group__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1476:1: ( 'feature' ) rule__Feature__Group__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1476:1: ( 'feature' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1477:1: 'feature'
            {
             before(grammarAccess.getFeatureAccess().getFeatureKeyword_0()); 
            match(input,22,FOLLOW_22_in_rule__Feature__Group__03012); 
             after(grammarAccess.getFeatureAccess().getFeatureKeyword_0()); 

            }

            pushFollow(FOLLOW_rule__Feature__Group__1_in_rule__Feature__Group__03022);
            rule__Feature__Group__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Feature__Group__0


    // $ANTLR start rule__Feature__Group__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1491:1: rule__Feature__Group__1 : ( ( rule__Feature__RetainedAssignment_1 )? ) rule__Feature__Group__2 ;
    public final void rule__Feature__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1495:1: ( ( ( rule__Feature__RetainedAssignment_1 )? ) rule__Feature__Group__2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1496:1: ( ( rule__Feature__RetainedAssignment_1 )? ) rule__Feature__Group__2
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1496:1: ( ( rule__Feature__RetainedAssignment_1 )? )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1497:1: ( rule__Feature__RetainedAssignment_1 )?
            {
             before(grammarAccess.getFeatureAccess().getRetainedAssignment_1()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1498:1: ( rule__Feature__RetainedAssignment_1 )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==33) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1498:2: rule__Feature__RetainedAssignment_1
                    {
                    pushFollow(FOLLOW_rule__Feature__RetainedAssignment_1_in_rule__Feature__Group__13050);
                    rule__Feature__RetainedAssignment_1();
                    _fsp--;


                    }
                    break;

            }

             after(grammarAccess.getFeatureAccess().getRetainedAssignment_1()); 

            }

            pushFollow(FOLLOW_rule__Feature__Group__2_in_rule__Feature__Group__13060);
            rule__Feature__Group__2();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Feature__Group__1


    // $ANTLR start rule__Feature__Group__2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1509:1: rule__Feature__Group__2 : ( ( rule__Feature__FeatureAssignment_2 ) ) ;
    public final void rule__Feature__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1513:1: ( ( ( rule__Feature__FeatureAssignment_2 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1514:1: ( ( rule__Feature__FeatureAssignment_2 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1514:1: ( ( rule__Feature__FeatureAssignment_2 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1515:1: ( rule__Feature__FeatureAssignment_2 )
            {
             before(grammarAccess.getFeatureAccess().getFeatureAssignment_2()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1516:1: ( rule__Feature__FeatureAssignment_2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1516:2: rule__Feature__FeatureAssignment_2
            {
            pushFollow(FOLLOW_rule__Feature__FeatureAssignment_2_in_rule__Feature__Group__23088);
            rule__Feature__FeatureAssignment_2();
            _fsp--;


            }

             after(grammarAccess.getFeatureAccess().getFeatureAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Feature__Group__2


    // $ANTLR start rule__OrExpression__Group__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1532:1: rule__OrExpression__Group__0 : ( ( rule__OrExpression__OperandsAssignment_0 ) ) rule__OrExpression__Group__1 ;
    public final void rule__OrExpression__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1536:1: ( ( ( rule__OrExpression__OperandsAssignment_0 ) ) rule__OrExpression__Group__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1537:1: ( ( rule__OrExpression__OperandsAssignment_0 ) ) rule__OrExpression__Group__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1537:1: ( ( rule__OrExpression__OperandsAssignment_0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1538:1: ( rule__OrExpression__OperandsAssignment_0 )
            {
             before(grammarAccess.getOrExpressionAccess().getOperandsAssignment_0()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1539:1: ( rule__OrExpression__OperandsAssignment_0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1539:2: rule__OrExpression__OperandsAssignment_0
            {
            pushFollow(FOLLOW_rule__OrExpression__OperandsAssignment_0_in_rule__OrExpression__Group__03128);
            rule__OrExpression__OperandsAssignment_0();
            _fsp--;


            }

             after(grammarAccess.getOrExpressionAccess().getOperandsAssignment_0()); 

            }

            pushFollow(FOLLOW_rule__OrExpression__Group__1_in_rule__OrExpression__Group__03137);
            rule__OrExpression__Group__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__OrExpression__Group__0


    // $ANTLR start rule__OrExpression__Group__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1550:1: rule__OrExpression__Group__1 : ( ( rule__OrExpression__Group_1__0 )* ) ;
    public final void rule__OrExpression__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1554:1: ( ( ( rule__OrExpression__Group_1__0 )* ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1555:1: ( ( rule__OrExpression__Group_1__0 )* )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1555:1: ( ( rule__OrExpression__Group_1__0 )* )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1556:1: ( rule__OrExpression__Group_1__0 )*
            {
             before(grammarAccess.getOrExpressionAccess().getGroup_1()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1557:1: ( rule__OrExpression__Group_1__0 )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( (LA17_0==23) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1557:2: rule__OrExpression__Group_1__0
            	    {
            	    pushFollow(FOLLOW_rule__OrExpression__Group_1__0_in_rule__OrExpression__Group__13165);
            	    rule__OrExpression__Group_1__0();
            	    _fsp--;


            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);

             after(grammarAccess.getOrExpressionAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__OrExpression__Group__1


    // $ANTLR start rule__OrExpression__Group_1__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1571:1: rule__OrExpression__Group_1__0 : ( 'or' ) rule__OrExpression__Group_1__1 ;
    public final void rule__OrExpression__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1575:1: ( ( 'or' ) rule__OrExpression__Group_1__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1576:1: ( 'or' ) rule__OrExpression__Group_1__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1576:1: ( 'or' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1577:1: 'or'
            {
             before(grammarAccess.getOrExpressionAccess().getOrKeyword_1_0()); 
            match(input,23,FOLLOW_23_in_rule__OrExpression__Group_1__03205); 
             after(grammarAccess.getOrExpressionAccess().getOrKeyword_1_0()); 

            }

            pushFollow(FOLLOW_rule__OrExpression__Group_1__1_in_rule__OrExpression__Group_1__03215);
            rule__OrExpression__Group_1__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__OrExpression__Group_1__0


    // $ANTLR start rule__OrExpression__Group_1__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1591:1: rule__OrExpression__Group_1__1 : ( ( rule__OrExpression__OperandsAssignment_1_1 ) ) ;
    public final void rule__OrExpression__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1595:1: ( ( ( rule__OrExpression__OperandsAssignment_1_1 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1596:1: ( ( rule__OrExpression__OperandsAssignment_1_1 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1596:1: ( ( rule__OrExpression__OperandsAssignment_1_1 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1597:1: ( rule__OrExpression__OperandsAssignment_1_1 )
            {
             before(grammarAccess.getOrExpressionAccess().getOperandsAssignment_1_1()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1598:1: ( rule__OrExpression__OperandsAssignment_1_1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1598:2: rule__OrExpression__OperandsAssignment_1_1
            {
            pushFollow(FOLLOW_rule__OrExpression__OperandsAssignment_1_1_in_rule__OrExpression__Group_1__13243);
            rule__OrExpression__OperandsAssignment_1_1();
            _fsp--;


            }

             after(grammarAccess.getOrExpressionAccess().getOperandsAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__OrExpression__Group_1__1


    // $ANTLR start rule__AndExpression__Group__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1612:1: rule__AndExpression__Group__0 : ( ( rule__AndExpression__OperandsAssignment_0 ) ) rule__AndExpression__Group__1 ;
    public final void rule__AndExpression__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1616:1: ( ( ( rule__AndExpression__OperandsAssignment_0 ) ) rule__AndExpression__Group__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1617:1: ( ( rule__AndExpression__OperandsAssignment_0 ) ) rule__AndExpression__Group__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1617:1: ( ( rule__AndExpression__OperandsAssignment_0 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1618:1: ( rule__AndExpression__OperandsAssignment_0 )
            {
             before(grammarAccess.getAndExpressionAccess().getOperandsAssignment_0()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1619:1: ( rule__AndExpression__OperandsAssignment_0 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1619:2: rule__AndExpression__OperandsAssignment_0
            {
            pushFollow(FOLLOW_rule__AndExpression__OperandsAssignment_0_in_rule__AndExpression__Group__03281);
            rule__AndExpression__OperandsAssignment_0();
            _fsp--;


            }

             after(grammarAccess.getAndExpressionAccess().getOperandsAssignment_0()); 

            }

            pushFollow(FOLLOW_rule__AndExpression__Group__1_in_rule__AndExpression__Group__03290);
            rule__AndExpression__Group__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__AndExpression__Group__0


    // $ANTLR start rule__AndExpression__Group__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1630:1: rule__AndExpression__Group__1 : ( ( rule__AndExpression__Group_1__0 )* ) ;
    public final void rule__AndExpression__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1634:1: ( ( ( rule__AndExpression__Group_1__0 )* ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1635:1: ( ( rule__AndExpression__Group_1__0 )* )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1635:1: ( ( rule__AndExpression__Group_1__0 )* )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1636:1: ( rule__AndExpression__Group_1__0 )*
            {
             before(grammarAccess.getAndExpressionAccess().getGroup_1()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1637:1: ( rule__AndExpression__Group_1__0 )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( (LA18_0==24) ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1637:2: rule__AndExpression__Group_1__0
            	    {
            	    pushFollow(FOLLOW_rule__AndExpression__Group_1__0_in_rule__AndExpression__Group__13318);
            	    rule__AndExpression__Group_1__0();
            	    _fsp--;


            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);

             after(grammarAccess.getAndExpressionAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__AndExpression__Group__1


    // $ANTLR start rule__AndExpression__Group_1__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1651:1: rule__AndExpression__Group_1__0 : ( 'and' ) rule__AndExpression__Group_1__1 ;
    public final void rule__AndExpression__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1655:1: ( ( 'and' ) rule__AndExpression__Group_1__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1656:1: ( 'and' ) rule__AndExpression__Group_1__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1656:1: ( 'and' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1657:1: 'and'
            {
             before(grammarAccess.getAndExpressionAccess().getAndKeyword_1_0()); 
            match(input,24,FOLLOW_24_in_rule__AndExpression__Group_1__03358); 
             after(grammarAccess.getAndExpressionAccess().getAndKeyword_1_0()); 

            }

            pushFollow(FOLLOW_rule__AndExpression__Group_1__1_in_rule__AndExpression__Group_1__03368);
            rule__AndExpression__Group_1__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__AndExpression__Group_1__0


    // $ANTLR start rule__AndExpression__Group_1__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1671:1: rule__AndExpression__Group_1__1 : ( ( rule__AndExpression__OperandsAssignment_1_1 ) ) ;
    public final void rule__AndExpression__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1675:1: ( ( ( rule__AndExpression__OperandsAssignment_1_1 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1676:1: ( ( rule__AndExpression__OperandsAssignment_1_1 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1676:1: ( ( rule__AndExpression__OperandsAssignment_1_1 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1677:1: ( rule__AndExpression__OperandsAssignment_1_1 )
            {
             before(grammarAccess.getAndExpressionAccess().getOperandsAssignment_1_1()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1678:1: ( rule__AndExpression__OperandsAssignment_1_1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1678:2: rule__AndExpression__OperandsAssignment_1_1
            {
            pushFollow(FOLLOW_rule__AndExpression__OperandsAssignment_1_1_in_rule__AndExpression__Group_1__13396);
            rule__AndExpression__OperandsAssignment_1_1();
            _fsp--;


            }

             after(grammarAccess.getAndExpressionAccess().getOperandsAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__AndExpression__Group_1__1


    // $ANTLR start rule__Operand__Group__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1692:1: rule__Operand__Group__0 : ( ( rule__Operand__IsNotAssignment_0 )? ) rule__Operand__Group__1 ;
    public final void rule__Operand__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1696:1: ( ( ( rule__Operand__IsNotAssignment_0 )? ) rule__Operand__Group__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1697:1: ( ( rule__Operand__IsNotAssignment_0 )? ) rule__Operand__Group__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1697:1: ( ( rule__Operand__IsNotAssignment_0 )? )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1698:1: ( rule__Operand__IsNotAssignment_0 )?
            {
             before(grammarAccess.getOperandAccess().getIsNotAssignment_0()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1699:1: ( rule__Operand__IsNotAssignment_0 )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==34) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1699:2: rule__Operand__IsNotAssignment_0
                    {
                    pushFollow(FOLLOW_rule__Operand__IsNotAssignment_0_in_rule__Operand__Group__03434);
                    rule__Operand__IsNotAssignment_0();
                    _fsp--;


                    }
                    break;

            }

             after(grammarAccess.getOperandAccess().getIsNotAssignment_0()); 

            }

            pushFollow(FOLLOW_rule__Operand__Group__1_in_rule__Operand__Group__03444);
            rule__Operand__Group__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Operand__Group__0


    // $ANTLR start rule__Operand__Group__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1710:1: rule__Operand__Group__1 : ( ( rule__Operand__ExpressionAssignment_1 ) ) ;
    public final void rule__Operand__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1714:1: ( ( ( rule__Operand__ExpressionAssignment_1 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1715:1: ( ( rule__Operand__ExpressionAssignment_1 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1715:1: ( ( rule__Operand__ExpressionAssignment_1 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1716:1: ( rule__Operand__ExpressionAssignment_1 )
            {
             before(grammarAccess.getOperandAccess().getExpressionAssignment_1()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1717:1: ( rule__Operand__ExpressionAssignment_1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1717:2: rule__Operand__ExpressionAssignment_1
            {
            pushFollow(FOLLOW_rule__Operand__ExpressionAssignment_1_in_rule__Operand__Group__13472);
            rule__Operand__ExpressionAssignment_1();
            _fsp--;


            }

             after(grammarAccess.getOperandAccess().getExpressionAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Operand__Group__1


    // $ANTLR start rule__Atom__Group_1__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1731:1: rule__Atom__Group_1__0 : ( '(' ) rule__Atom__Group_1__1 ;
    public final void rule__Atom__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1735:1: ( ( '(' ) rule__Atom__Group_1__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1736:1: ( '(' ) rule__Atom__Group_1__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1736:1: ( '(' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1737:1: '('
            {
             before(grammarAccess.getAtomAccess().getLeftParenthesisKeyword_1_0()); 
            match(input,17,FOLLOW_17_in_rule__Atom__Group_1__03511); 
             after(grammarAccess.getAtomAccess().getLeftParenthesisKeyword_1_0()); 

            }

            pushFollow(FOLLOW_rule__Atom__Group_1__1_in_rule__Atom__Group_1__03521);
            rule__Atom__Group_1__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Atom__Group_1__0


    // $ANTLR start rule__Atom__Group_1__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1751:1: rule__Atom__Group_1__1 : ( ( rule__Atom__ExpressionAssignment_1_1 ) ) rule__Atom__Group_1__2 ;
    public final void rule__Atom__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1755:1: ( ( ( rule__Atom__ExpressionAssignment_1_1 ) ) rule__Atom__Group_1__2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1756:1: ( ( rule__Atom__ExpressionAssignment_1_1 ) ) rule__Atom__Group_1__2
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1756:1: ( ( rule__Atom__ExpressionAssignment_1_1 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1757:1: ( rule__Atom__ExpressionAssignment_1_1 )
            {
             before(grammarAccess.getAtomAccess().getExpressionAssignment_1_1()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1758:1: ( rule__Atom__ExpressionAssignment_1_1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1758:2: rule__Atom__ExpressionAssignment_1_1
            {
            pushFollow(FOLLOW_rule__Atom__ExpressionAssignment_1_1_in_rule__Atom__Group_1__13549);
            rule__Atom__ExpressionAssignment_1_1();
            _fsp--;


            }

             after(grammarAccess.getAtomAccess().getExpressionAssignment_1_1()); 

            }

            pushFollow(FOLLOW_rule__Atom__Group_1__2_in_rule__Atom__Group_1__13558);
            rule__Atom__Group_1__2();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Atom__Group_1__1


    // $ANTLR start rule__Atom__Group_1__2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1769:1: rule__Atom__Group_1__2 : ( ')' ) ;
    public final void rule__Atom__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1773:1: ( ( ')' ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1774:1: ( ')' )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1774:1: ( ')' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1775:1: ')'
            {
             before(grammarAccess.getAtomAccess().getRightParenthesisKeyword_1_2()); 
            match(input,18,FOLLOW_18_in_rule__Atom__Group_1__23587); 
             after(grammarAccess.getAtomAccess().getRightParenthesisKeyword_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Atom__Group_1__2


    // $ANTLR start rule__FeatureModelImport__Group__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1794:1: rule__FeatureModelImport__Group__0 : ( 'featuremodel' ) rule__FeatureModelImport__Group__1 ;
    public final void rule__FeatureModelImport__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1798:1: ( ( 'featuremodel' ) rule__FeatureModelImport__Group__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1799:1: ( 'featuremodel' ) rule__FeatureModelImport__Group__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1799:1: ( 'featuremodel' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1800:1: 'featuremodel'
            {
             before(grammarAccess.getFeatureModelImportAccess().getFeaturemodelKeyword_0()); 
            match(input,25,FOLLOW_25_in_rule__FeatureModelImport__Group__03629); 
             after(grammarAccess.getFeatureModelImportAccess().getFeaturemodelKeyword_0()); 

            }

            pushFollow(FOLLOW_rule__FeatureModelImport__Group__1_in_rule__FeatureModelImport__Group__03639);
            rule__FeatureModelImport__Group__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureModelImport__Group__0


    // $ANTLR start rule__FeatureModelImport__Group__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1814:1: rule__FeatureModelImport__Group__1 : ( ( rule__FeatureModelImport__ImportURIAssignment_1 ) ) ;
    public final void rule__FeatureModelImport__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1818:1: ( ( ( rule__FeatureModelImport__ImportURIAssignment_1 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1819:1: ( ( rule__FeatureModelImport__ImportURIAssignment_1 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1819:1: ( ( rule__FeatureModelImport__ImportURIAssignment_1 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1820:1: ( rule__FeatureModelImport__ImportURIAssignment_1 )
            {
             before(grammarAccess.getFeatureModelImportAccess().getImportURIAssignment_1()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1821:1: ( rule__FeatureModelImport__ImportURIAssignment_1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1821:2: rule__FeatureModelImport__ImportURIAssignment_1
            {
            pushFollow(FOLLOW_rule__FeatureModelImport__ImportURIAssignment_1_in_rule__FeatureModelImport__Group__13667);
            rule__FeatureModelImport__ImportURIAssignment_1();
            _fsp--;


            }

             after(grammarAccess.getFeatureModelImportAccess().getImportURIAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureModelImport__Group__1


    // $ANTLR start rule__TagsClause__Group__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1835:1: rule__TagsClause__Group__0 : ( 'tags' ) rule__TagsClause__Group__1 ;
    public final void rule__TagsClause__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1839:1: ( ( 'tags' ) rule__TagsClause__Group__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1840:1: ( 'tags' ) rule__TagsClause__Group__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1840:1: ( 'tags' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1841:1: 'tags'
            {
             before(grammarAccess.getTagsClauseAccess().getTagsKeyword_0()); 
            match(input,26,FOLLOW_26_in_rule__TagsClause__Group__03706); 
             after(grammarAccess.getTagsClauseAccess().getTagsKeyword_0()); 

            }

            pushFollow(FOLLOW_rule__TagsClause__Group__1_in_rule__TagsClause__Group__03716);
            rule__TagsClause__Group__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__TagsClause__Group__0


    // $ANTLR start rule__TagsClause__Group__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1855:1: rule__TagsClause__Group__1 : ( '(' ) rule__TagsClause__Group__2 ;
    public final void rule__TagsClause__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1859:1: ( ( '(' ) rule__TagsClause__Group__2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1860:1: ( '(' ) rule__TagsClause__Group__2
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1860:1: ( '(' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1861:1: '('
            {
             before(grammarAccess.getTagsClauseAccess().getLeftParenthesisKeyword_1()); 
            match(input,17,FOLLOW_17_in_rule__TagsClause__Group__13745); 
             after(grammarAccess.getTagsClauseAccess().getLeftParenthesisKeyword_1()); 

            }

            pushFollow(FOLLOW_rule__TagsClause__Group__2_in_rule__TagsClause__Group__13755);
            rule__TagsClause__Group__2();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__TagsClause__Group__1


    // $ANTLR start rule__TagsClause__Group__2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1875:1: rule__TagsClause__Group__2 : ( ( rule__TagsClause__TagsAssignment_2 )* ) rule__TagsClause__Group__3 ;
    public final void rule__TagsClause__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1879:1: ( ( ( rule__TagsClause__TagsAssignment_2 )* ) rule__TagsClause__Group__3 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1880:1: ( ( rule__TagsClause__TagsAssignment_2 )* ) rule__TagsClause__Group__3
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1880:1: ( ( rule__TagsClause__TagsAssignment_2 )* )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1881:1: ( rule__TagsClause__TagsAssignment_2 )*
            {
             before(grammarAccess.getTagsClauseAccess().getTagsAssignment_2()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1882:1: ( rule__TagsClause__TagsAssignment_2 )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( (LA20_0==RULE_ID) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1882:2: rule__TagsClause__TagsAssignment_2
            	    {
            	    pushFollow(FOLLOW_rule__TagsClause__TagsAssignment_2_in_rule__TagsClause__Group__23783);
            	    rule__TagsClause__TagsAssignment_2();
            	    _fsp--;


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

             after(grammarAccess.getTagsClauseAccess().getTagsAssignment_2()); 

            }

            pushFollow(FOLLOW_rule__TagsClause__Group__3_in_rule__TagsClause__Group__23793);
            rule__TagsClause__Group__3();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__TagsClause__Group__2


    // $ANTLR start rule__TagsClause__Group__3
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1893:1: rule__TagsClause__Group__3 : ( ')' ) ;
    public final void rule__TagsClause__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1897:1: ( ( ')' ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1898:1: ( ')' )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1898:1: ( ')' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1899:1: ')'
            {
             before(grammarAccess.getTagsClauseAccess().getRightParenthesisKeyword_3()); 
            match(input,18,FOLLOW_18_in_rule__TagsClause__Group__33822); 
             after(grammarAccess.getTagsClauseAccess().getRightParenthesisKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__TagsClause__Group__3


    // $ANTLR start rule__Pointcut__Group__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1920:1: rule__Pointcut__Group__0 : ( 'aspect' ) rule__Pointcut__Group__1 ;
    public final void rule__Pointcut__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1924:1: ( ( 'aspect' ) rule__Pointcut__Group__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1925:1: ( 'aspect' ) rule__Pointcut__Group__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1925:1: ( 'aspect' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1926:1: 'aspect'
            {
             before(grammarAccess.getPointcutAccess().getAspectKeyword_0()); 
            match(input,27,FOLLOW_27_in_rule__Pointcut__Group__03866); 
             after(grammarAccess.getPointcutAccess().getAspectKeyword_0()); 

            }

            pushFollow(FOLLOW_rule__Pointcut__Group__1_in_rule__Pointcut__Group__03876);
            rule__Pointcut__Group__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Pointcut__Group__0


    // $ANTLR start rule__Pointcut__Group__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1940:1: rule__Pointcut__Group__1 : ( '{' ) rule__Pointcut__Group__2 ;
    public final void rule__Pointcut__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1944:1: ( ( '{' ) rule__Pointcut__Group__2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1945:1: ( '{' ) rule__Pointcut__Group__2
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1945:1: ( '{' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1946:1: '{'
            {
             before(grammarAccess.getPointcutAccess().getLeftCurlyBracketKeyword_1()); 
            match(input,13,FOLLOW_13_in_rule__Pointcut__Group__13905); 
             after(grammarAccess.getPointcutAccess().getLeftCurlyBracketKeyword_1()); 

            }

            pushFollow(FOLLOW_rule__Pointcut__Group__2_in_rule__Pointcut__Group__13915);
            rule__Pointcut__Group__2();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Pointcut__Group__1


    // $ANTLR start rule__Pointcut__Group__2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1960:1: rule__Pointcut__Group__2 : ( ( rule__Pointcut__MatchesAssignment_2 )* ) rule__Pointcut__Group__3 ;
    public final void rule__Pointcut__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1964:1: ( ( ( rule__Pointcut__MatchesAssignment_2 )* ) rule__Pointcut__Group__3 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1965:1: ( ( rule__Pointcut__MatchesAssignment_2 )* ) rule__Pointcut__Group__3
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1965:1: ( ( rule__Pointcut__MatchesAssignment_2 )* )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1966:1: ( rule__Pointcut__MatchesAssignment_2 )*
            {
             before(grammarAccess.getPointcutAccess().getMatchesAssignment_2()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1967:1: ( rule__Pointcut__MatchesAssignment_2 )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==11||LA21_0==28||LA21_0==32) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1967:2: rule__Pointcut__MatchesAssignment_2
            	    {
            	    pushFollow(FOLLOW_rule__Pointcut__MatchesAssignment_2_in_rule__Pointcut__Group__23943);
            	    rule__Pointcut__MatchesAssignment_2();
            	    _fsp--;


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);

             after(grammarAccess.getPointcutAccess().getMatchesAssignment_2()); 

            }

            pushFollow(FOLLOW_rule__Pointcut__Group__3_in_rule__Pointcut__Group__23953);
            rule__Pointcut__Group__3();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Pointcut__Group__2


    // $ANTLR start rule__Pointcut__Group__3
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1978:1: rule__Pointcut__Group__3 : ( '}' ) ;
    public final void rule__Pointcut__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1982:1: ( ( '}' ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1983:1: ( '}' )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1983:1: ( '}' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:1984:1: '}'
            {
             before(grammarAccess.getPointcutAccess().getRightCurlyBracketKeyword_3()); 
            match(input,14,FOLLOW_14_in_rule__Pointcut__Group__33982); 
             after(grammarAccess.getPointcutAccess().getRightCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Pointcut__Group__3


    // $ANTLR start rule__ExactNameMatch__Group__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2005:1: rule__ExactNameMatch__Group__0 : ( 'name' ) rule__ExactNameMatch__Group__1 ;
    public final void rule__ExactNameMatch__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2009:1: ( ( 'name' ) rule__ExactNameMatch__Group__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2010:1: ( 'name' ) rule__ExactNameMatch__Group__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2010:1: ( 'name' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2011:1: 'name'
            {
             before(grammarAccess.getExactNameMatchAccess().getNameKeyword_0()); 
            match(input,28,FOLLOW_28_in_rule__ExactNameMatch__Group__04026); 
             after(grammarAccess.getExactNameMatchAccess().getNameKeyword_0()); 

            }

            pushFollow(FOLLOW_rule__ExactNameMatch__Group__1_in_rule__ExactNameMatch__Group__04036);
            rule__ExactNameMatch__Group__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__ExactNameMatch__Group__0


    // $ANTLR start rule__ExactNameMatch__Group__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2025:1: rule__ExactNameMatch__Group__1 : ( '=' ) rule__ExactNameMatch__Group__2 ;
    public final void rule__ExactNameMatch__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2029:1: ( ( '=' ) rule__ExactNameMatch__Group__2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2030:1: ( '=' ) rule__ExactNameMatch__Group__2
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2030:1: ( '=' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2031:1: '='
            {
             before(grammarAccess.getExactNameMatchAccess().getEqualsSignKeyword_1()); 
            match(input,29,FOLLOW_29_in_rule__ExactNameMatch__Group__14065); 
             after(grammarAccess.getExactNameMatchAccess().getEqualsSignKeyword_1()); 

            }

            pushFollow(FOLLOW_rule__ExactNameMatch__Group__2_in_rule__ExactNameMatch__Group__14075);
            rule__ExactNameMatch__Group__2();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__ExactNameMatch__Group__1


    // $ANTLR start rule__ExactNameMatch__Group__2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2045:1: rule__ExactNameMatch__Group__2 : ( ( rule__ExactNameMatch__NameAssignment_2 ) ) ;
    public final void rule__ExactNameMatch__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2049:1: ( ( ( rule__ExactNameMatch__NameAssignment_2 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2050:1: ( ( rule__ExactNameMatch__NameAssignment_2 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2050:1: ( ( rule__ExactNameMatch__NameAssignment_2 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2051:1: ( rule__ExactNameMatch__NameAssignment_2 )
            {
             before(grammarAccess.getExactNameMatchAccess().getNameAssignment_2()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2052:1: ( rule__ExactNameMatch__NameAssignment_2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2052:2: rule__ExactNameMatch__NameAssignment_2
            {
            pushFollow(FOLLOW_rule__ExactNameMatch__NameAssignment_2_in_rule__ExactNameMatch__Group__24103);
            rule__ExactNameMatch__NameAssignment_2();
            _fsp--;


            }

             after(grammarAccess.getExactNameMatchAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__ExactNameMatch__Group__2


    // $ANTLR start rule__StartsWithNameMatch__Group__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2068:1: rule__StartsWithNameMatch__Group__0 : ( 'name' ) rule__StartsWithNameMatch__Group__1 ;
    public final void rule__StartsWithNameMatch__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2072:1: ( ( 'name' ) rule__StartsWithNameMatch__Group__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2073:1: ( 'name' ) rule__StartsWithNameMatch__Group__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2073:1: ( 'name' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2074:1: 'name'
            {
             before(grammarAccess.getStartsWithNameMatchAccess().getNameKeyword_0()); 
            match(input,28,FOLLOW_28_in_rule__StartsWithNameMatch__Group__04144); 
             after(grammarAccess.getStartsWithNameMatchAccess().getNameKeyword_0()); 

            }

            pushFollow(FOLLOW_rule__StartsWithNameMatch__Group__1_in_rule__StartsWithNameMatch__Group__04154);
            rule__StartsWithNameMatch__Group__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__StartsWithNameMatch__Group__0


    // $ANTLR start rule__StartsWithNameMatch__Group__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2088:1: rule__StartsWithNameMatch__Group__1 : ( 'startswith' ) rule__StartsWithNameMatch__Group__2 ;
    public final void rule__StartsWithNameMatch__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2092:1: ( ( 'startswith' ) rule__StartsWithNameMatch__Group__2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2093:1: ( 'startswith' ) rule__StartsWithNameMatch__Group__2
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2093:1: ( 'startswith' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2094:1: 'startswith'
            {
             before(grammarAccess.getStartsWithNameMatchAccess().getStartswithKeyword_1()); 
            match(input,30,FOLLOW_30_in_rule__StartsWithNameMatch__Group__14183); 
             after(grammarAccess.getStartsWithNameMatchAccess().getStartswithKeyword_1()); 

            }

            pushFollow(FOLLOW_rule__StartsWithNameMatch__Group__2_in_rule__StartsWithNameMatch__Group__14193);
            rule__StartsWithNameMatch__Group__2();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__StartsWithNameMatch__Group__1


    // $ANTLR start rule__StartsWithNameMatch__Group__2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2108:1: rule__StartsWithNameMatch__Group__2 : ( ( rule__StartsWithNameMatch__NameAssignment_2 ) ) ;
    public final void rule__StartsWithNameMatch__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2112:1: ( ( ( rule__StartsWithNameMatch__NameAssignment_2 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2113:1: ( ( rule__StartsWithNameMatch__NameAssignment_2 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2113:1: ( ( rule__StartsWithNameMatch__NameAssignment_2 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2114:1: ( rule__StartsWithNameMatch__NameAssignment_2 )
            {
             before(grammarAccess.getStartsWithNameMatchAccess().getNameAssignment_2()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2115:1: ( rule__StartsWithNameMatch__NameAssignment_2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2115:2: rule__StartsWithNameMatch__NameAssignment_2
            {
            pushFollow(FOLLOW_rule__StartsWithNameMatch__NameAssignment_2_in_rule__StartsWithNameMatch__Group__24221);
            rule__StartsWithNameMatch__NameAssignment_2();
            _fsp--;


            }

             after(grammarAccess.getStartsWithNameMatchAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__StartsWithNameMatch__Group__2


    // $ANTLR start rule__EndsWithNameMatch__Group__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2131:1: rule__EndsWithNameMatch__Group__0 : ( 'name' ) rule__EndsWithNameMatch__Group__1 ;
    public final void rule__EndsWithNameMatch__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2135:1: ( ( 'name' ) rule__EndsWithNameMatch__Group__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2136:1: ( 'name' ) rule__EndsWithNameMatch__Group__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2136:1: ( 'name' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2137:1: 'name'
            {
             before(grammarAccess.getEndsWithNameMatchAccess().getNameKeyword_0()); 
            match(input,28,FOLLOW_28_in_rule__EndsWithNameMatch__Group__04262); 
             after(grammarAccess.getEndsWithNameMatchAccess().getNameKeyword_0()); 

            }

            pushFollow(FOLLOW_rule__EndsWithNameMatch__Group__1_in_rule__EndsWithNameMatch__Group__04272);
            rule__EndsWithNameMatch__Group__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__EndsWithNameMatch__Group__0


    // $ANTLR start rule__EndsWithNameMatch__Group__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2151:1: rule__EndsWithNameMatch__Group__1 : ( 'endswith' ) rule__EndsWithNameMatch__Group__2 ;
    public final void rule__EndsWithNameMatch__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2155:1: ( ( 'endswith' ) rule__EndsWithNameMatch__Group__2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2156:1: ( 'endswith' ) rule__EndsWithNameMatch__Group__2
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2156:1: ( 'endswith' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2157:1: 'endswith'
            {
             before(grammarAccess.getEndsWithNameMatchAccess().getEndswithKeyword_1()); 
            match(input,31,FOLLOW_31_in_rule__EndsWithNameMatch__Group__14301); 
             after(grammarAccess.getEndsWithNameMatchAccess().getEndswithKeyword_1()); 

            }

            pushFollow(FOLLOW_rule__EndsWithNameMatch__Group__2_in_rule__EndsWithNameMatch__Group__14311);
            rule__EndsWithNameMatch__Group__2();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__EndsWithNameMatch__Group__1


    // $ANTLR start rule__EndsWithNameMatch__Group__2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2171:1: rule__EndsWithNameMatch__Group__2 : ( ( rule__EndsWithNameMatch__NameAssignment_2 ) ) ;
    public final void rule__EndsWithNameMatch__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2175:1: ( ( ( rule__EndsWithNameMatch__NameAssignment_2 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2176:1: ( ( rule__EndsWithNameMatch__NameAssignment_2 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2176:1: ( ( rule__EndsWithNameMatch__NameAssignment_2 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2177:1: ( rule__EndsWithNameMatch__NameAssignment_2 )
            {
             before(grammarAccess.getEndsWithNameMatchAccess().getNameAssignment_2()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2178:1: ( rule__EndsWithNameMatch__NameAssignment_2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2178:2: rule__EndsWithNameMatch__NameAssignment_2
            {
            pushFollow(FOLLOW_rule__EndsWithNameMatch__NameAssignment_2_in_rule__EndsWithNameMatch__Group__24339);
            rule__EndsWithNameMatch__NameAssignment_2();
            _fsp--;


            }

             after(grammarAccess.getEndsWithNameMatchAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__EndsWithNameMatch__Group__2


    // $ANTLR start rule__TagMatch__Group__0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2194:1: rule__TagMatch__Group__0 : ( 'tag' ) rule__TagMatch__Group__1 ;
    public final void rule__TagMatch__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2198:1: ( ( 'tag' ) rule__TagMatch__Group__1 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2199:1: ( 'tag' ) rule__TagMatch__Group__1
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2199:1: ( 'tag' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2200:1: 'tag'
            {
             before(grammarAccess.getTagMatchAccess().getTagKeyword_0()); 
            match(input,32,FOLLOW_32_in_rule__TagMatch__Group__04380); 
             after(grammarAccess.getTagMatchAccess().getTagKeyword_0()); 

            }

            pushFollow(FOLLOW_rule__TagMatch__Group__1_in_rule__TagMatch__Group__04390);
            rule__TagMatch__Group__1();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__TagMatch__Group__0


    // $ANTLR start rule__TagMatch__Group__1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2214:1: rule__TagMatch__Group__1 : ( '=' ) rule__TagMatch__Group__2 ;
    public final void rule__TagMatch__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2218:1: ( ( '=' ) rule__TagMatch__Group__2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2219:1: ( '=' ) rule__TagMatch__Group__2
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2219:1: ( '=' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2220:1: '='
            {
             before(grammarAccess.getTagMatchAccess().getEqualsSignKeyword_1()); 
            match(input,29,FOLLOW_29_in_rule__TagMatch__Group__14419); 
             after(grammarAccess.getTagMatchAccess().getEqualsSignKeyword_1()); 

            }

            pushFollow(FOLLOW_rule__TagMatch__Group__2_in_rule__TagMatch__Group__14429);
            rule__TagMatch__Group__2();
            _fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__TagMatch__Group__1


    // $ANTLR start rule__TagMatch__Group__2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2234:1: rule__TagMatch__Group__2 : ( ( rule__TagMatch__NameAssignment_2 ) ) ;
    public final void rule__TagMatch__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2238:1: ( ( ( rule__TagMatch__NameAssignment_2 ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2239:1: ( ( rule__TagMatch__NameAssignment_2 ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2239:1: ( ( rule__TagMatch__NameAssignment_2 ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2240:1: ( rule__TagMatch__NameAssignment_2 )
            {
             before(grammarAccess.getTagMatchAccess().getNameAssignment_2()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2241:1: ( rule__TagMatch__NameAssignment_2 )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2241:2: rule__TagMatch__NameAssignment_2
            {
            pushFollow(FOLLOW_rule__TagMatch__NameAssignment_2_in_rule__TagMatch__Group__24457);
            rule__TagMatch__NameAssignment_2();
            _fsp--;


            }

             after(grammarAccess.getTagMatchAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__TagMatch__Group__2


    // $ANTLR start rule__System__FeatureModelAssignment_0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2257:1: rule__System__FeatureModelAssignment_0 : ( ruleFeatureModelImport ) ;
    public final void rule__System__FeatureModelAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2261:1: ( ( ruleFeatureModelImport ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2262:1: ( ruleFeatureModelImport )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2262:1: ( ruleFeatureModelImport )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2263:1: ruleFeatureModelImport
            {
             before(grammarAccess.getSystemAccess().getFeatureModelFeatureModelImportParserRuleCall_0_0()); 
            pushFollow(FOLLOW_ruleFeatureModelImport_in_rule__System__FeatureModelAssignment_04497);
            ruleFeatureModelImport();
            _fsp--;

             after(grammarAccess.getSystemAccess().getFeatureModelFeatureModelImportParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__System__FeatureModelAssignment_0


    // $ANTLR start rule__System__EntitiesAssignment_1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2272:1: rule__System__EntitiesAssignment_1 : ( ruleEntity ) ;
    public final void rule__System__EntitiesAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2276:1: ( ( ruleEntity ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2277:1: ( ruleEntity )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2277:1: ( ruleEntity )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2278:1: ruleEntity
            {
             before(grammarAccess.getSystemAccess().getEntitiesEntityParserRuleCall_1_0()); 
            pushFollow(FOLLOW_ruleEntity_in_rule__System__EntitiesAssignment_14528);
            ruleEntity();
            _fsp--;

             after(grammarAccess.getSystemAccess().getEntitiesEntityParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__System__EntitiesAssignment_1


    // $ANTLR start rule__Entity__PointcutAssignment_0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2287:1: rule__Entity__PointcutAssignment_0 : ( rulePointcut ) ;
    public final void rule__Entity__PointcutAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2291:1: ( ( rulePointcut ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2292:1: ( rulePointcut )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2292:1: ( rulePointcut )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2293:1: rulePointcut
            {
             before(grammarAccess.getEntityAccess().getPointcutPointcutParserRuleCall_0_0()); 
            pushFollow(FOLLOW_rulePointcut_in_rule__Entity__PointcutAssignment_04559);
            rulePointcut();
            _fsp--;

             after(grammarAccess.getEntityAccess().getPointcutPointcutParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Entity__PointcutAssignment_0


    // $ANTLR start rule__Entity__NameAssignment_2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2302:1: rule__Entity__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__Entity__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2306:1: ( ( RULE_ID ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2307:1: ( RULE_ID )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2307:1: ( RULE_ID )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2308:1: RULE_ID
            {
             before(grammarAccess.getEntityAccess().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Entity__NameAssignment_24590); 
             after(grammarAccess.getEntityAccess().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Entity__NameAssignment_2


    // $ANTLR start rule__Entity__TagsAssignment_3
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2317:1: rule__Entity__TagsAssignment_3 : ( ruleTagsClause ) ;
    public final void rule__Entity__TagsAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2321:1: ( ( ruleTagsClause ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2322:1: ( ruleTagsClause )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2322:1: ( ruleTagsClause )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2323:1: ruleTagsClause
            {
             before(grammarAccess.getEntityAccess().getTagsTagsClauseParserRuleCall_3_0()); 
            pushFollow(FOLLOW_ruleTagsClause_in_rule__Entity__TagsAssignment_34621);
            ruleTagsClause();
            _fsp--;

             after(grammarAccess.getEntityAccess().getTagsTagsClauseParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Entity__TagsAssignment_3


    // $ANTLR start rule__Entity__FeatureClauseAssignment_4
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2332:1: rule__Entity__FeatureClauseAssignment_4 : ( ruleFeatureClause ) ;
    public final void rule__Entity__FeatureClauseAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2336:1: ( ( ruleFeatureClause ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2337:1: ( ruleFeatureClause )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2337:1: ( ruleFeatureClause )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2338:1: ruleFeatureClause
            {
             before(grammarAccess.getEntityAccess().getFeatureClauseFeatureClauseParserRuleCall_4_0()); 
            pushFollow(FOLLOW_ruleFeatureClause_in_rule__Entity__FeatureClauseAssignment_44652);
            ruleFeatureClause();
            _fsp--;

             after(grammarAccess.getEntityAccess().getFeatureClauseFeatureClauseParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Entity__FeatureClauseAssignment_4


    // $ANTLR start rule__Entity__AttributesAssignment_6
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2347:1: rule__Entity__AttributesAssignment_6 : ( ruleAttribute ) ;
    public final void rule__Entity__AttributesAssignment_6() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2351:1: ( ( ruleAttribute ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2352:1: ( ruleAttribute )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2352:1: ( ruleAttribute )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2353:1: ruleAttribute
            {
             before(grammarAccess.getEntityAccess().getAttributesAttributeParserRuleCall_6_0()); 
            pushFollow(FOLLOW_ruleAttribute_in_rule__Entity__AttributesAssignment_64683);
            ruleAttribute();
            _fsp--;

             after(grammarAccess.getEntityAccess().getAttributesAttributeParserRuleCall_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Entity__AttributesAssignment_6


    // $ANTLR start rule__Attribute__NameAssignment_0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2362:1: rule__Attribute__NameAssignment_0 : ( RULE_ID ) ;
    public final void rule__Attribute__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2366:1: ( ( RULE_ID ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2367:1: ( RULE_ID )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2367:1: ( RULE_ID )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2368:1: RULE_ID
            {
             before(grammarAccess.getAttributeAccess().getNameIDTerminalRuleCall_0_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Attribute__NameAssignment_04714); 
             after(grammarAccess.getAttributeAccess().getNameIDTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Attribute__NameAssignment_0


    // $ANTLR start rule__Attribute__TypeAssignment_2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2377:1: rule__Attribute__TypeAssignment_2 : ( RULE_ID ) ;
    public final void rule__Attribute__TypeAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2381:1: ( ( RULE_ID ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2382:1: ( RULE_ID )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2382:1: ( RULE_ID )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2383:1: RULE_ID
            {
             before(grammarAccess.getAttributeAccess().getTypeIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Attribute__TypeAssignment_24745); 
             after(grammarAccess.getAttributeAccess().getTypeIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Attribute__TypeAssignment_2


    // $ANTLR start rule__Attribute__FeatureClauseAssignment_3
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2392:1: rule__Attribute__FeatureClauseAssignment_3 : ( ruleFeatureClause ) ;
    public final void rule__Attribute__FeatureClauseAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2396:1: ( ( ruleFeatureClause ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2397:1: ( ruleFeatureClause )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2397:1: ( ruleFeatureClause )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2398:1: ruleFeatureClause
            {
             before(grammarAccess.getAttributeAccess().getFeatureClauseFeatureClauseParserRuleCall_3_0()); 
            pushFollow(FOLLOW_ruleFeatureClause_in_rule__Attribute__FeatureClauseAssignment_34776);
            ruleFeatureClause();
            _fsp--;

             after(grammarAccess.getAttributeAccess().getFeatureClauseFeatureClauseParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Attribute__FeatureClauseAssignment_3


    // $ANTLR start rule__FeatureAndList__RetainedAssignment_1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2407:1: rule__FeatureAndList__RetainedAssignment_1 : ( ( 'retain' ) ) ;
    public final void rule__FeatureAndList__RetainedAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2411:1: ( ( ( 'retain' ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2412:1: ( ( 'retain' ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2412:1: ( ( 'retain' ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2413:1: ( 'retain' )
            {
             before(grammarAccess.getFeatureAndListAccess().getRetainedRetainKeyword_1_0()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2414:1: ( 'retain' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2415:1: 'retain'
            {
             before(grammarAccess.getFeatureAndListAccess().getRetainedRetainKeyword_1_0()); 
            match(input,33,FOLLOW_33_in_rule__FeatureAndList__RetainedAssignment_14812); 
             after(grammarAccess.getFeatureAndListAccess().getRetainedRetainKeyword_1_0()); 

            }

             after(grammarAccess.getFeatureAndListAccess().getRetainedRetainKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureAndList__RetainedAssignment_1


    // $ANTLR start rule__FeatureAndList__FeatureListAssignment_3
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2430:1: rule__FeatureAndList__FeatureListAssignment_3 : ( RULE_ID ) ;
    public final void rule__FeatureAndList__FeatureListAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2434:1: ( ( RULE_ID ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2435:1: ( RULE_ID )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2435:1: ( RULE_ID )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2436:1: RULE_ID
            {
             before(grammarAccess.getFeatureAndListAccess().getFeatureListIDTerminalRuleCall_3_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__FeatureAndList__FeatureListAssignment_34851); 
             after(grammarAccess.getFeatureAndListAccess().getFeatureListIDTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureAndList__FeatureListAssignment_3


    // $ANTLR start rule__FeatureAndList__FeatureListAssignment_4_1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2445:1: rule__FeatureAndList__FeatureListAssignment_4_1 : ( RULE_ID ) ;
    public final void rule__FeatureAndList__FeatureListAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2449:1: ( ( RULE_ID ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2450:1: ( RULE_ID )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2450:1: ( RULE_ID )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2451:1: RULE_ID
            {
             before(grammarAccess.getFeatureAndListAccess().getFeatureListIDTerminalRuleCall_4_1_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__FeatureAndList__FeatureListAssignment_4_14882); 
             after(grammarAccess.getFeatureAndListAccess().getFeatureListIDTerminalRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureAndList__FeatureListAssignment_4_1


    // $ANTLR start rule__FeatureOrList__RetainedAssignment_1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2460:1: rule__FeatureOrList__RetainedAssignment_1 : ( ( 'retain' ) ) ;
    public final void rule__FeatureOrList__RetainedAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2464:1: ( ( ( 'retain' ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2465:1: ( ( 'retain' ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2465:1: ( ( 'retain' ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2466:1: ( 'retain' )
            {
             before(grammarAccess.getFeatureOrListAccess().getRetainedRetainKeyword_1_0()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2467:1: ( 'retain' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2468:1: 'retain'
            {
             before(grammarAccess.getFeatureOrListAccess().getRetainedRetainKeyword_1_0()); 
            match(input,33,FOLLOW_33_in_rule__FeatureOrList__RetainedAssignment_14918); 
             after(grammarAccess.getFeatureOrListAccess().getRetainedRetainKeyword_1_0()); 

            }

             after(grammarAccess.getFeatureOrListAccess().getRetainedRetainKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureOrList__RetainedAssignment_1


    // $ANTLR start rule__FeatureOrList__FeatureListAssignment_3
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2483:1: rule__FeatureOrList__FeatureListAssignment_3 : ( RULE_ID ) ;
    public final void rule__FeatureOrList__FeatureListAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2487:1: ( ( RULE_ID ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2488:1: ( RULE_ID )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2488:1: ( RULE_ID )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2489:1: RULE_ID
            {
             before(grammarAccess.getFeatureOrListAccess().getFeatureListIDTerminalRuleCall_3_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__FeatureOrList__FeatureListAssignment_34957); 
             after(grammarAccess.getFeatureOrListAccess().getFeatureListIDTerminalRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureOrList__FeatureListAssignment_3


    // $ANTLR start rule__FeatureOrList__FeatureListAssignment_4_1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2498:1: rule__FeatureOrList__FeatureListAssignment_4_1 : ( RULE_ID ) ;
    public final void rule__FeatureOrList__FeatureListAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2502:1: ( ( RULE_ID ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2503:1: ( RULE_ID )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2503:1: ( RULE_ID )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2504:1: RULE_ID
            {
             before(grammarAccess.getFeatureOrListAccess().getFeatureListIDTerminalRuleCall_4_1_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__FeatureOrList__FeatureListAssignment_4_14988); 
             after(grammarAccess.getFeatureOrListAccess().getFeatureListIDTerminalRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureOrList__FeatureListAssignment_4_1


    // $ANTLR start rule__FeatureExpression__RetainedAssignment_1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2513:1: rule__FeatureExpression__RetainedAssignment_1 : ( ( 'retain' ) ) ;
    public final void rule__FeatureExpression__RetainedAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2517:1: ( ( ( 'retain' ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2518:1: ( ( 'retain' ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2518:1: ( ( 'retain' ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2519:1: ( 'retain' )
            {
             before(grammarAccess.getFeatureExpressionAccess().getRetainedRetainKeyword_1_0()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2520:1: ( 'retain' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2521:1: 'retain'
            {
             before(grammarAccess.getFeatureExpressionAccess().getRetainedRetainKeyword_1_0()); 
            match(input,33,FOLLOW_33_in_rule__FeatureExpression__RetainedAssignment_15024); 
             after(grammarAccess.getFeatureExpressionAccess().getRetainedRetainKeyword_1_0()); 

            }

             after(grammarAccess.getFeatureExpressionAccess().getRetainedRetainKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureExpression__RetainedAssignment_1


    // $ANTLR start rule__FeatureExpression__ExpressionAssignment_3
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2536:1: rule__FeatureExpression__ExpressionAssignment_3 : ( ruleOrExpression ) ;
    public final void rule__FeatureExpression__ExpressionAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2540:1: ( ( ruleOrExpression ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2541:1: ( ruleOrExpression )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2541:1: ( ruleOrExpression )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2542:1: ruleOrExpression
            {
             before(grammarAccess.getFeatureExpressionAccess().getExpressionOrExpressionParserRuleCall_3_0()); 
            pushFollow(FOLLOW_ruleOrExpression_in_rule__FeatureExpression__ExpressionAssignment_35063);
            ruleOrExpression();
            _fsp--;

             after(grammarAccess.getFeatureExpressionAccess().getExpressionOrExpressionParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureExpression__ExpressionAssignment_3


    // $ANTLR start rule__Feature__RetainedAssignment_1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2551:1: rule__Feature__RetainedAssignment_1 : ( ( 'retain' ) ) ;
    public final void rule__Feature__RetainedAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2555:1: ( ( ( 'retain' ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2556:1: ( ( 'retain' ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2556:1: ( ( 'retain' ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2557:1: ( 'retain' )
            {
             before(grammarAccess.getFeatureAccess().getRetainedRetainKeyword_1_0()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2558:1: ( 'retain' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2559:1: 'retain'
            {
             before(grammarAccess.getFeatureAccess().getRetainedRetainKeyword_1_0()); 
            match(input,33,FOLLOW_33_in_rule__Feature__RetainedAssignment_15099); 
             after(grammarAccess.getFeatureAccess().getRetainedRetainKeyword_1_0()); 

            }

             after(grammarAccess.getFeatureAccess().getRetainedRetainKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Feature__RetainedAssignment_1


    // $ANTLR start rule__Feature__FeatureAssignment_2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2574:1: rule__Feature__FeatureAssignment_2 : ( RULE_ID ) ;
    public final void rule__Feature__FeatureAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2578:1: ( ( RULE_ID ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2579:1: ( RULE_ID )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2579:1: ( RULE_ID )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2580:1: RULE_ID
            {
             before(grammarAccess.getFeatureAccess().getFeatureIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Feature__FeatureAssignment_25138); 
             after(grammarAccess.getFeatureAccess().getFeatureIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Feature__FeatureAssignment_2


    // $ANTLR start rule__OrExpression__OperandsAssignment_0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2589:1: rule__OrExpression__OperandsAssignment_0 : ( ruleAndExpression ) ;
    public final void rule__OrExpression__OperandsAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2593:1: ( ( ruleAndExpression ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2594:1: ( ruleAndExpression )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2594:1: ( ruleAndExpression )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2595:1: ruleAndExpression
            {
             before(grammarAccess.getOrExpressionAccess().getOperandsAndExpressionParserRuleCall_0_0()); 
            pushFollow(FOLLOW_ruleAndExpression_in_rule__OrExpression__OperandsAssignment_05169);
            ruleAndExpression();
            _fsp--;

             after(grammarAccess.getOrExpressionAccess().getOperandsAndExpressionParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__OrExpression__OperandsAssignment_0


    // $ANTLR start rule__OrExpression__OperandsAssignment_1_1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2604:1: rule__OrExpression__OperandsAssignment_1_1 : ( ruleAndExpression ) ;
    public final void rule__OrExpression__OperandsAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2608:1: ( ( ruleAndExpression ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2609:1: ( ruleAndExpression )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2609:1: ( ruleAndExpression )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2610:1: ruleAndExpression
            {
             before(grammarAccess.getOrExpressionAccess().getOperandsAndExpressionParserRuleCall_1_1_0()); 
            pushFollow(FOLLOW_ruleAndExpression_in_rule__OrExpression__OperandsAssignment_1_15200);
            ruleAndExpression();
            _fsp--;

             after(grammarAccess.getOrExpressionAccess().getOperandsAndExpressionParserRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__OrExpression__OperandsAssignment_1_1


    // $ANTLR start rule__AndExpression__OperandsAssignment_0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2619:1: rule__AndExpression__OperandsAssignment_0 : ( ruleOperand ) ;
    public final void rule__AndExpression__OperandsAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2623:1: ( ( ruleOperand ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2624:1: ( ruleOperand )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2624:1: ( ruleOperand )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2625:1: ruleOperand
            {
             before(grammarAccess.getAndExpressionAccess().getOperandsOperandParserRuleCall_0_0()); 
            pushFollow(FOLLOW_ruleOperand_in_rule__AndExpression__OperandsAssignment_05231);
            ruleOperand();
            _fsp--;

             after(grammarAccess.getAndExpressionAccess().getOperandsOperandParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__AndExpression__OperandsAssignment_0


    // $ANTLR start rule__AndExpression__OperandsAssignment_1_1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2634:1: rule__AndExpression__OperandsAssignment_1_1 : ( ruleOperand ) ;
    public final void rule__AndExpression__OperandsAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2638:1: ( ( ruleOperand ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2639:1: ( ruleOperand )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2639:1: ( ruleOperand )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2640:1: ruleOperand
            {
             before(grammarAccess.getAndExpressionAccess().getOperandsOperandParserRuleCall_1_1_0()); 
            pushFollow(FOLLOW_ruleOperand_in_rule__AndExpression__OperandsAssignment_1_15262);
            ruleOperand();
            _fsp--;

             after(grammarAccess.getAndExpressionAccess().getOperandsOperandParserRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__AndExpression__OperandsAssignment_1_1


    // $ANTLR start rule__Operand__IsNotAssignment_0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2649:1: rule__Operand__IsNotAssignment_0 : ( ( 'not' ) ) ;
    public final void rule__Operand__IsNotAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2653:1: ( ( ( 'not' ) ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2654:1: ( ( 'not' ) )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2654:1: ( ( 'not' ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2655:1: ( 'not' )
            {
             before(grammarAccess.getOperandAccess().getIsNotNotKeyword_0_0()); 
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2656:1: ( 'not' )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2657:1: 'not'
            {
             before(grammarAccess.getOperandAccess().getIsNotNotKeyword_0_0()); 
            match(input,34,FOLLOW_34_in_rule__Operand__IsNotAssignment_05298); 
             after(grammarAccess.getOperandAccess().getIsNotNotKeyword_0_0()); 

            }

             after(grammarAccess.getOperandAccess().getIsNotNotKeyword_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Operand__IsNotAssignment_0


    // $ANTLR start rule__Operand__ExpressionAssignment_1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2672:1: rule__Operand__ExpressionAssignment_1 : ( ruleAtom ) ;
    public final void rule__Operand__ExpressionAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2676:1: ( ( ruleAtom ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2677:1: ( ruleAtom )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2677:1: ( ruleAtom )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2678:1: ruleAtom
            {
             before(grammarAccess.getOperandAccess().getExpressionAtomParserRuleCall_1_0()); 
            pushFollow(FOLLOW_ruleAtom_in_rule__Operand__ExpressionAssignment_15337);
            ruleAtom();
            _fsp--;

             after(grammarAccess.getOperandAccess().getExpressionAtomParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Operand__ExpressionAssignment_1


    // $ANTLR start rule__Atom__FeatureAssignment_0
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2687:1: rule__Atom__FeatureAssignment_0 : ( RULE_ID ) ;
    public final void rule__Atom__FeatureAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2691:1: ( ( RULE_ID ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2692:1: ( RULE_ID )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2692:1: ( RULE_ID )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2693:1: RULE_ID
            {
             before(grammarAccess.getAtomAccess().getFeatureIDTerminalRuleCall_0_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Atom__FeatureAssignment_05368); 
             after(grammarAccess.getAtomAccess().getFeatureIDTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Atom__FeatureAssignment_0


    // $ANTLR start rule__Atom__ExpressionAssignment_1_1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2702:1: rule__Atom__ExpressionAssignment_1_1 : ( ruleOrExpression ) ;
    public final void rule__Atom__ExpressionAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2706:1: ( ( ruleOrExpression ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2707:1: ( ruleOrExpression )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2707:1: ( ruleOrExpression )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2708:1: ruleOrExpression
            {
             before(grammarAccess.getAtomAccess().getExpressionOrExpressionParserRuleCall_1_1_0()); 
            pushFollow(FOLLOW_ruleOrExpression_in_rule__Atom__ExpressionAssignment_1_15399);
            ruleOrExpression();
            _fsp--;

             after(grammarAccess.getAtomAccess().getExpressionOrExpressionParserRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Atom__ExpressionAssignment_1_1


    // $ANTLR start rule__FeatureModelImport__ImportURIAssignment_1
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2717:1: rule__FeatureModelImport__ImportURIAssignment_1 : ( RULE_STRING ) ;
    public final void rule__FeatureModelImport__ImportURIAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2721:1: ( ( RULE_STRING ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2722:1: ( RULE_STRING )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2722:1: ( RULE_STRING )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2723:1: RULE_STRING
            {
             before(grammarAccess.getFeatureModelImportAccess().getImportURISTRINGTerminalRuleCall_1_0()); 
            match(input,RULE_STRING,FOLLOW_RULE_STRING_in_rule__FeatureModelImport__ImportURIAssignment_15430); 
             after(grammarAccess.getFeatureModelImportAccess().getImportURISTRINGTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__FeatureModelImport__ImportURIAssignment_1


    // $ANTLR start rule__TagsClause__TagsAssignment_2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2732:1: rule__TagsClause__TagsAssignment_2 : ( ruleTag ) ;
    public final void rule__TagsClause__TagsAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2736:1: ( ( ruleTag ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2737:1: ( ruleTag )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2737:1: ( ruleTag )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2738:1: ruleTag
            {
             before(grammarAccess.getTagsClauseAccess().getTagsTagParserRuleCall_2_0()); 
            pushFollow(FOLLOW_ruleTag_in_rule__TagsClause__TagsAssignment_25461);
            ruleTag();
            _fsp--;

             after(grammarAccess.getTagsClauseAccess().getTagsTagParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__TagsClause__TagsAssignment_2


    // $ANTLR start rule__Tag__NameAssignment
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2747:1: rule__Tag__NameAssignment : ( RULE_ID ) ;
    public final void rule__Tag__NameAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2751:1: ( ( RULE_ID ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2752:1: ( RULE_ID )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2752:1: ( RULE_ID )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2753:1: RULE_ID
            {
             before(grammarAccess.getTagAccess().getNameIDTerminalRuleCall_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Tag__NameAssignment5492); 
             after(grammarAccess.getTagAccess().getNameIDTerminalRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Tag__NameAssignment


    // $ANTLR start rule__Pointcut__MatchesAssignment_2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2762:1: rule__Pointcut__MatchesAssignment_2 : ( ruleMatch ) ;
    public final void rule__Pointcut__MatchesAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2766:1: ( ( ruleMatch ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2767:1: ( ruleMatch )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2767:1: ( ruleMatch )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2768:1: ruleMatch
            {
             before(grammarAccess.getPointcutAccess().getMatchesMatchParserRuleCall_2_0()); 
            pushFollow(FOLLOW_ruleMatch_in_rule__Pointcut__MatchesAssignment_25523);
            ruleMatch();
            _fsp--;

             after(grammarAccess.getPointcutAccess().getMatchesMatchParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__Pointcut__MatchesAssignment_2


    // $ANTLR start rule__ExactNameMatch__NameAssignment_2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2777:1: rule__ExactNameMatch__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__ExactNameMatch__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2781:1: ( ( RULE_ID ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2782:1: ( RULE_ID )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2782:1: ( RULE_ID )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2783:1: RULE_ID
            {
             before(grammarAccess.getExactNameMatchAccess().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__ExactNameMatch__NameAssignment_25554); 
             after(grammarAccess.getExactNameMatchAccess().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__ExactNameMatch__NameAssignment_2


    // $ANTLR start rule__StartsWithNameMatch__NameAssignment_2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2792:1: rule__StartsWithNameMatch__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__StartsWithNameMatch__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2796:1: ( ( RULE_ID ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2797:1: ( RULE_ID )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2797:1: ( RULE_ID )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2798:1: RULE_ID
            {
             before(grammarAccess.getStartsWithNameMatchAccess().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__StartsWithNameMatch__NameAssignment_25585); 
             after(grammarAccess.getStartsWithNameMatchAccess().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__StartsWithNameMatch__NameAssignment_2


    // $ANTLR start rule__EndsWithNameMatch__NameAssignment_2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2807:1: rule__EndsWithNameMatch__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__EndsWithNameMatch__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2811:1: ( ( RULE_ID ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2812:1: ( RULE_ID )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2812:1: ( RULE_ID )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2813:1: RULE_ID
            {
             before(grammarAccess.getEndsWithNameMatchAccess().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__EndsWithNameMatch__NameAssignment_25616); 
             after(grammarAccess.getEndsWithNameMatchAccess().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__EndsWithNameMatch__NameAssignment_2


    // $ANTLR start rule__TagMatch__NameAssignment_2
    // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2822:1: rule__TagMatch__NameAssignment_2 : ( RULE_ID ) ;
    public final void rule__TagMatch__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2826:1: ( ( RULE_ID ) )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2827:1: ( RULE_ID )
            {
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2827:1: ( RULE_ID )
            // ../org.xtext.example.mydsl.ui/src-gen/org/xtext/example/contentassist/antlr/internal/InternalMyDsl.g:2828:1: RULE_ID
            {
             before(grammarAccess.getTagMatchAccess().getNameIDTerminalRuleCall_2_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__TagMatch__NameAssignment_25647); 
             after(grammarAccess.getTagMatchAccess().getNameIDTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end rule__TagMatch__NameAssignment_2


 

    public static final BitSet FOLLOW_ruleSystem_in_entryRuleSystem60 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleSystem67 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__System__Group__0_in_ruleSystem94 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEntity_in_entryRuleEntity120 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleEntity127 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__Group__0_in_ruleEntity154 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAttribute_in_entryRuleAttribute180 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleAttribute187 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__Group__0_in_ruleAttribute214 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureClause_in_entryRuleFeatureClause240 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeatureClause247 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureClause__Alternatives_in_ruleFeatureClause274 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureAndList_in_entryRuleFeatureAndList300 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeatureAndList307 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureAndList__Group__0_in_ruleFeatureAndList334 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureOrList_in_entryRuleFeatureOrList360 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeatureOrList367 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureOrList__Group__0_in_ruleFeatureOrList394 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureExpression_in_entryRuleFeatureExpression420 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeatureExpression427 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureExpression__Group__0_in_ruleFeatureExpression454 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeature_in_entryRuleFeature480 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeature487 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__Group__0_in_ruleFeature514 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleOrExpression_in_entryRuleOrExpression540 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleOrExpression547 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__OrExpression__Group__0_in_ruleOrExpression574 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAndExpression_in_entryRuleAndExpression600 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleAndExpression607 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__AndExpression__Group__0_in_ruleAndExpression634 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleOperand_in_entryRuleOperand660 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleOperand667 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Operand__Group__0_in_ruleOperand694 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAtom_in_entryRuleAtom720 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleAtom727 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Atom__Alternatives_in_ruleAtom754 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureModelImport_in_entryRuleFeatureModelImport780 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeatureModelImport787 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureModelImport__Group__0_in_ruleFeatureModelImport814 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleTagsClause_in_entryRuleTagsClause840 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleTagsClause847 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__TagsClause__Group__0_in_ruleTagsClause874 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleTag_in_entryRuleTag900 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleTag907 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Tag__NameAssignment_in_ruleTag934 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePointcut_in_entryRulePointcut960 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRulePointcut967 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Pointcut__Group__0_in_rulePointcut994 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleMatch_in_entryRuleMatch1020 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleMatch1027 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Match__Alternatives_in_ruleMatch1054 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAllMatch_in_entryRuleAllMatch1080 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleAllMatch1087 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_11_in_ruleAllMatch1115 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExactNameMatch_in_entryRuleExactNameMatch1142 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleExactNameMatch1149 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ExactNameMatch__Group__0_in_ruleExactNameMatch1176 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleStartsWithNameMatch_in_entryRuleStartsWithNameMatch1202 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleStartsWithNameMatch1209 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__StartsWithNameMatch__Group__0_in_ruleStartsWithNameMatch1236 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEndsWithNameMatch_in_entryRuleEndsWithNameMatch1262 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleEndsWithNameMatch1269 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EndsWithNameMatch__Group__0_in_ruleEndsWithNameMatch1296 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleTagMatch_in_entryRuleTagMatch1322 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleTagMatch1329 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__TagMatch__Group__0_in_ruleTagMatch1356 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureAndList_in_rule__FeatureClause__Alternatives1392 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureOrList_in_rule__FeatureClause__Alternatives1409 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureExpression_in_rule__FeatureClause__Alternatives1426 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeature_in_rule__FeatureClause__Alternatives1443 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Atom__FeatureAssignment_0_in_rule__Atom__Alternatives1475 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Atom__Group_1__0_in_rule__Atom__Alternatives1493 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAllMatch_in_rule__Match__Alternatives1526 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExactNameMatch_in_rule__Match__Alternatives1543 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleStartsWithNameMatch_in_rule__Match__Alternatives1560 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEndsWithNameMatch_in_rule__Match__Alternatives1577 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleTagMatch_in_rule__Match__Alternatives1594 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__System__FeatureModelAssignment_0_in_rule__System__Group__01628 = new BitSet(new long[]{0x0000000008001002L});
    public static final BitSet FOLLOW_rule__System__Group__1_in_rule__System__Group__01638 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__System__EntitiesAssignment_1_in_rule__System__Group__11666 = new BitSet(new long[]{0x0000000008001002L});
    public static final BitSet FOLLOW_rule__Entity__PointcutAssignment_0_in_rule__Entity__Group__01705 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_rule__Entity__Group__1_in_rule__Entity__Group__01715 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_12_in_rule__Entity__Group__11744 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Entity__Group__2_in_rule__Entity__Group__11754 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__NameAssignment_2_in_rule__Entity__Group__21782 = new BitSet(new long[]{0x0000000004712000L});
    public static final BitSet FOLLOW_rule__Entity__Group__3_in_rule__Entity__Group__21791 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__TagsAssignment_3_in_rule__Entity__Group__31819 = new BitSet(new long[]{0x0000000000712000L});
    public static final BitSet FOLLOW_rule__Entity__Group__4_in_rule__Entity__Group__31829 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__FeatureClauseAssignment_4_in_rule__Entity__Group__41857 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_rule__Entity__Group__5_in_rule__Entity__Group__41867 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_rule__Entity__Group__51896 = new BitSet(new long[]{0x0000000000004010L});
    public static final BitSet FOLLOW_rule__Entity__Group__6_in_rule__Entity__Group__51906 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Entity__AttributesAssignment_6_in_rule__Entity__Group__61934 = new BitSet(new long[]{0x0000000000004010L});
    public static final BitSet FOLLOW_rule__Entity__Group__7_in_rule__Entity__Group__61944 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_14_in_rule__Entity__Group__71973 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__NameAssignment_0_in_rule__Attribute__Group__02024 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_rule__Attribute__Group__1_in_rule__Attribute__Group__02033 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_15_in_rule__Attribute__Group__12062 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Attribute__Group__2_in_rule__Attribute__Group__12072 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__TypeAssignment_2_in_rule__Attribute__Group__22100 = new BitSet(new long[]{0x0000000000710002L});
    public static final BitSet FOLLOW_rule__Attribute__Group__3_in_rule__Attribute__Group__22109 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Attribute__FeatureClauseAssignment_3_in_rule__Attribute__Group__32137 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_16_in_rule__FeatureAndList__Group__02181 = new BitSet(new long[]{0x0000000200020000L});
    public static final BitSet FOLLOW_rule__FeatureAndList__Group__1_in_rule__FeatureAndList__Group__02191 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureAndList__RetainedAssignment_1_in_rule__FeatureAndList__Group__12219 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_rule__FeatureAndList__Group__2_in_rule__FeatureAndList__Group__12229 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_17_in_rule__FeatureAndList__Group__22258 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__FeatureAndList__Group__3_in_rule__FeatureAndList__Group__22268 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureAndList__FeatureListAssignment_3_in_rule__FeatureAndList__Group__32296 = new BitSet(new long[]{0x00000000000C0000L});
    public static final BitSet FOLLOW_rule__FeatureAndList__Group__4_in_rule__FeatureAndList__Group__32305 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureAndList__Group_4__0_in_rule__FeatureAndList__Group__42333 = new BitSet(new long[]{0x00000000000C0000L});
    public static final BitSet FOLLOW_rule__FeatureAndList__Group__5_in_rule__FeatureAndList__Group__42343 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_18_in_rule__FeatureAndList__Group__52372 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_19_in_rule__FeatureAndList__Group_4__02420 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__FeatureAndList__Group_4__1_in_rule__FeatureAndList__Group_4__02430 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureAndList__FeatureListAssignment_4_1_in_rule__FeatureAndList__Group_4__12458 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_20_in_rule__FeatureOrList__Group__02497 = new BitSet(new long[]{0x0000000200020000L});
    public static final BitSet FOLLOW_rule__FeatureOrList__Group__1_in_rule__FeatureOrList__Group__02507 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureOrList__RetainedAssignment_1_in_rule__FeatureOrList__Group__12535 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_rule__FeatureOrList__Group__2_in_rule__FeatureOrList__Group__12545 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_17_in_rule__FeatureOrList__Group__22574 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__FeatureOrList__Group__3_in_rule__FeatureOrList__Group__22584 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureOrList__FeatureListAssignment_3_in_rule__FeatureOrList__Group__32612 = new BitSet(new long[]{0x00000000000C0000L});
    public static final BitSet FOLLOW_rule__FeatureOrList__Group__4_in_rule__FeatureOrList__Group__32621 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureOrList__Group_4__0_in_rule__FeatureOrList__Group__42649 = new BitSet(new long[]{0x00000000000C0000L});
    public static final BitSet FOLLOW_rule__FeatureOrList__Group__5_in_rule__FeatureOrList__Group__42659 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_18_in_rule__FeatureOrList__Group__52688 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_19_in_rule__FeatureOrList__Group_4__02736 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__FeatureOrList__Group_4__1_in_rule__FeatureOrList__Group_4__02746 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureOrList__FeatureListAssignment_4_1_in_rule__FeatureOrList__Group_4__12774 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_21_in_rule__FeatureExpression__Group__02813 = new BitSet(new long[]{0x0000000200020000L});
    public static final BitSet FOLLOW_rule__FeatureExpression__Group__1_in_rule__FeatureExpression__Group__02823 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureExpression__RetainedAssignment_1_in_rule__FeatureExpression__Group__12851 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_rule__FeatureExpression__Group__2_in_rule__FeatureExpression__Group__12861 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_17_in_rule__FeatureExpression__Group__22890 = new BitSet(new long[]{0x0000000400020010L});
    public static final BitSet FOLLOW_rule__FeatureExpression__Group__3_in_rule__FeatureExpression__Group__22900 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureExpression__ExpressionAssignment_3_in_rule__FeatureExpression__Group__32928 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_rule__FeatureExpression__Group__4_in_rule__FeatureExpression__Group__32937 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_18_in_rule__FeatureExpression__Group__42966 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_22_in_rule__Feature__Group__03012 = new BitSet(new long[]{0x0000000200000010L});
    public static final BitSet FOLLOW_rule__Feature__Group__1_in_rule__Feature__Group__03022 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__RetainedAssignment_1_in_rule__Feature__Group__13050 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Feature__Group__2_in_rule__Feature__Group__13060 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__FeatureAssignment_2_in_rule__Feature__Group__23088 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__OrExpression__OperandsAssignment_0_in_rule__OrExpression__Group__03128 = new BitSet(new long[]{0x0000000000800002L});
    public static final BitSet FOLLOW_rule__OrExpression__Group__1_in_rule__OrExpression__Group__03137 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__OrExpression__Group_1__0_in_rule__OrExpression__Group__13165 = new BitSet(new long[]{0x0000000000800002L});
    public static final BitSet FOLLOW_23_in_rule__OrExpression__Group_1__03205 = new BitSet(new long[]{0x0000000400020010L});
    public static final BitSet FOLLOW_rule__OrExpression__Group_1__1_in_rule__OrExpression__Group_1__03215 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__OrExpression__OperandsAssignment_1_1_in_rule__OrExpression__Group_1__13243 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__AndExpression__OperandsAssignment_0_in_rule__AndExpression__Group__03281 = new BitSet(new long[]{0x0000000001000002L});
    public static final BitSet FOLLOW_rule__AndExpression__Group__1_in_rule__AndExpression__Group__03290 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__AndExpression__Group_1__0_in_rule__AndExpression__Group__13318 = new BitSet(new long[]{0x0000000001000002L});
    public static final BitSet FOLLOW_24_in_rule__AndExpression__Group_1__03358 = new BitSet(new long[]{0x0000000400020010L});
    public static final BitSet FOLLOW_rule__AndExpression__Group_1__1_in_rule__AndExpression__Group_1__03368 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__AndExpression__OperandsAssignment_1_1_in_rule__AndExpression__Group_1__13396 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Operand__IsNotAssignment_0_in_rule__Operand__Group__03434 = new BitSet(new long[]{0x0000000000020010L});
    public static final BitSet FOLLOW_rule__Operand__Group__1_in_rule__Operand__Group__03444 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Operand__ExpressionAssignment_1_in_rule__Operand__Group__13472 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_17_in_rule__Atom__Group_1__03511 = new BitSet(new long[]{0x0000000400020010L});
    public static final BitSet FOLLOW_rule__Atom__Group_1__1_in_rule__Atom__Group_1__03521 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Atom__ExpressionAssignment_1_1_in_rule__Atom__Group_1__13549 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_rule__Atom__Group_1__2_in_rule__Atom__Group_1__13558 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_18_in_rule__Atom__Group_1__23587 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_25_in_rule__FeatureModelImport__Group__03629 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_rule__FeatureModelImport__Group__1_in_rule__FeatureModelImport__Group__03639 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureModelImport__ImportURIAssignment_1_in_rule__FeatureModelImport__Group__13667 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_26_in_rule__TagsClause__Group__03706 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_rule__TagsClause__Group__1_in_rule__TagsClause__Group__03716 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_17_in_rule__TagsClause__Group__13745 = new BitSet(new long[]{0x0000000000040010L});
    public static final BitSet FOLLOW_rule__TagsClause__Group__2_in_rule__TagsClause__Group__13755 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__TagsClause__TagsAssignment_2_in_rule__TagsClause__Group__23783 = new BitSet(new long[]{0x0000000000040010L});
    public static final BitSet FOLLOW_rule__TagsClause__Group__3_in_rule__TagsClause__Group__23793 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_18_in_rule__TagsClause__Group__33822 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_27_in_rule__Pointcut__Group__03866 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_rule__Pointcut__Group__1_in_rule__Pointcut__Group__03876 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_rule__Pointcut__Group__13905 = new BitSet(new long[]{0x0000000110004800L});
    public static final BitSet FOLLOW_rule__Pointcut__Group__2_in_rule__Pointcut__Group__13915 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Pointcut__MatchesAssignment_2_in_rule__Pointcut__Group__23943 = new BitSet(new long[]{0x0000000110004800L});
    public static final BitSet FOLLOW_rule__Pointcut__Group__3_in_rule__Pointcut__Group__23953 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_14_in_rule__Pointcut__Group__33982 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_28_in_rule__ExactNameMatch__Group__04026 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_rule__ExactNameMatch__Group__1_in_rule__ExactNameMatch__Group__04036 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_29_in_rule__ExactNameMatch__Group__14065 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__ExactNameMatch__Group__2_in_rule__ExactNameMatch__Group__14075 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ExactNameMatch__NameAssignment_2_in_rule__ExactNameMatch__Group__24103 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_28_in_rule__StartsWithNameMatch__Group__04144 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_rule__StartsWithNameMatch__Group__1_in_rule__StartsWithNameMatch__Group__04154 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_30_in_rule__StartsWithNameMatch__Group__14183 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__StartsWithNameMatch__Group__2_in_rule__StartsWithNameMatch__Group__14193 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__StartsWithNameMatch__NameAssignment_2_in_rule__StartsWithNameMatch__Group__24221 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_28_in_rule__EndsWithNameMatch__Group__04262 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_rule__EndsWithNameMatch__Group__1_in_rule__EndsWithNameMatch__Group__04272 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_31_in_rule__EndsWithNameMatch__Group__14301 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__EndsWithNameMatch__Group__2_in_rule__EndsWithNameMatch__Group__14311 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__EndsWithNameMatch__NameAssignment_2_in_rule__EndsWithNameMatch__Group__24339 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_32_in_rule__TagMatch__Group__04380 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_rule__TagMatch__Group__1_in_rule__TagMatch__Group__04390 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_29_in_rule__TagMatch__Group__14419 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__TagMatch__Group__2_in_rule__TagMatch__Group__14429 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__TagMatch__NameAssignment_2_in_rule__TagMatch__Group__24457 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureModelImport_in_rule__System__FeatureModelAssignment_04497 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEntity_in_rule__System__EntitiesAssignment_14528 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePointcut_in_rule__Entity__PointcutAssignment_04559 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Entity__NameAssignment_24590 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleTagsClause_in_rule__Entity__TagsAssignment_34621 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureClause_in_rule__Entity__FeatureClauseAssignment_44652 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAttribute_in_rule__Entity__AttributesAssignment_64683 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Attribute__NameAssignment_04714 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Attribute__TypeAssignment_24745 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureClause_in_rule__Attribute__FeatureClauseAssignment_34776 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_rule__FeatureAndList__RetainedAssignment_14812 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__FeatureAndList__FeatureListAssignment_34851 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__FeatureAndList__FeatureListAssignment_4_14882 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_rule__FeatureOrList__RetainedAssignment_14918 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__FeatureOrList__FeatureListAssignment_34957 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__FeatureOrList__FeatureListAssignment_4_14988 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_rule__FeatureExpression__RetainedAssignment_15024 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleOrExpression_in_rule__FeatureExpression__ExpressionAssignment_35063 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_rule__Feature__RetainedAssignment_15099 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Feature__FeatureAssignment_25138 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAndExpression_in_rule__OrExpression__OperandsAssignment_05169 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAndExpression_in_rule__OrExpression__OperandsAssignment_1_15200 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleOperand_in_rule__AndExpression__OperandsAssignment_05231 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleOperand_in_rule__AndExpression__OperandsAssignment_1_15262 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_34_in_rule__Operand__IsNotAssignment_05298 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAtom_in_rule__Operand__ExpressionAssignment_15337 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Atom__FeatureAssignment_05368 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleOrExpression_in_rule__Atom__ExpressionAssignment_1_15399 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_STRING_in_rule__FeatureModelImport__ImportURIAssignment_15430 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleTag_in_rule__TagsClause__TagsAssignment_25461 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Tag__NameAssignment5492 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleMatch_in_rule__Pointcut__MatchesAssignment_25523 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__ExactNameMatch__NameAssignment_25554 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__StartsWithNameMatch__NameAssignment_25585 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__EndsWithNameMatch__NameAssignment_25616 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__TagMatch__NameAssignment_25647 = new BitSet(new long[]{0x0000000000000002L});

}