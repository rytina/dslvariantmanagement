/**
 * <copyright>
 * </copyright>
 *

 */
package org.xtext.example.myDsl.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.example.myDsl.AllMatch;
import org.xtext.example.myDsl.MyDslPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>All Match</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class AllMatchImpl extends MatchImpl implements AllMatch
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected AllMatchImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return MyDslPackage.Literals.ALL_MATCH;
  }

} //AllMatchImpl
