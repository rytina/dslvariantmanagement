/**
 * <copyright>
 * </copyright>
 *

 */
package org.xtext.example.myDsl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Match</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.example.myDsl.MyDslPackage#getMatch()
 * @model
 * @generated
 */
public interface Match extends EObject
{
} // Match
