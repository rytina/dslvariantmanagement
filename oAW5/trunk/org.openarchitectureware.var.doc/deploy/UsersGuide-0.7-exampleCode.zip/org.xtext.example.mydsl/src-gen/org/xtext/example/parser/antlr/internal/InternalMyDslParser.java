package org.xtext.example.parser.antlr.internal; 

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.xtext.parsetree.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.eclipse.xtext.conversion.ValueConverterException;
import org.xtext.example.services.MyDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class InternalMyDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'entity'", "'{'", "'}'", "':'", "'featureAndList'", "'retain'", "'('", "','", "')'", "'featureOrList'", "'featureExp'", "'feature'", "'or'", "'and'", "'not'", "'featuremodel'", "'tags'", "'aspect'", "'*'", "'name'", "'='", "'startswith'", "'endswith'", "'tag'"
    };
    public static final int RULE_ID=4;
    public static final int RULE_STRING=5;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_INT=6;
    public static final int RULE_WS=9;
    public static final int RULE_SL_COMMENT=8;
    public static final int EOF=-1;
    public static final int RULE_ML_COMMENT=7;

        public InternalMyDslParser(TokenStream input) {
            super(input);
        }
        

    public String[] getTokenNames() { return tokenNames; }
    public String getGrammarFileName() { return "../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g"; }


     
     	private MyDslGrammarAccess grammarAccess;
     	
        public InternalMyDslParser(TokenStream input, IAstFactory factory, MyDslGrammarAccess grammarAccess) {
            this(input);
            this.factory = factory;
            registerRules(grammarAccess.getGrammar());
            this.grammarAccess = grammarAccess;
        }
        
        @Override
        protected InputStream getTokenFile() {
        	ClassLoader classLoader = getClass().getClassLoader();
        	return classLoader.getResourceAsStream("org/xtext/example/parser/antlr/internal/InternalMyDsl.tokens");
        }
        
        @Override
        protected String getFirstRuleName() {
        	return "System";	
       	} 



    // $ANTLR start entryRuleSystem
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:72:1: entryRuleSystem returns [EObject current=null] : iv_ruleSystem= ruleSystem EOF ;
    public final EObject entryRuleSystem() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSystem = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:72:48: (iv_ruleSystem= ruleSystem EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:73:2: iv_ruleSystem= ruleSystem EOF
            {
             currentNode = createCompositeNode(grammarAccess.getSystemRule(), currentNode); 
            pushFollow(FOLLOW_ruleSystem_in_entryRuleSystem73);
            iv_ruleSystem=ruleSystem();
            _fsp--;

             current =iv_ruleSystem; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleSystem83); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleSystem


    // $ANTLR start ruleSystem
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:80:1: ruleSystem returns [EObject current=null] : ( (lv_featureModel_0= ruleFeatureModelImport )? (lv_entities_1= ruleEntity )* ) ;
    public final EObject ruleSystem() throws RecognitionException {
        EObject current = null;

        EObject lv_featureModel_0 = null;

        EObject lv_entities_1 = null;


         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:85:6: ( ( (lv_featureModel_0= ruleFeatureModelImport )? (lv_entities_1= ruleEntity )* ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:86:1: ( (lv_featureModel_0= ruleFeatureModelImport )? (lv_entities_1= ruleEntity )* )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:86:1: ( (lv_featureModel_0= ruleFeatureModelImport )? (lv_entities_1= ruleEntity )* )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:86:2: (lv_featureModel_0= ruleFeatureModelImport )? (lv_entities_1= ruleEntity )*
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:86:2: (lv_featureModel_0= ruleFeatureModelImport )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==26) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:89:6: lv_featureModel_0= ruleFeatureModelImport
                    {
                     
                    	        currentNode=createCompositeNode(grammarAccess.getSystemAccess().getFeatureModelFeatureModelImportParserRuleCall_0_0(), currentNode); 
                    	    
                    pushFollow(FOLLOW_ruleFeatureModelImport_in_ruleSystem142);
                    lv_featureModel_0=ruleFeatureModelImport();
                    _fsp--;


                    	        if (current==null) {
                    	            current = factory.create(grammarAccess.getSystemRule().getType().getClassifier());
                    	            associateNodeWithAstElement(currentNode.getParent(), current);
                    	        }
                    	        
                    	        try {
                    	       		set(current, "featureModel", lv_featureModel_0, "FeatureModelImport", currentNode);
                    	        } catch (ValueConverterException vce) {
                    				handleValueConverterException(vce);
                    	        }
                    	        currentNode = currentNode.getParent();
                    	    

                    }
                    break;

            }

            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:107:3: (lv_entities_1= ruleEntity )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0==11||LA2_0==28) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:110:6: lv_entities_1= ruleEntity
            	    {
            	     
            	    	        currentNode=createCompositeNode(grammarAccess.getSystemAccess().getEntitiesEntityParserRuleCall_1_0(), currentNode); 
            	    	    
            	    pushFollow(FOLLOW_ruleEntity_in_ruleSystem181);
            	    lv_entities_1=ruleEntity();
            	    _fsp--;


            	    	        if (current==null) {
            	    	            current = factory.create(grammarAccess.getSystemRule().getType().getClassifier());
            	    	            associateNodeWithAstElement(currentNode.getParent(), current);
            	    	        }
            	    	        
            	    	        try {
            	    	       		add(current, "entities", lv_entities_1, "Entity", currentNode);
            	    	        } catch (ValueConverterException vce) {
            	    				handleValueConverterException(vce);
            	    	        }
            	    	        currentNode = currentNode.getParent();
            	    	    

            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);


            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleSystem


    // $ANTLR start entryRuleEntity
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:135:1: entryRuleEntity returns [EObject current=null] : iv_ruleEntity= ruleEntity EOF ;
    public final EObject entryRuleEntity() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEntity = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:135:48: (iv_ruleEntity= ruleEntity EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:136:2: iv_ruleEntity= ruleEntity EOF
            {
             currentNode = createCompositeNode(grammarAccess.getEntityRule(), currentNode); 
            pushFollow(FOLLOW_ruleEntity_in_entryRuleEntity219);
            iv_ruleEntity=ruleEntity();
            _fsp--;

             current =iv_ruleEntity; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleEntity229); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleEntity


    // $ANTLR start ruleEntity
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:143:1: ruleEntity returns [EObject current=null] : ( (lv_pointcut_0= rulePointcut )? 'entity' (lv_name_2= RULE_ID ) (lv_tags_3= ruleTagsClause )? (lv_featureClause_4= ruleFeatureClause )? '{' (lv_attributes_6= ruleAttribute )* '}' ) ;
    public final EObject ruleEntity() throws RecognitionException {
        EObject current = null;

        Token lv_name_2=null;
        EObject lv_pointcut_0 = null;

        EObject lv_tags_3 = null;

        EObject lv_featureClause_4 = null;

        EObject lv_attributes_6 = null;


         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:148:6: ( ( (lv_pointcut_0= rulePointcut )? 'entity' (lv_name_2= RULE_ID ) (lv_tags_3= ruleTagsClause )? (lv_featureClause_4= ruleFeatureClause )? '{' (lv_attributes_6= ruleAttribute )* '}' ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:149:1: ( (lv_pointcut_0= rulePointcut )? 'entity' (lv_name_2= RULE_ID ) (lv_tags_3= ruleTagsClause )? (lv_featureClause_4= ruleFeatureClause )? '{' (lv_attributes_6= ruleAttribute )* '}' )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:149:1: ( (lv_pointcut_0= rulePointcut )? 'entity' (lv_name_2= RULE_ID ) (lv_tags_3= ruleTagsClause )? (lv_featureClause_4= ruleFeatureClause )? '{' (lv_attributes_6= ruleAttribute )* '}' )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:149:2: (lv_pointcut_0= rulePointcut )? 'entity' (lv_name_2= RULE_ID ) (lv_tags_3= ruleTagsClause )? (lv_featureClause_4= ruleFeatureClause )? '{' (lv_attributes_6= ruleAttribute )* '}'
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:149:2: (lv_pointcut_0= rulePointcut )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==28) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:152:6: lv_pointcut_0= rulePointcut
                    {
                     
                    	        currentNode=createCompositeNode(grammarAccess.getEntityAccess().getPointcutPointcutParserRuleCall_0_0(), currentNode); 
                    	    
                    pushFollow(FOLLOW_rulePointcut_in_ruleEntity288);
                    lv_pointcut_0=rulePointcut();
                    _fsp--;


                    	        if (current==null) {
                    	            current = factory.create(grammarAccess.getEntityRule().getType().getClassifier());
                    	            associateNodeWithAstElement(currentNode.getParent(), current);
                    	        }
                    	        
                    	        try {
                    	       		set(current, "pointcut", lv_pointcut_0, "Pointcut", currentNode);
                    	        } catch (ValueConverterException vce) {
                    				handleValueConverterException(vce);
                    	        }
                    	        currentNode = currentNode.getParent();
                    	    

                    }
                    break;

            }

            match(input,11,FOLLOW_11_in_ruleEntity302); 

                    createLeafNode(grammarAccess.getEntityAccess().getEntityKeyword_1(), null); 
                
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:174:1: (lv_name_2= RULE_ID )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:176:6: lv_name_2= RULE_ID
            {
            lv_name_2=(Token)input.LT(1);
            match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleEntity324); 

            		createLeafNode(grammarAccess.getEntityAccess().getNameIDTerminalRuleCall_2_0(), "name"); 
            	

            	        if (current==null) {
            	            current = factory.create(grammarAccess.getEntityRule().getType().getClassifier());
            	            associateNodeWithAstElement(currentNode, current);
            	        }
            	        
            	        try {
            	       		set(current, "name", lv_name_2, "ID", lastConsumedNode);
            	        } catch (ValueConverterException vce) {
            				handleValueConverterException(vce);
            	        }
            	    

            }

            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:194:2: (lv_tags_3= ruleTagsClause )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==27) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:197:6: lv_tags_3= ruleTagsClause
                    {
                     
                    	        currentNode=createCompositeNode(grammarAccess.getEntityAccess().getTagsTagsClauseParserRuleCall_3_0(), currentNode); 
                    	    
                    pushFollow(FOLLOW_ruleTagsClause_in_ruleEntity366);
                    lv_tags_3=ruleTagsClause();
                    _fsp--;


                    	        if (current==null) {
                    	            current = factory.create(grammarAccess.getEntityRule().getType().getClassifier());
                    	            associateNodeWithAstElement(currentNode.getParent(), current);
                    	        }
                    	        
                    	        try {
                    	       		set(current, "tags", lv_tags_3, "TagsClause", currentNode);
                    	        } catch (ValueConverterException vce) {
                    				handleValueConverterException(vce);
                    	        }
                    	        currentNode = currentNode.getParent();
                    	    

                    }
                    break;

            }

            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:215:3: (lv_featureClause_4= ruleFeatureClause )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==15||(LA5_0>=20 && LA5_0<=22)) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:218:6: lv_featureClause_4= ruleFeatureClause
                    {
                     
                    	        currentNode=createCompositeNode(grammarAccess.getEntityAccess().getFeatureClauseFeatureClauseParserRuleCall_4_0(), currentNode); 
                    	    
                    pushFollow(FOLLOW_ruleFeatureClause_in_ruleEntity405);
                    lv_featureClause_4=ruleFeatureClause();
                    _fsp--;


                    	        if (current==null) {
                    	            current = factory.create(grammarAccess.getEntityRule().getType().getClassifier());
                    	            associateNodeWithAstElement(currentNode.getParent(), current);
                    	        }
                    	        
                    	        try {
                    	       		set(current, "featureClause", lv_featureClause_4, "FeatureClause", currentNode);
                    	        } catch (ValueConverterException vce) {
                    				handleValueConverterException(vce);
                    	        }
                    	        currentNode = currentNode.getParent();
                    	    

                    }
                    break;

            }

            match(input,12,FOLLOW_12_in_ruleEntity419); 

                    createLeafNode(grammarAccess.getEntityAccess().getLeftCurlyBracketKeyword_5(), null); 
                
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:240:1: (lv_attributes_6= ruleAttribute )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==RULE_ID) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:243:6: lv_attributes_6= ruleAttribute
            	    {
            	     
            	    	        currentNode=createCompositeNode(grammarAccess.getEntityAccess().getAttributesAttributeParserRuleCall_6_0(), currentNode); 
            	    	    
            	    pushFollow(FOLLOW_ruleAttribute_in_ruleEntity453);
            	    lv_attributes_6=ruleAttribute();
            	    _fsp--;


            	    	        if (current==null) {
            	    	            current = factory.create(grammarAccess.getEntityRule().getType().getClassifier());
            	    	            associateNodeWithAstElement(currentNode.getParent(), current);
            	    	        }
            	    	        
            	    	        try {
            	    	       		add(current, "attributes", lv_attributes_6, "Attribute", currentNode);
            	    	        } catch (ValueConverterException vce) {
            	    				handleValueConverterException(vce);
            	    	        }
            	    	        currentNode = currentNode.getParent();
            	    	    

            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            match(input,13,FOLLOW_13_in_ruleEntity467); 

                    createLeafNode(grammarAccess.getEntityAccess().getRightCurlyBracketKeyword_7(), null); 
                

            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleEntity


    // $ANTLR start entryRuleAttribute
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:272:1: entryRuleAttribute returns [EObject current=null] : iv_ruleAttribute= ruleAttribute EOF ;
    public final EObject entryRuleAttribute() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAttribute = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:272:51: (iv_ruleAttribute= ruleAttribute EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:273:2: iv_ruleAttribute= ruleAttribute EOF
            {
             currentNode = createCompositeNode(grammarAccess.getAttributeRule(), currentNode); 
            pushFollow(FOLLOW_ruleAttribute_in_entryRuleAttribute500);
            iv_ruleAttribute=ruleAttribute();
            _fsp--;

             current =iv_ruleAttribute; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleAttribute510); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleAttribute


    // $ANTLR start ruleAttribute
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:280:1: ruleAttribute returns [EObject current=null] : ( (lv_name_0= RULE_ID ) ':' (lv_type_2= RULE_ID ) (lv_featureClause_3= ruleFeatureClause )? ) ;
    public final EObject ruleAttribute() throws RecognitionException {
        EObject current = null;

        Token lv_name_0=null;
        Token lv_type_2=null;
        EObject lv_featureClause_3 = null;


         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:285:6: ( ( (lv_name_0= RULE_ID ) ':' (lv_type_2= RULE_ID ) (lv_featureClause_3= ruleFeatureClause )? ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:286:1: ( (lv_name_0= RULE_ID ) ':' (lv_type_2= RULE_ID ) (lv_featureClause_3= ruleFeatureClause )? )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:286:1: ( (lv_name_0= RULE_ID ) ':' (lv_type_2= RULE_ID ) (lv_featureClause_3= ruleFeatureClause )? )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:286:2: (lv_name_0= RULE_ID ) ':' (lv_type_2= RULE_ID ) (lv_featureClause_3= ruleFeatureClause )?
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:286:2: (lv_name_0= RULE_ID )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:288:6: lv_name_0= RULE_ID
            {
            lv_name_0=(Token)input.LT(1);
            match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleAttribute557); 

            		createLeafNode(grammarAccess.getAttributeAccess().getNameIDTerminalRuleCall_0_0(), "name"); 
            	

            	        if (current==null) {
            	            current = factory.create(grammarAccess.getAttributeRule().getType().getClassifier());
            	            associateNodeWithAstElement(currentNode, current);
            	        }
            	        
            	        try {
            	       		set(current, "name", lv_name_0, "ID", lastConsumedNode);
            	        } catch (ValueConverterException vce) {
            				handleValueConverterException(vce);
            	        }
            	    

            }

            match(input,14,FOLLOW_14_in_ruleAttribute574); 

                    createLeafNode(grammarAccess.getAttributeAccess().getColonKeyword_1(), null); 
                
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:310:1: (lv_type_2= RULE_ID )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:312:6: lv_type_2= RULE_ID
            {
            lv_type_2=(Token)input.LT(1);
            match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleAttribute596); 

            		createLeafNode(grammarAccess.getAttributeAccess().getTypeIDTerminalRuleCall_2_0(), "type"); 
            	

            	        if (current==null) {
            	            current = factory.create(grammarAccess.getAttributeRule().getType().getClassifier());
            	            associateNodeWithAstElement(currentNode, current);
            	        }
            	        
            	        try {
            	       		set(current, "type", lv_type_2, "ID", lastConsumedNode);
            	        } catch (ValueConverterException vce) {
            				handleValueConverterException(vce);
            	        }
            	    

            }

            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:330:2: (lv_featureClause_3= ruleFeatureClause )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==15||(LA7_0>=20 && LA7_0<=22)) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:333:6: lv_featureClause_3= ruleFeatureClause
                    {
                     
                    	        currentNode=createCompositeNode(grammarAccess.getAttributeAccess().getFeatureClauseFeatureClauseParserRuleCall_3_0(), currentNode); 
                    	    
                    pushFollow(FOLLOW_ruleFeatureClause_in_ruleAttribute638);
                    lv_featureClause_3=ruleFeatureClause();
                    _fsp--;


                    	        if (current==null) {
                    	            current = factory.create(grammarAccess.getAttributeRule().getType().getClassifier());
                    	            associateNodeWithAstElement(currentNode.getParent(), current);
                    	        }
                    	        
                    	        try {
                    	       		set(current, "featureClause", lv_featureClause_3, "FeatureClause", currentNode);
                    	        } catch (ValueConverterException vce) {
                    				handleValueConverterException(vce);
                    	        }
                    	        currentNode = currentNode.getParent();
                    	    

                    }
                    break;

            }


            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleAttribute


    // $ANTLR start entryRuleFeatureClause
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:358:1: entryRuleFeatureClause returns [EObject current=null] : iv_ruleFeatureClause= ruleFeatureClause EOF ;
    public final EObject entryRuleFeatureClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFeatureClause = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:358:55: (iv_ruleFeatureClause= ruleFeatureClause EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:359:2: iv_ruleFeatureClause= ruleFeatureClause EOF
            {
             currentNode = createCompositeNode(grammarAccess.getFeatureClauseRule(), currentNode); 
            pushFollow(FOLLOW_ruleFeatureClause_in_entryRuleFeatureClause676);
            iv_ruleFeatureClause=ruleFeatureClause();
            _fsp--;

             current =iv_ruleFeatureClause; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeatureClause686); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleFeatureClause


    // $ANTLR start ruleFeatureClause
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:366:1: ruleFeatureClause returns [EObject current=null] : (this_FeatureAndList_0= ruleFeatureAndList | this_FeatureOrList_1= ruleFeatureOrList | this_FeatureExpression_2= ruleFeatureExpression | this_Feature_3= ruleFeature ) ;
    public final EObject ruleFeatureClause() throws RecognitionException {
        EObject current = null;

        EObject this_FeatureAndList_0 = null;

        EObject this_FeatureOrList_1 = null;

        EObject this_FeatureExpression_2 = null;

        EObject this_Feature_3 = null;


         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:371:6: ( (this_FeatureAndList_0= ruleFeatureAndList | this_FeatureOrList_1= ruleFeatureOrList | this_FeatureExpression_2= ruleFeatureExpression | this_Feature_3= ruleFeature ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:372:1: (this_FeatureAndList_0= ruleFeatureAndList | this_FeatureOrList_1= ruleFeatureOrList | this_FeatureExpression_2= ruleFeatureExpression | this_Feature_3= ruleFeature )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:372:1: (this_FeatureAndList_0= ruleFeatureAndList | this_FeatureOrList_1= ruleFeatureOrList | this_FeatureExpression_2= ruleFeatureExpression | this_Feature_3= ruleFeature )
            int alt8=4;
            switch ( input.LA(1) ) {
            case 15:
                {
                alt8=1;
                }
                break;
            case 20:
                {
                alt8=2;
                }
                break;
            case 21:
                {
                alt8=3;
                }
                break;
            case 22:
                {
                alt8=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("372:1: (this_FeatureAndList_0= ruleFeatureAndList | this_FeatureOrList_1= ruleFeatureOrList | this_FeatureExpression_2= ruleFeatureExpression | this_Feature_3= ruleFeature )", 8, 0, input);

                throw nvae;
            }

            switch (alt8) {
                case 1 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:373:5: this_FeatureAndList_0= ruleFeatureAndList
                    {
                     
                            currentNode=createCompositeNode(grammarAccess.getFeatureClauseAccess().getFeatureAndListParserRuleCall_0(), currentNode); 
                        
                    pushFollow(FOLLOW_ruleFeatureAndList_in_ruleFeatureClause733);
                    this_FeatureAndList_0=ruleFeatureAndList();
                    _fsp--;

                     
                            current = this_FeatureAndList_0; 
                            currentNode = currentNode.getParent();
                        

                    }
                    break;
                case 2 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:383:5: this_FeatureOrList_1= ruleFeatureOrList
                    {
                     
                            currentNode=createCompositeNode(grammarAccess.getFeatureClauseAccess().getFeatureOrListParserRuleCall_1(), currentNode); 
                        
                    pushFollow(FOLLOW_ruleFeatureOrList_in_ruleFeatureClause760);
                    this_FeatureOrList_1=ruleFeatureOrList();
                    _fsp--;

                     
                            current = this_FeatureOrList_1; 
                            currentNode = currentNode.getParent();
                        

                    }
                    break;
                case 3 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:393:5: this_FeatureExpression_2= ruleFeatureExpression
                    {
                     
                            currentNode=createCompositeNode(grammarAccess.getFeatureClauseAccess().getFeatureExpressionParserRuleCall_2(), currentNode); 
                        
                    pushFollow(FOLLOW_ruleFeatureExpression_in_ruleFeatureClause787);
                    this_FeatureExpression_2=ruleFeatureExpression();
                    _fsp--;

                     
                            current = this_FeatureExpression_2; 
                            currentNode = currentNode.getParent();
                        

                    }
                    break;
                case 4 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:403:5: this_Feature_3= ruleFeature
                    {
                     
                            currentNode=createCompositeNode(grammarAccess.getFeatureClauseAccess().getFeatureParserRuleCall_3(), currentNode); 
                        
                    pushFollow(FOLLOW_ruleFeature_in_ruleFeatureClause814);
                    this_Feature_3=ruleFeature();
                    _fsp--;

                     
                            current = this_Feature_3; 
                            currentNode = currentNode.getParent();
                        

                    }
                    break;

            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleFeatureClause


    // $ANTLR start entryRuleFeatureAndList
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:418:1: entryRuleFeatureAndList returns [EObject current=null] : iv_ruleFeatureAndList= ruleFeatureAndList EOF ;
    public final EObject entryRuleFeatureAndList() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFeatureAndList = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:418:56: (iv_ruleFeatureAndList= ruleFeatureAndList EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:419:2: iv_ruleFeatureAndList= ruleFeatureAndList EOF
            {
             currentNode = createCompositeNode(grammarAccess.getFeatureAndListRule(), currentNode); 
            pushFollow(FOLLOW_ruleFeatureAndList_in_entryRuleFeatureAndList846);
            iv_ruleFeatureAndList=ruleFeatureAndList();
            _fsp--;

             current =iv_ruleFeatureAndList; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeatureAndList856); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleFeatureAndList


    // $ANTLR start ruleFeatureAndList
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:426:1: ruleFeatureAndList returns [EObject current=null] : ( 'featureAndList' (lv_retained_1= 'retain' )? '(' (lv_featureList_3= RULE_ID ) ( ',' (lv_featureList_5= RULE_ID ) )* ')' ) ;
    public final EObject ruleFeatureAndList() throws RecognitionException {
        EObject current = null;

        Token lv_retained_1=null;
        Token lv_featureList_3=null;
        Token lv_featureList_5=null;

         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:431:6: ( ( 'featureAndList' (lv_retained_1= 'retain' )? '(' (lv_featureList_3= RULE_ID ) ( ',' (lv_featureList_5= RULE_ID ) )* ')' ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:432:1: ( 'featureAndList' (lv_retained_1= 'retain' )? '(' (lv_featureList_3= RULE_ID ) ( ',' (lv_featureList_5= RULE_ID ) )* ')' )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:432:1: ( 'featureAndList' (lv_retained_1= 'retain' )? '(' (lv_featureList_3= RULE_ID ) ( ',' (lv_featureList_5= RULE_ID ) )* ')' )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:432:2: 'featureAndList' (lv_retained_1= 'retain' )? '(' (lv_featureList_3= RULE_ID ) ( ',' (lv_featureList_5= RULE_ID ) )* ')'
            {
            match(input,15,FOLLOW_15_in_ruleFeatureAndList890); 

                    createLeafNode(grammarAccess.getFeatureAndListAccess().getFeatureAndListKeyword_0(), null); 
                
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:436:1: (lv_retained_1= 'retain' )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==16) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:438:6: lv_retained_1= 'retain'
                    {
                    lv_retained_1=(Token)input.LT(1);
                    match(input,16,FOLLOW_16_in_ruleFeatureAndList911); 

                            createLeafNode(grammarAccess.getFeatureAndListAccess().getRetainedRetainKeyword_1_0(), "retained"); 
                        

                    	        if (current==null) {
                    	            current = factory.create(grammarAccess.getFeatureAndListRule().getType().getClassifier());
                    	            associateNodeWithAstElement(currentNode, current);
                    	        }
                    	        
                    	        try {
                    	       		set(current, "retained", true, "retain", lastConsumedNode);
                    	        } catch (ValueConverterException vce) {
                    				handleValueConverterException(vce);
                    	        }
                    	    

                    }
                    break;

            }

            match(input,17,FOLLOW_17_in_ruleFeatureAndList934); 

                    createLeafNode(grammarAccess.getFeatureAndListAccess().getLeftParenthesisKeyword_2(), null); 
                
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:461:1: (lv_featureList_3= RULE_ID )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:463:6: lv_featureList_3= RULE_ID
            {
            lv_featureList_3=(Token)input.LT(1);
            match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleFeatureAndList956); 

            		createLeafNode(grammarAccess.getFeatureAndListAccess().getFeatureListIDTerminalRuleCall_3_0(), "featureList"); 
            	

            	        if (current==null) {
            	            current = factory.create(grammarAccess.getFeatureAndListRule().getType().getClassifier());
            	            associateNodeWithAstElement(currentNode, current);
            	        }
            	        
            	        try {
            	       		add(current, "featureList", lv_featureList_3, "ID", lastConsumedNode);
            	        } catch (ValueConverterException vce) {
            				handleValueConverterException(vce);
            	        }
            	    

            }

            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:481:2: ( ',' (lv_featureList_5= RULE_ID ) )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==18) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:481:3: ',' (lv_featureList_5= RULE_ID )
            	    {
            	    match(input,18,FOLLOW_18_in_ruleFeatureAndList974); 

            	            createLeafNode(grammarAccess.getFeatureAndListAccess().getCommaKeyword_4_0(), null); 
            	        
            	    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:485:1: (lv_featureList_5= RULE_ID )
            	    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:487:6: lv_featureList_5= RULE_ID
            	    {
            	    lv_featureList_5=(Token)input.LT(1);
            	    match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleFeatureAndList996); 

            	    		createLeafNode(grammarAccess.getFeatureAndListAccess().getFeatureListIDTerminalRuleCall_4_1_0(), "featureList"); 
            	    	

            	    	        if (current==null) {
            	    	            current = factory.create(grammarAccess.getFeatureAndListRule().getType().getClassifier());
            	    	            associateNodeWithAstElement(currentNode, current);
            	    	        }
            	    	        
            	    	        try {
            	    	       		add(current, "featureList", lv_featureList_5, "ID", lastConsumedNode);
            	    	        } catch (ValueConverterException vce) {
            	    				handleValueConverterException(vce);
            	    	        }
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

            match(input,19,FOLLOW_19_in_ruleFeatureAndList1015); 

                    createLeafNode(grammarAccess.getFeatureAndListAccess().getRightParenthesisKeyword_5(), null); 
                

            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleFeatureAndList


    // $ANTLR start entryRuleFeatureOrList
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:516:1: entryRuleFeatureOrList returns [EObject current=null] : iv_ruleFeatureOrList= ruleFeatureOrList EOF ;
    public final EObject entryRuleFeatureOrList() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFeatureOrList = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:516:55: (iv_ruleFeatureOrList= ruleFeatureOrList EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:517:2: iv_ruleFeatureOrList= ruleFeatureOrList EOF
            {
             currentNode = createCompositeNode(grammarAccess.getFeatureOrListRule(), currentNode); 
            pushFollow(FOLLOW_ruleFeatureOrList_in_entryRuleFeatureOrList1048);
            iv_ruleFeatureOrList=ruleFeatureOrList();
            _fsp--;

             current =iv_ruleFeatureOrList; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeatureOrList1058); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleFeatureOrList


    // $ANTLR start ruleFeatureOrList
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:524:1: ruleFeatureOrList returns [EObject current=null] : ( 'featureOrList' (lv_retained_1= 'retain' )? '(' (lv_featureList_3= RULE_ID ) ( ',' (lv_featureList_5= RULE_ID ) )* ')' ) ;
    public final EObject ruleFeatureOrList() throws RecognitionException {
        EObject current = null;

        Token lv_retained_1=null;
        Token lv_featureList_3=null;
        Token lv_featureList_5=null;

         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:529:6: ( ( 'featureOrList' (lv_retained_1= 'retain' )? '(' (lv_featureList_3= RULE_ID ) ( ',' (lv_featureList_5= RULE_ID ) )* ')' ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:530:1: ( 'featureOrList' (lv_retained_1= 'retain' )? '(' (lv_featureList_3= RULE_ID ) ( ',' (lv_featureList_5= RULE_ID ) )* ')' )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:530:1: ( 'featureOrList' (lv_retained_1= 'retain' )? '(' (lv_featureList_3= RULE_ID ) ( ',' (lv_featureList_5= RULE_ID ) )* ')' )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:530:2: 'featureOrList' (lv_retained_1= 'retain' )? '(' (lv_featureList_3= RULE_ID ) ( ',' (lv_featureList_5= RULE_ID ) )* ')'
            {
            match(input,20,FOLLOW_20_in_ruleFeatureOrList1092); 

                    createLeafNode(grammarAccess.getFeatureOrListAccess().getFeatureOrListKeyword_0(), null); 
                
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:534:1: (lv_retained_1= 'retain' )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==16) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:536:6: lv_retained_1= 'retain'
                    {
                    lv_retained_1=(Token)input.LT(1);
                    match(input,16,FOLLOW_16_in_ruleFeatureOrList1113); 

                            createLeafNode(grammarAccess.getFeatureOrListAccess().getRetainedRetainKeyword_1_0(), "retained"); 
                        

                    	        if (current==null) {
                    	            current = factory.create(grammarAccess.getFeatureOrListRule().getType().getClassifier());
                    	            associateNodeWithAstElement(currentNode, current);
                    	        }
                    	        
                    	        try {
                    	       		set(current, "retained", true, "retain", lastConsumedNode);
                    	        } catch (ValueConverterException vce) {
                    				handleValueConverterException(vce);
                    	        }
                    	    

                    }
                    break;

            }

            match(input,17,FOLLOW_17_in_ruleFeatureOrList1136); 

                    createLeafNode(grammarAccess.getFeatureOrListAccess().getLeftParenthesisKeyword_2(), null); 
                
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:559:1: (lv_featureList_3= RULE_ID )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:561:6: lv_featureList_3= RULE_ID
            {
            lv_featureList_3=(Token)input.LT(1);
            match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleFeatureOrList1158); 

            		createLeafNode(grammarAccess.getFeatureOrListAccess().getFeatureListIDTerminalRuleCall_3_0(), "featureList"); 
            	

            	        if (current==null) {
            	            current = factory.create(grammarAccess.getFeatureOrListRule().getType().getClassifier());
            	            associateNodeWithAstElement(currentNode, current);
            	        }
            	        
            	        try {
            	       		add(current, "featureList", lv_featureList_3, "ID", lastConsumedNode);
            	        } catch (ValueConverterException vce) {
            				handleValueConverterException(vce);
            	        }
            	    

            }

            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:579:2: ( ',' (lv_featureList_5= RULE_ID ) )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==18) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:579:3: ',' (lv_featureList_5= RULE_ID )
            	    {
            	    match(input,18,FOLLOW_18_in_ruleFeatureOrList1176); 

            	            createLeafNode(grammarAccess.getFeatureOrListAccess().getCommaKeyword_4_0(), null); 
            	        
            	    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:583:1: (lv_featureList_5= RULE_ID )
            	    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:585:6: lv_featureList_5= RULE_ID
            	    {
            	    lv_featureList_5=(Token)input.LT(1);
            	    match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleFeatureOrList1198); 

            	    		createLeafNode(grammarAccess.getFeatureOrListAccess().getFeatureListIDTerminalRuleCall_4_1_0(), "featureList"); 
            	    	

            	    	        if (current==null) {
            	    	            current = factory.create(grammarAccess.getFeatureOrListRule().getType().getClassifier());
            	    	            associateNodeWithAstElement(currentNode, current);
            	    	        }
            	    	        
            	    	        try {
            	    	       		add(current, "featureList", lv_featureList_5, "ID", lastConsumedNode);
            	    	        } catch (ValueConverterException vce) {
            	    				handleValueConverterException(vce);
            	    	        }
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

            match(input,19,FOLLOW_19_in_ruleFeatureOrList1217); 

                    createLeafNode(grammarAccess.getFeatureOrListAccess().getRightParenthesisKeyword_5(), null); 
                

            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleFeatureOrList


    // $ANTLR start entryRuleFeatureExpression
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:614:1: entryRuleFeatureExpression returns [EObject current=null] : iv_ruleFeatureExpression= ruleFeatureExpression EOF ;
    public final EObject entryRuleFeatureExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFeatureExpression = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:614:59: (iv_ruleFeatureExpression= ruleFeatureExpression EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:615:2: iv_ruleFeatureExpression= ruleFeatureExpression EOF
            {
             currentNode = createCompositeNode(grammarAccess.getFeatureExpressionRule(), currentNode); 
            pushFollow(FOLLOW_ruleFeatureExpression_in_entryRuleFeatureExpression1250);
            iv_ruleFeatureExpression=ruleFeatureExpression();
            _fsp--;

             current =iv_ruleFeatureExpression; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeatureExpression1260); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleFeatureExpression


    // $ANTLR start ruleFeatureExpression
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:622:1: ruleFeatureExpression returns [EObject current=null] : ( 'featureExp' (lv_retained_1= 'retain' )? '(' (lv_expression_3= ruleOrExpression ) ')' ) ;
    public final EObject ruleFeatureExpression() throws RecognitionException {
        EObject current = null;

        Token lv_retained_1=null;
        EObject lv_expression_3 = null;


         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:627:6: ( ( 'featureExp' (lv_retained_1= 'retain' )? '(' (lv_expression_3= ruleOrExpression ) ')' ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:628:1: ( 'featureExp' (lv_retained_1= 'retain' )? '(' (lv_expression_3= ruleOrExpression ) ')' )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:628:1: ( 'featureExp' (lv_retained_1= 'retain' )? '(' (lv_expression_3= ruleOrExpression ) ')' )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:628:2: 'featureExp' (lv_retained_1= 'retain' )? '(' (lv_expression_3= ruleOrExpression ) ')'
            {
            match(input,21,FOLLOW_21_in_ruleFeatureExpression1294); 

                    createLeafNode(grammarAccess.getFeatureExpressionAccess().getFeatureExpKeyword_0(), null); 
                
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:632:1: (lv_retained_1= 'retain' )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==16) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:634:6: lv_retained_1= 'retain'
                    {
                    lv_retained_1=(Token)input.LT(1);
                    match(input,16,FOLLOW_16_in_ruleFeatureExpression1315); 

                            createLeafNode(grammarAccess.getFeatureExpressionAccess().getRetainedRetainKeyword_1_0(), "retained"); 
                        

                    	        if (current==null) {
                    	            current = factory.create(grammarAccess.getFeatureExpressionRule().getType().getClassifier());
                    	            associateNodeWithAstElement(currentNode, current);
                    	        }
                    	        
                    	        try {
                    	       		set(current, "retained", true, "retain", lastConsumedNode);
                    	        } catch (ValueConverterException vce) {
                    				handleValueConverterException(vce);
                    	        }
                    	    

                    }
                    break;

            }

            match(input,17,FOLLOW_17_in_ruleFeatureExpression1338); 

                    createLeafNode(grammarAccess.getFeatureExpressionAccess().getLeftParenthesisKeyword_2(), null); 
                
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:657:1: (lv_expression_3= ruleOrExpression )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:660:6: lv_expression_3= ruleOrExpression
            {
             
            	        currentNode=createCompositeNode(grammarAccess.getFeatureExpressionAccess().getExpressionOrExpressionParserRuleCall_3_0(), currentNode); 
            	    
            pushFollow(FOLLOW_ruleOrExpression_in_ruleFeatureExpression1372);
            lv_expression_3=ruleOrExpression();
            _fsp--;


            	        if (current==null) {
            	            current = factory.create(grammarAccess.getFeatureExpressionRule().getType().getClassifier());
            	            associateNodeWithAstElement(currentNode.getParent(), current);
            	        }
            	        
            	        try {
            	       		set(current, "expression", lv_expression_3, "OrExpression", currentNode);
            	        } catch (ValueConverterException vce) {
            				handleValueConverterException(vce);
            	        }
            	        currentNode = currentNode.getParent();
            	    

            }

            match(input,19,FOLLOW_19_in_ruleFeatureExpression1385); 

                    createLeafNode(grammarAccess.getFeatureExpressionAccess().getRightParenthesisKeyword_4(), null); 
                

            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleFeatureExpression


    // $ANTLR start entryRuleFeature
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:689:1: entryRuleFeature returns [EObject current=null] : iv_ruleFeature= ruleFeature EOF ;
    public final EObject entryRuleFeature() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFeature = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:689:49: (iv_ruleFeature= ruleFeature EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:690:2: iv_ruleFeature= ruleFeature EOF
            {
             currentNode = createCompositeNode(grammarAccess.getFeatureRule(), currentNode); 
            pushFollow(FOLLOW_ruleFeature_in_entryRuleFeature1418);
            iv_ruleFeature=ruleFeature();
            _fsp--;

             current =iv_ruleFeature; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeature1428); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleFeature


    // $ANTLR start ruleFeature
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:697:1: ruleFeature returns [EObject current=null] : ( 'feature' (lv_retained_1= 'retain' )? (lv_feature_2= RULE_ID ) ) ;
    public final EObject ruleFeature() throws RecognitionException {
        EObject current = null;

        Token lv_retained_1=null;
        Token lv_feature_2=null;

         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:702:6: ( ( 'feature' (lv_retained_1= 'retain' )? (lv_feature_2= RULE_ID ) ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:703:1: ( 'feature' (lv_retained_1= 'retain' )? (lv_feature_2= RULE_ID ) )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:703:1: ( 'feature' (lv_retained_1= 'retain' )? (lv_feature_2= RULE_ID ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:703:2: 'feature' (lv_retained_1= 'retain' )? (lv_feature_2= RULE_ID )
            {
            match(input,22,FOLLOW_22_in_ruleFeature1462); 

                    createLeafNode(grammarAccess.getFeatureAccess().getFeatureKeyword_0(), null); 
                
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:707:1: (lv_retained_1= 'retain' )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==16) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:709:6: lv_retained_1= 'retain'
                    {
                    lv_retained_1=(Token)input.LT(1);
                    match(input,16,FOLLOW_16_in_ruleFeature1483); 

                            createLeafNode(grammarAccess.getFeatureAccess().getRetainedRetainKeyword_1_0(), "retained"); 
                        

                    	        if (current==null) {
                    	            current = factory.create(grammarAccess.getFeatureRule().getType().getClassifier());
                    	            associateNodeWithAstElement(currentNode, current);
                    	        }
                    	        
                    	        try {
                    	       		set(current, "retained", true, "retain", lastConsumedNode);
                    	        } catch (ValueConverterException vce) {
                    				handleValueConverterException(vce);
                    	        }
                    	    

                    }
                    break;

            }

            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:728:3: (lv_feature_2= RULE_ID )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:730:6: lv_feature_2= RULE_ID
            {
            lv_feature_2=(Token)input.LT(1);
            match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleFeature1519); 

            		createLeafNode(grammarAccess.getFeatureAccess().getFeatureIDTerminalRuleCall_2_0(), "feature"); 
            	

            	        if (current==null) {
            	            current = factory.create(grammarAccess.getFeatureRule().getType().getClassifier());
            	            associateNodeWithAstElement(currentNode, current);
            	        }
            	        
            	        try {
            	       		set(current, "feature", lv_feature_2, "ID", lastConsumedNode);
            	        } catch (ValueConverterException vce) {
            				handleValueConverterException(vce);
            	        }
            	    

            }


            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleFeature


    // $ANTLR start entryRuleOrExpression
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:755:1: entryRuleOrExpression returns [EObject current=null] : iv_ruleOrExpression= ruleOrExpression EOF ;
    public final EObject entryRuleOrExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOrExpression = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:755:54: (iv_ruleOrExpression= ruleOrExpression EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:756:2: iv_ruleOrExpression= ruleOrExpression EOF
            {
             currentNode = createCompositeNode(grammarAccess.getOrExpressionRule(), currentNode); 
            pushFollow(FOLLOW_ruleOrExpression_in_entryRuleOrExpression1560);
            iv_ruleOrExpression=ruleOrExpression();
            _fsp--;

             current =iv_ruleOrExpression; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleOrExpression1570); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleOrExpression


    // $ANTLR start ruleOrExpression
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:763:1: ruleOrExpression returns [EObject current=null] : ( (lv_operands_0= ruleAndExpression ) ( 'or' (lv_operands_2= ruleAndExpression ) )* ) ;
    public final EObject ruleOrExpression() throws RecognitionException {
        EObject current = null;

        EObject lv_operands_0 = null;

        EObject lv_operands_2 = null;


         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:768:6: ( ( (lv_operands_0= ruleAndExpression ) ( 'or' (lv_operands_2= ruleAndExpression ) )* ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:769:1: ( (lv_operands_0= ruleAndExpression ) ( 'or' (lv_operands_2= ruleAndExpression ) )* )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:769:1: ( (lv_operands_0= ruleAndExpression ) ( 'or' (lv_operands_2= ruleAndExpression ) )* )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:769:2: (lv_operands_0= ruleAndExpression ) ( 'or' (lv_operands_2= ruleAndExpression ) )*
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:769:2: (lv_operands_0= ruleAndExpression )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:772:6: lv_operands_0= ruleAndExpression
            {
             
            	        currentNode=createCompositeNode(grammarAccess.getOrExpressionAccess().getOperandsAndExpressionParserRuleCall_0_0(), currentNode); 
            	    
            pushFollow(FOLLOW_ruleAndExpression_in_ruleOrExpression1629);
            lv_operands_0=ruleAndExpression();
            _fsp--;


            	        if (current==null) {
            	            current = factory.create(grammarAccess.getOrExpressionRule().getType().getClassifier());
            	            associateNodeWithAstElement(currentNode.getParent(), current);
            	        }
            	        
            	        try {
            	       		add(current, "operands", lv_operands_0, "AndExpression", currentNode);
            	        } catch (ValueConverterException vce) {
            				handleValueConverterException(vce);
            	        }
            	        currentNode = currentNode.getParent();
            	    

            }

            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:790:2: ( 'or' (lv_operands_2= ruleAndExpression ) )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==23) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:790:3: 'or' (lv_operands_2= ruleAndExpression )
            	    {
            	    match(input,23,FOLLOW_23_in_ruleOrExpression1643); 

            	            createLeafNode(grammarAccess.getOrExpressionAccess().getOrKeyword_1_0(), null); 
            	        
            	    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:794:1: (lv_operands_2= ruleAndExpression )
            	    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:797:6: lv_operands_2= ruleAndExpression
            	    {
            	     
            	    	        currentNode=createCompositeNode(grammarAccess.getOrExpressionAccess().getOperandsAndExpressionParserRuleCall_1_1_0(), currentNode); 
            	    	    
            	    pushFollow(FOLLOW_ruleAndExpression_in_ruleOrExpression1677);
            	    lv_operands_2=ruleAndExpression();
            	    _fsp--;


            	    	        if (current==null) {
            	    	            current = factory.create(grammarAccess.getOrExpressionRule().getType().getClassifier());
            	    	            associateNodeWithAstElement(currentNode.getParent(), current);
            	    	        }
            	    	        
            	    	        try {
            	    	       		add(current, "operands", lv_operands_2, "AndExpression", currentNode);
            	    	        } catch (ValueConverterException vce) {
            	    				handleValueConverterException(vce);
            	    	        }
            	    	        currentNode = currentNode.getParent();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);


            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleOrExpression


    // $ANTLR start entryRuleAndExpression
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:822:1: entryRuleAndExpression returns [EObject current=null] : iv_ruleAndExpression= ruleAndExpression EOF ;
    public final EObject entryRuleAndExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAndExpression = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:822:55: (iv_ruleAndExpression= ruleAndExpression EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:823:2: iv_ruleAndExpression= ruleAndExpression EOF
            {
             currentNode = createCompositeNode(grammarAccess.getAndExpressionRule(), currentNode); 
            pushFollow(FOLLOW_ruleAndExpression_in_entryRuleAndExpression1716);
            iv_ruleAndExpression=ruleAndExpression();
            _fsp--;

             current =iv_ruleAndExpression; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleAndExpression1726); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleAndExpression


    // $ANTLR start ruleAndExpression
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:830:1: ruleAndExpression returns [EObject current=null] : ( (lv_operands_0= ruleOperand ) ( 'and' (lv_operands_2= ruleOperand ) )* ) ;
    public final EObject ruleAndExpression() throws RecognitionException {
        EObject current = null;

        EObject lv_operands_0 = null;

        EObject lv_operands_2 = null;


         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:835:6: ( ( (lv_operands_0= ruleOperand ) ( 'and' (lv_operands_2= ruleOperand ) )* ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:836:1: ( (lv_operands_0= ruleOperand ) ( 'and' (lv_operands_2= ruleOperand ) )* )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:836:1: ( (lv_operands_0= ruleOperand ) ( 'and' (lv_operands_2= ruleOperand ) )* )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:836:2: (lv_operands_0= ruleOperand ) ( 'and' (lv_operands_2= ruleOperand ) )*
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:836:2: (lv_operands_0= ruleOperand )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:839:6: lv_operands_0= ruleOperand
            {
             
            	        currentNode=createCompositeNode(grammarAccess.getAndExpressionAccess().getOperandsOperandParserRuleCall_0_0(), currentNode); 
            	    
            pushFollow(FOLLOW_ruleOperand_in_ruleAndExpression1785);
            lv_operands_0=ruleOperand();
            _fsp--;


            	        if (current==null) {
            	            current = factory.create(grammarAccess.getAndExpressionRule().getType().getClassifier());
            	            associateNodeWithAstElement(currentNode.getParent(), current);
            	        }
            	        
            	        try {
            	       		add(current, "operands", lv_operands_0, "Operand", currentNode);
            	        } catch (ValueConverterException vce) {
            				handleValueConverterException(vce);
            	        }
            	        currentNode = currentNode.getParent();
            	    

            }

            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:857:2: ( 'and' (lv_operands_2= ruleOperand ) )*
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( (LA16_0==24) ) {
                    alt16=1;
                }


                switch (alt16) {
            	case 1 :
            	    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:857:3: 'and' (lv_operands_2= ruleOperand )
            	    {
            	    match(input,24,FOLLOW_24_in_ruleAndExpression1799); 

            	            createLeafNode(grammarAccess.getAndExpressionAccess().getAndKeyword_1_0(), null); 
            	        
            	    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:861:1: (lv_operands_2= ruleOperand )
            	    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:864:6: lv_operands_2= ruleOperand
            	    {
            	     
            	    	        currentNode=createCompositeNode(grammarAccess.getAndExpressionAccess().getOperandsOperandParserRuleCall_1_1_0(), currentNode); 
            	    	    
            	    pushFollow(FOLLOW_ruleOperand_in_ruleAndExpression1833);
            	    lv_operands_2=ruleOperand();
            	    _fsp--;


            	    	        if (current==null) {
            	    	            current = factory.create(grammarAccess.getAndExpressionRule().getType().getClassifier());
            	    	            associateNodeWithAstElement(currentNode.getParent(), current);
            	    	        }
            	    	        
            	    	        try {
            	    	       		add(current, "operands", lv_operands_2, "Operand", currentNode);
            	    	        } catch (ValueConverterException vce) {
            	    				handleValueConverterException(vce);
            	    	        }
            	    	        currentNode = currentNode.getParent();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    break loop16;
                }
            } while (true);


            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleAndExpression


    // $ANTLR start entryRuleOperand
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:889:1: entryRuleOperand returns [EObject current=null] : iv_ruleOperand= ruleOperand EOF ;
    public final EObject entryRuleOperand() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOperand = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:889:49: (iv_ruleOperand= ruleOperand EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:890:2: iv_ruleOperand= ruleOperand EOF
            {
             currentNode = createCompositeNode(grammarAccess.getOperandRule(), currentNode); 
            pushFollow(FOLLOW_ruleOperand_in_entryRuleOperand1872);
            iv_ruleOperand=ruleOperand();
            _fsp--;

             current =iv_ruleOperand; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleOperand1882); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleOperand


    // $ANTLR start ruleOperand
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:897:1: ruleOperand returns [EObject current=null] : ( (lv_isNot_0= 'not' )? (lv_expression_1= ruleAtom ) ) ;
    public final EObject ruleOperand() throws RecognitionException {
        EObject current = null;

        Token lv_isNot_0=null;
        EObject lv_expression_1 = null;


         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:902:6: ( ( (lv_isNot_0= 'not' )? (lv_expression_1= ruleAtom ) ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:903:1: ( (lv_isNot_0= 'not' )? (lv_expression_1= ruleAtom ) )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:903:1: ( (lv_isNot_0= 'not' )? (lv_expression_1= ruleAtom ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:903:2: (lv_isNot_0= 'not' )? (lv_expression_1= ruleAtom )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:903:2: (lv_isNot_0= 'not' )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==25) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:905:6: lv_isNot_0= 'not'
                    {
                    lv_isNot_0=(Token)input.LT(1);
                    match(input,25,FOLLOW_25_in_ruleOperand1928); 

                            createLeafNode(grammarAccess.getOperandAccess().getIsNotNotKeyword_0_0(), "isNot"); 
                        

                    	        if (current==null) {
                    	            current = factory.create(grammarAccess.getOperandRule().getType().getClassifier());
                    	            associateNodeWithAstElement(currentNode, current);
                    	        }
                    	        
                    	        try {
                    	       		set(current, "isNot", true, "not", lastConsumedNode);
                    	        } catch (ValueConverterException vce) {
                    				handleValueConverterException(vce);
                    	        }
                    	    

                    }
                    break;

            }

            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:924:3: (lv_expression_1= ruleAtom )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:927:6: lv_expression_1= ruleAtom
            {
             
            	        currentNode=createCompositeNode(grammarAccess.getOperandAccess().getExpressionAtomParserRuleCall_1_0(), currentNode); 
            	    
            pushFollow(FOLLOW_ruleAtom_in_ruleOperand1976);
            lv_expression_1=ruleAtom();
            _fsp--;


            	        if (current==null) {
            	            current = factory.create(grammarAccess.getOperandRule().getType().getClassifier());
            	            associateNodeWithAstElement(currentNode.getParent(), current);
            	        }
            	        
            	        try {
            	       		set(current, "expression", lv_expression_1, "Atom", currentNode);
            	        } catch (ValueConverterException vce) {
            				handleValueConverterException(vce);
            	        }
            	        currentNode = currentNode.getParent();
            	    

            }


            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleOperand


    // $ANTLR start entryRuleAtom
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:952:1: entryRuleAtom returns [EObject current=null] : iv_ruleAtom= ruleAtom EOF ;
    public final EObject entryRuleAtom() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAtom = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:952:46: (iv_ruleAtom= ruleAtom EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:953:2: iv_ruleAtom= ruleAtom EOF
            {
             currentNode = createCompositeNode(grammarAccess.getAtomRule(), currentNode); 
            pushFollow(FOLLOW_ruleAtom_in_entryRuleAtom2013);
            iv_ruleAtom=ruleAtom();
            _fsp--;

             current =iv_ruleAtom; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleAtom2023); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleAtom


    // $ANTLR start ruleAtom
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:960:1: ruleAtom returns [EObject current=null] : ( (lv_feature_0= RULE_ID ) | ( '(' (lv_expression_2= ruleOrExpression ) ')' ) ) ;
    public final EObject ruleAtom() throws RecognitionException {
        EObject current = null;

        Token lv_feature_0=null;
        EObject lv_expression_2 = null;


         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:965:6: ( ( (lv_feature_0= RULE_ID ) | ( '(' (lv_expression_2= ruleOrExpression ) ')' ) ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:966:1: ( (lv_feature_0= RULE_ID ) | ( '(' (lv_expression_2= ruleOrExpression ) ')' ) )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:966:1: ( (lv_feature_0= RULE_ID ) | ( '(' (lv_expression_2= ruleOrExpression ) ')' ) )
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==RULE_ID) ) {
                alt18=1;
            }
            else if ( (LA18_0==17) ) {
                alt18=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("966:1: ( (lv_feature_0= RULE_ID ) | ( '(' (lv_expression_2= ruleOrExpression ) ')' ) )", 18, 0, input);

                throw nvae;
            }
            switch (alt18) {
                case 1 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:966:2: (lv_feature_0= RULE_ID )
                    {
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:966:2: (lv_feature_0= RULE_ID )
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:968:6: lv_feature_0= RULE_ID
                    {
                    lv_feature_0=(Token)input.LT(1);
                    match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleAtom2070); 

                    		createLeafNode(grammarAccess.getAtomAccess().getFeatureIDTerminalRuleCall_0_0(), "feature"); 
                    	

                    	        if (current==null) {
                    	            current = factory.create(grammarAccess.getAtomRule().getType().getClassifier());
                    	            associateNodeWithAstElement(currentNode, current);
                    	        }
                    	        
                    	        try {
                    	       		set(current, "feature", lv_feature_0, "ID", lastConsumedNode);
                    	        } catch (ValueConverterException vce) {
                    				handleValueConverterException(vce);
                    	        }
                    	    

                    }


                    }
                    break;
                case 2 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:987:6: ( '(' (lv_expression_2= ruleOrExpression ) ')' )
                    {
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:987:6: ( '(' (lv_expression_2= ruleOrExpression ) ')' )
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:987:7: '(' (lv_expression_2= ruleOrExpression ) ')'
                    {
                    match(input,17,FOLLOW_17_in_ruleAtom2094); 

                            createLeafNode(grammarAccess.getAtomAccess().getLeftParenthesisKeyword_1_0(), null); 
                        
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:991:1: (lv_expression_2= ruleOrExpression )
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:994:6: lv_expression_2= ruleOrExpression
                    {
                     
                    	        currentNode=createCompositeNode(grammarAccess.getAtomAccess().getExpressionOrExpressionParserRuleCall_1_1_0(), currentNode); 
                    	    
                    pushFollow(FOLLOW_ruleOrExpression_in_ruleAtom2128);
                    lv_expression_2=ruleOrExpression();
                    _fsp--;


                    	        if (current==null) {
                    	            current = factory.create(grammarAccess.getAtomRule().getType().getClassifier());
                    	            associateNodeWithAstElement(currentNode.getParent(), current);
                    	        }
                    	        
                    	        try {
                    	       		set(current, "expression", lv_expression_2, "OrExpression", currentNode);
                    	        } catch (ValueConverterException vce) {
                    				handleValueConverterException(vce);
                    	        }
                    	        currentNode = currentNode.getParent();
                    	    

                    }

                    match(input,19,FOLLOW_19_in_ruleAtom2141); 

                            createLeafNode(grammarAccess.getAtomAccess().getRightParenthesisKeyword_1_2(), null); 
                        

                    }


                    }
                    break;

            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleAtom


    // $ANTLR start entryRuleFeatureModelImport
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1023:1: entryRuleFeatureModelImport returns [EObject current=null] : iv_ruleFeatureModelImport= ruleFeatureModelImport EOF ;
    public final EObject entryRuleFeatureModelImport() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFeatureModelImport = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1023:60: (iv_ruleFeatureModelImport= ruleFeatureModelImport EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1024:2: iv_ruleFeatureModelImport= ruleFeatureModelImport EOF
            {
             currentNode = createCompositeNode(grammarAccess.getFeatureModelImportRule(), currentNode); 
            pushFollow(FOLLOW_ruleFeatureModelImport_in_entryRuleFeatureModelImport2175);
            iv_ruleFeatureModelImport=ruleFeatureModelImport();
            _fsp--;

             current =iv_ruleFeatureModelImport; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeatureModelImport2185); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleFeatureModelImport


    // $ANTLR start ruleFeatureModelImport
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1031:1: ruleFeatureModelImport returns [EObject current=null] : ( 'featuremodel' (lv_importURI_1= RULE_STRING ) ) ;
    public final EObject ruleFeatureModelImport() throws RecognitionException {
        EObject current = null;

        Token lv_importURI_1=null;

         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1036:6: ( ( 'featuremodel' (lv_importURI_1= RULE_STRING ) ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1037:1: ( 'featuremodel' (lv_importURI_1= RULE_STRING ) )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1037:1: ( 'featuremodel' (lv_importURI_1= RULE_STRING ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1037:2: 'featuremodel' (lv_importURI_1= RULE_STRING )
            {
            match(input,26,FOLLOW_26_in_ruleFeatureModelImport2219); 

                    createLeafNode(grammarAccess.getFeatureModelImportAccess().getFeaturemodelKeyword_0(), null); 
                
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1041:1: (lv_importURI_1= RULE_STRING )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1043:6: lv_importURI_1= RULE_STRING
            {
            lv_importURI_1=(Token)input.LT(1);
            match(input,RULE_STRING,FOLLOW_RULE_STRING_in_ruleFeatureModelImport2241); 

            		createLeafNode(grammarAccess.getFeatureModelImportAccess().getImportURISTRINGTerminalRuleCall_1_0(), "importURI"); 
            	

            	        if (current==null) {
            	            current = factory.create(grammarAccess.getFeatureModelImportRule().getType().getClassifier());
            	            associateNodeWithAstElement(currentNode, current);
            	        }
            	        
            	        try {
            	       		set(current, "importURI", lv_importURI_1, "STRING", lastConsumedNode);
            	        } catch (ValueConverterException vce) {
            				handleValueConverterException(vce);
            	        }
            	    

            }


            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleFeatureModelImport


    // $ANTLR start entryRuleTagsClause
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1068:1: entryRuleTagsClause returns [EObject current=null] : iv_ruleTagsClause= ruleTagsClause EOF ;
    public final EObject entryRuleTagsClause() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTagsClause = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1068:52: (iv_ruleTagsClause= ruleTagsClause EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1069:2: iv_ruleTagsClause= ruleTagsClause EOF
            {
             currentNode = createCompositeNode(grammarAccess.getTagsClauseRule(), currentNode); 
            pushFollow(FOLLOW_ruleTagsClause_in_entryRuleTagsClause2282);
            iv_ruleTagsClause=ruleTagsClause();
            _fsp--;

             current =iv_ruleTagsClause; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleTagsClause2292); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleTagsClause


    // $ANTLR start ruleTagsClause
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1076:1: ruleTagsClause returns [EObject current=null] : ( 'tags' '(' (lv_tags_2= ruleTag )* ')' ) ;
    public final EObject ruleTagsClause() throws RecognitionException {
        EObject current = null;

        EObject lv_tags_2 = null;


         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1081:6: ( ( 'tags' '(' (lv_tags_2= ruleTag )* ')' ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1082:1: ( 'tags' '(' (lv_tags_2= ruleTag )* ')' )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1082:1: ( 'tags' '(' (lv_tags_2= ruleTag )* ')' )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1082:2: 'tags' '(' (lv_tags_2= ruleTag )* ')'
            {
            match(input,27,FOLLOW_27_in_ruleTagsClause2326); 

                    createLeafNode(grammarAccess.getTagsClauseAccess().getTagsKeyword_0(), null); 
                
            match(input,17,FOLLOW_17_in_ruleTagsClause2335); 

                    createLeafNode(grammarAccess.getTagsClauseAccess().getLeftParenthesisKeyword_1(), null); 
                
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1090:1: (lv_tags_2= ruleTag )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==RULE_ID) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1093:6: lv_tags_2= ruleTag
            	    {
            	     
            	    	        currentNode=createCompositeNode(grammarAccess.getTagsClauseAccess().getTagsTagParserRuleCall_2_0(), currentNode); 
            	    	    
            	    pushFollow(FOLLOW_ruleTag_in_ruleTagsClause2369);
            	    lv_tags_2=ruleTag();
            	    _fsp--;


            	    	        if (current==null) {
            	    	            current = factory.create(grammarAccess.getTagsClauseRule().getType().getClassifier());
            	    	            associateNodeWithAstElement(currentNode.getParent(), current);
            	    	        }
            	    	        
            	    	        try {
            	    	       		add(current, "tags", lv_tags_2, "Tag", currentNode);
            	    	        } catch (ValueConverterException vce) {
            	    				handleValueConverterException(vce);
            	    	        }
            	    	        currentNode = currentNode.getParent();
            	    	    

            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

            match(input,19,FOLLOW_19_in_ruleTagsClause2383); 

                    createLeafNode(grammarAccess.getTagsClauseAccess().getRightParenthesisKeyword_3(), null); 
                

            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleTagsClause


    // $ANTLR start entryRuleTag
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1122:1: entryRuleTag returns [EObject current=null] : iv_ruleTag= ruleTag EOF ;
    public final EObject entryRuleTag() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTag = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1122:45: (iv_ruleTag= ruleTag EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1123:2: iv_ruleTag= ruleTag EOF
            {
             currentNode = createCompositeNode(grammarAccess.getTagRule(), currentNode); 
            pushFollow(FOLLOW_ruleTag_in_entryRuleTag2416);
            iv_ruleTag=ruleTag();
            _fsp--;

             current =iv_ruleTag; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleTag2426); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleTag


    // $ANTLR start ruleTag
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1130:1: ruleTag returns [EObject current=null] : (lv_name_0= RULE_ID ) ;
    public final EObject ruleTag() throws RecognitionException {
        EObject current = null;

        Token lv_name_0=null;

         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1135:6: ( (lv_name_0= RULE_ID ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1136:1: (lv_name_0= RULE_ID )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1136:1: (lv_name_0= RULE_ID )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1138:6: lv_name_0= RULE_ID
            {
            lv_name_0=(Token)input.LT(1);
            match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleTag2472); 

            		createLeafNode(grammarAccess.getTagAccess().getNameIDTerminalRuleCall_0(), "name"); 
            	

            	        if (current==null) {
            	            current = factory.create(grammarAccess.getTagRule().getType().getClassifier());
            	            associateNodeWithAstElement(currentNode, current);
            	        }
            	        
            	        try {
            	       		set(current, "name", lv_name_0, "ID", lastConsumedNode);
            	        } catch (ValueConverterException vce) {
            				handleValueConverterException(vce);
            	        }
            	    

            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleTag


    // $ANTLR start entryRulePointcut
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1163:1: entryRulePointcut returns [EObject current=null] : iv_rulePointcut= rulePointcut EOF ;
    public final EObject entryRulePointcut() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePointcut = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1163:50: (iv_rulePointcut= rulePointcut EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1164:2: iv_rulePointcut= rulePointcut EOF
            {
             currentNode = createCompositeNode(grammarAccess.getPointcutRule(), currentNode); 
            pushFollow(FOLLOW_rulePointcut_in_entryRulePointcut2512);
            iv_rulePointcut=rulePointcut();
            _fsp--;

             current =iv_rulePointcut; 
            match(input,EOF,FOLLOW_EOF_in_entryRulePointcut2522); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRulePointcut


    // $ANTLR start rulePointcut
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1171:1: rulePointcut returns [EObject current=null] : ( 'aspect' '{' (lv_matches_2= ruleMatch )* '}' ) ;
    public final EObject rulePointcut() throws RecognitionException {
        EObject current = null;

        EObject lv_matches_2 = null;


         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1176:6: ( ( 'aspect' '{' (lv_matches_2= ruleMatch )* '}' ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1177:1: ( 'aspect' '{' (lv_matches_2= ruleMatch )* '}' )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1177:1: ( 'aspect' '{' (lv_matches_2= ruleMatch )* '}' )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1177:2: 'aspect' '{' (lv_matches_2= ruleMatch )* '}'
            {
            match(input,28,FOLLOW_28_in_rulePointcut2556); 

                    createLeafNode(grammarAccess.getPointcutAccess().getAspectKeyword_0(), null); 
                
            match(input,12,FOLLOW_12_in_rulePointcut2565); 

                    createLeafNode(grammarAccess.getPointcutAccess().getLeftCurlyBracketKeyword_1(), null); 
                
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1185:1: (lv_matches_2= ruleMatch )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( ((LA20_0>=29 && LA20_0<=30)||LA20_0==34) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1188:6: lv_matches_2= ruleMatch
            	    {
            	     
            	    	        currentNode=createCompositeNode(grammarAccess.getPointcutAccess().getMatchesMatchParserRuleCall_2_0(), currentNode); 
            	    	    
            	    pushFollow(FOLLOW_ruleMatch_in_rulePointcut2599);
            	    lv_matches_2=ruleMatch();
            	    _fsp--;


            	    	        if (current==null) {
            	    	            current = factory.create(grammarAccess.getPointcutRule().getType().getClassifier());
            	    	            associateNodeWithAstElement(currentNode.getParent(), current);
            	    	        }
            	    	        
            	    	        try {
            	    	       		add(current, "matches", lv_matches_2, "Match", currentNode);
            	    	        } catch (ValueConverterException vce) {
            	    				handleValueConverterException(vce);
            	    	        }
            	    	        currentNode = currentNode.getParent();
            	    	    

            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

            match(input,13,FOLLOW_13_in_rulePointcut2613); 

                    createLeafNode(grammarAccess.getPointcutAccess().getRightCurlyBracketKeyword_3(), null); 
                

            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end rulePointcut


    // $ANTLR start entryRuleMatch
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1217:1: entryRuleMatch returns [EObject current=null] : iv_ruleMatch= ruleMatch EOF ;
    public final EObject entryRuleMatch() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMatch = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1217:47: (iv_ruleMatch= ruleMatch EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1218:2: iv_ruleMatch= ruleMatch EOF
            {
             currentNode = createCompositeNode(grammarAccess.getMatchRule(), currentNode); 
            pushFollow(FOLLOW_ruleMatch_in_entryRuleMatch2646);
            iv_ruleMatch=ruleMatch();
            _fsp--;

             current =iv_ruleMatch; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleMatch2656); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleMatch


    // $ANTLR start ruleMatch
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1225:1: ruleMatch returns [EObject current=null] : (this_AllMatch_0= ruleAllMatch | this_ExactNameMatch_1= ruleExactNameMatch | this_StartsWithNameMatch_2= ruleStartsWithNameMatch | this_EndsWithNameMatch_3= ruleEndsWithNameMatch | this_TagMatch_4= ruleTagMatch ) ;
    public final EObject ruleMatch() throws RecognitionException {
        EObject current = null;

        EObject this_AllMatch_0 = null;

        EObject this_ExactNameMatch_1 = null;

        EObject this_StartsWithNameMatch_2 = null;

        EObject this_EndsWithNameMatch_3 = null;

        EObject this_TagMatch_4 = null;


         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1230:6: ( (this_AllMatch_0= ruleAllMatch | this_ExactNameMatch_1= ruleExactNameMatch | this_StartsWithNameMatch_2= ruleStartsWithNameMatch | this_EndsWithNameMatch_3= ruleEndsWithNameMatch | this_TagMatch_4= ruleTagMatch ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1231:1: (this_AllMatch_0= ruleAllMatch | this_ExactNameMatch_1= ruleExactNameMatch | this_StartsWithNameMatch_2= ruleStartsWithNameMatch | this_EndsWithNameMatch_3= ruleEndsWithNameMatch | this_TagMatch_4= ruleTagMatch )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1231:1: (this_AllMatch_0= ruleAllMatch | this_ExactNameMatch_1= ruleExactNameMatch | this_StartsWithNameMatch_2= ruleStartsWithNameMatch | this_EndsWithNameMatch_3= ruleEndsWithNameMatch | this_TagMatch_4= ruleTagMatch )
            int alt21=5;
            switch ( input.LA(1) ) {
            case 29:
                {
                alt21=1;
                }
                break;
            case 30:
                {
                switch ( input.LA(2) ) {
                case 33:
                    {
                    alt21=4;
                    }
                    break;
                case 31:
                    {
                    alt21=2;
                    }
                    break;
                case 32:
                    {
                    alt21=3;
                    }
                    break;
                default:
                    NoViableAltException nvae =
                        new NoViableAltException("1231:1: (this_AllMatch_0= ruleAllMatch | this_ExactNameMatch_1= ruleExactNameMatch | this_StartsWithNameMatch_2= ruleStartsWithNameMatch | this_EndsWithNameMatch_3= ruleEndsWithNameMatch | this_TagMatch_4= ruleTagMatch )", 21, 2, input);

                    throw nvae;
                }

                }
                break;
            case 34:
                {
                alt21=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("1231:1: (this_AllMatch_0= ruleAllMatch | this_ExactNameMatch_1= ruleExactNameMatch | this_StartsWithNameMatch_2= ruleStartsWithNameMatch | this_EndsWithNameMatch_3= ruleEndsWithNameMatch | this_TagMatch_4= ruleTagMatch )", 21, 0, input);

                throw nvae;
            }

            switch (alt21) {
                case 1 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1232:5: this_AllMatch_0= ruleAllMatch
                    {
                     
                            currentNode=createCompositeNode(grammarAccess.getMatchAccess().getAllMatchParserRuleCall_0(), currentNode); 
                        
                    pushFollow(FOLLOW_ruleAllMatch_in_ruleMatch2703);
                    this_AllMatch_0=ruleAllMatch();
                    _fsp--;

                     
                            current = this_AllMatch_0; 
                            currentNode = currentNode.getParent();
                        

                    }
                    break;
                case 2 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1242:5: this_ExactNameMatch_1= ruleExactNameMatch
                    {
                     
                            currentNode=createCompositeNode(grammarAccess.getMatchAccess().getExactNameMatchParserRuleCall_1(), currentNode); 
                        
                    pushFollow(FOLLOW_ruleExactNameMatch_in_ruleMatch2730);
                    this_ExactNameMatch_1=ruleExactNameMatch();
                    _fsp--;

                     
                            current = this_ExactNameMatch_1; 
                            currentNode = currentNode.getParent();
                        

                    }
                    break;
                case 3 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1252:5: this_StartsWithNameMatch_2= ruleStartsWithNameMatch
                    {
                     
                            currentNode=createCompositeNode(grammarAccess.getMatchAccess().getStartsWithNameMatchParserRuleCall_2(), currentNode); 
                        
                    pushFollow(FOLLOW_ruleStartsWithNameMatch_in_ruleMatch2757);
                    this_StartsWithNameMatch_2=ruleStartsWithNameMatch();
                    _fsp--;

                     
                            current = this_StartsWithNameMatch_2; 
                            currentNode = currentNode.getParent();
                        

                    }
                    break;
                case 4 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1262:5: this_EndsWithNameMatch_3= ruleEndsWithNameMatch
                    {
                     
                            currentNode=createCompositeNode(grammarAccess.getMatchAccess().getEndsWithNameMatchParserRuleCall_3(), currentNode); 
                        
                    pushFollow(FOLLOW_ruleEndsWithNameMatch_in_ruleMatch2784);
                    this_EndsWithNameMatch_3=ruleEndsWithNameMatch();
                    _fsp--;

                     
                            current = this_EndsWithNameMatch_3; 
                            currentNode = currentNode.getParent();
                        

                    }
                    break;
                case 5 :
                    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1272:5: this_TagMatch_4= ruleTagMatch
                    {
                     
                            currentNode=createCompositeNode(grammarAccess.getMatchAccess().getTagMatchParserRuleCall_4(), currentNode); 
                        
                    pushFollow(FOLLOW_ruleTagMatch_in_ruleMatch2811);
                    this_TagMatch_4=ruleTagMatch();
                    _fsp--;

                     
                            current = this_TagMatch_4; 
                            currentNode = currentNode.getParent();
                        

                    }
                    break;

            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleMatch


    // $ANTLR start entryRuleAllMatch
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1287:1: entryRuleAllMatch returns [EObject current=null] : iv_ruleAllMatch= ruleAllMatch EOF ;
    public final EObject entryRuleAllMatch() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAllMatch = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1287:50: (iv_ruleAllMatch= ruleAllMatch EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1288:2: iv_ruleAllMatch= ruleAllMatch EOF
            {
             currentNode = createCompositeNode(grammarAccess.getAllMatchRule(), currentNode); 
            pushFollow(FOLLOW_ruleAllMatch_in_entryRuleAllMatch2843);
            iv_ruleAllMatch=ruleAllMatch();
            _fsp--;

             current =iv_ruleAllMatch; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleAllMatch2853); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleAllMatch


    // $ANTLR start ruleAllMatch
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1295:1: ruleAllMatch returns [EObject current=null] : '*' ;
    public final EObject ruleAllMatch() throws RecognitionException {
        EObject current = null;

         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1300:6: ( '*' )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1301:1: '*'
            {
            match(input,29,FOLLOW_29_in_ruleAllMatch2886); 

                    createLeafNode(grammarAccess.getAllMatchAccess().getAsteriskKeyword(), null); 
                

            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleAllMatch


    // $ANTLR start entryRuleExactNameMatch
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1312:1: entryRuleExactNameMatch returns [EObject current=null] : iv_ruleExactNameMatch= ruleExactNameMatch EOF ;
    public final EObject entryRuleExactNameMatch() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExactNameMatch = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1312:56: (iv_ruleExactNameMatch= ruleExactNameMatch EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1313:2: iv_ruleExactNameMatch= ruleExactNameMatch EOF
            {
             currentNode = createCompositeNode(grammarAccess.getExactNameMatchRule(), currentNode); 
            pushFollow(FOLLOW_ruleExactNameMatch_in_entryRuleExactNameMatch2918);
            iv_ruleExactNameMatch=ruleExactNameMatch();
            _fsp--;

             current =iv_ruleExactNameMatch; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleExactNameMatch2928); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleExactNameMatch


    // $ANTLR start ruleExactNameMatch
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1320:1: ruleExactNameMatch returns [EObject current=null] : ( 'name' '=' (lv_name_2= RULE_ID ) ) ;
    public final EObject ruleExactNameMatch() throws RecognitionException {
        EObject current = null;

        Token lv_name_2=null;

         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1325:6: ( ( 'name' '=' (lv_name_2= RULE_ID ) ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1326:1: ( 'name' '=' (lv_name_2= RULE_ID ) )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1326:1: ( 'name' '=' (lv_name_2= RULE_ID ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1326:2: 'name' '=' (lv_name_2= RULE_ID )
            {
            match(input,30,FOLLOW_30_in_ruleExactNameMatch2962); 

                    createLeafNode(grammarAccess.getExactNameMatchAccess().getNameKeyword_0(), null); 
                
            match(input,31,FOLLOW_31_in_ruleExactNameMatch2971); 

                    createLeafNode(grammarAccess.getExactNameMatchAccess().getEqualsSignKeyword_1(), null); 
                
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1334:1: (lv_name_2= RULE_ID )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1336:6: lv_name_2= RULE_ID
            {
            lv_name_2=(Token)input.LT(1);
            match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleExactNameMatch2993); 

            		createLeafNode(grammarAccess.getExactNameMatchAccess().getNameIDTerminalRuleCall_2_0(), "name"); 
            	

            	        if (current==null) {
            	            current = factory.create(grammarAccess.getExactNameMatchRule().getType().getClassifier());
            	            associateNodeWithAstElement(currentNode, current);
            	        }
            	        
            	        try {
            	       		set(current, "name", lv_name_2, "ID", lastConsumedNode);
            	        } catch (ValueConverterException vce) {
            				handleValueConverterException(vce);
            	        }
            	    

            }


            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleExactNameMatch


    // $ANTLR start entryRuleStartsWithNameMatch
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1361:1: entryRuleStartsWithNameMatch returns [EObject current=null] : iv_ruleStartsWithNameMatch= ruleStartsWithNameMatch EOF ;
    public final EObject entryRuleStartsWithNameMatch() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStartsWithNameMatch = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1361:61: (iv_ruleStartsWithNameMatch= ruleStartsWithNameMatch EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1362:2: iv_ruleStartsWithNameMatch= ruleStartsWithNameMatch EOF
            {
             currentNode = createCompositeNode(grammarAccess.getStartsWithNameMatchRule(), currentNode); 
            pushFollow(FOLLOW_ruleStartsWithNameMatch_in_entryRuleStartsWithNameMatch3034);
            iv_ruleStartsWithNameMatch=ruleStartsWithNameMatch();
            _fsp--;

             current =iv_ruleStartsWithNameMatch; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleStartsWithNameMatch3044); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleStartsWithNameMatch


    // $ANTLR start ruleStartsWithNameMatch
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1369:1: ruleStartsWithNameMatch returns [EObject current=null] : ( 'name' 'startswith' (lv_name_2= RULE_ID ) ) ;
    public final EObject ruleStartsWithNameMatch() throws RecognitionException {
        EObject current = null;

        Token lv_name_2=null;

         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1374:6: ( ( 'name' 'startswith' (lv_name_2= RULE_ID ) ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1375:1: ( 'name' 'startswith' (lv_name_2= RULE_ID ) )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1375:1: ( 'name' 'startswith' (lv_name_2= RULE_ID ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1375:2: 'name' 'startswith' (lv_name_2= RULE_ID )
            {
            match(input,30,FOLLOW_30_in_ruleStartsWithNameMatch3078); 

                    createLeafNode(grammarAccess.getStartsWithNameMatchAccess().getNameKeyword_0(), null); 
                
            match(input,32,FOLLOW_32_in_ruleStartsWithNameMatch3087); 

                    createLeafNode(grammarAccess.getStartsWithNameMatchAccess().getStartswithKeyword_1(), null); 
                
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1383:1: (lv_name_2= RULE_ID )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1385:6: lv_name_2= RULE_ID
            {
            lv_name_2=(Token)input.LT(1);
            match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleStartsWithNameMatch3109); 

            		createLeafNode(grammarAccess.getStartsWithNameMatchAccess().getNameIDTerminalRuleCall_2_0(), "name"); 
            	

            	        if (current==null) {
            	            current = factory.create(grammarAccess.getStartsWithNameMatchRule().getType().getClassifier());
            	            associateNodeWithAstElement(currentNode, current);
            	        }
            	        
            	        try {
            	       		set(current, "name", lv_name_2, "ID", lastConsumedNode);
            	        } catch (ValueConverterException vce) {
            				handleValueConverterException(vce);
            	        }
            	    

            }


            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleStartsWithNameMatch


    // $ANTLR start entryRuleEndsWithNameMatch
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1410:1: entryRuleEndsWithNameMatch returns [EObject current=null] : iv_ruleEndsWithNameMatch= ruleEndsWithNameMatch EOF ;
    public final EObject entryRuleEndsWithNameMatch() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEndsWithNameMatch = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1410:59: (iv_ruleEndsWithNameMatch= ruleEndsWithNameMatch EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1411:2: iv_ruleEndsWithNameMatch= ruleEndsWithNameMatch EOF
            {
             currentNode = createCompositeNode(grammarAccess.getEndsWithNameMatchRule(), currentNode); 
            pushFollow(FOLLOW_ruleEndsWithNameMatch_in_entryRuleEndsWithNameMatch3150);
            iv_ruleEndsWithNameMatch=ruleEndsWithNameMatch();
            _fsp--;

             current =iv_ruleEndsWithNameMatch; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleEndsWithNameMatch3160); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleEndsWithNameMatch


    // $ANTLR start ruleEndsWithNameMatch
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1418:1: ruleEndsWithNameMatch returns [EObject current=null] : ( 'name' 'endswith' (lv_name_2= RULE_ID ) ) ;
    public final EObject ruleEndsWithNameMatch() throws RecognitionException {
        EObject current = null;

        Token lv_name_2=null;

         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1423:6: ( ( 'name' 'endswith' (lv_name_2= RULE_ID ) ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1424:1: ( 'name' 'endswith' (lv_name_2= RULE_ID ) )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1424:1: ( 'name' 'endswith' (lv_name_2= RULE_ID ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1424:2: 'name' 'endswith' (lv_name_2= RULE_ID )
            {
            match(input,30,FOLLOW_30_in_ruleEndsWithNameMatch3194); 

                    createLeafNode(grammarAccess.getEndsWithNameMatchAccess().getNameKeyword_0(), null); 
                
            match(input,33,FOLLOW_33_in_ruleEndsWithNameMatch3203); 

                    createLeafNode(grammarAccess.getEndsWithNameMatchAccess().getEndswithKeyword_1(), null); 
                
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1432:1: (lv_name_2= RULE_ID )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1434:6: lv_name_2= RULE_ID
            {
            lv_name_2=(Token)input.LT(1);
            match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleEndsWithNameMatch3225); 

            		createLeafNode(grammarAccess.getEndsWithNameMatchAccess().getNameIDTerminalRuleCall_2_0(), "name"); 
            	

            	        if (current==null) {
            	            current = factory.create(grammarAccess.getEndsWithNameMatchRule().getType().getClassifier());
            	            associateNodeWithAstElement(currentNode, current);
            	        }
            	        
            	        try {
            	       		set(current, "name", lv_name_2, "ID", lastConsumedNode);
            	        } catch (ValueConverterException vce) {
            				handleValueConverterException(vce);
            	        }
            	    

            }


            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleEndsWithNameMatch


    // $ANTLR start entryRuleTagMatch
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1459:1: entryRuleTagMatch returns [EObject current=null] : iv_ruleTagMatch= ruleTagMatch EOF ;
    public final EObject entryRuleTagMatch() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTagMatch = null;


        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1459:50: (iv_ruleTagMatch= ruleTagMatch EOF )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1460:2: iv_ruleTagMatch= ruleTagMatch EOF
            {
             currentNode = createCompositeNode(grammarAccess.getTagMatchRule(), currentNode); 
            pushFollow(FOLLOW_ruleTagMatch_in_entryRuleTagMatch3266);
            iv_ruleTagMatch=ruleTagMatch();
            _fsp--;

             current =iv_ruleTagMatch; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleTagMatch3276); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end entryRuleTagMatch


    // $ANTLR start ruleTagMatch
    // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1467:1: ruleTagMatch returns [EObject current=null] : ( 'tag' '=' (lv_name_2= RULE_ID ) ) ;
    public final EObject ruleTagMatch() throws RecognitionException {
        EObject current = null;

        Token lv_name_2=null;

         EObject temp=null; setCurrentLookahead(); resetLookahead(); 
            
        try {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1472:6: ( ( 'tag' '=' (lv_name_2= RULE_ID ) ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1473:1: ( 'tag' '=' (lv_name_2= RULE_ID ) )
            {
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1473:1: ( 'tag' '=' (lv_name_2= RULE_ID ) )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1473:2: 'tag' '=' (lv_name_2= RULE_ID )
            {
            match(input,34,FOLLOW_34_in_ruleTagMatch3310); 

                    createLeafNode(grammarAccess.getTagMatchAccess().getTagKeyword_0(), null); 
                
            match(input,31,FOLLOW_31_in_ruleTagMatch3319); 

                    createLeafNode(grammarAccess.getTagMatchAccess().getEqualsSignKeyword_1(), null); 
                
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1481:1: (lv_name_2= RULE_ID )
            // ../org.xtext.example.mydsl/src-gen/org/xtext/example/parser/antlr/internal/InternalMyDsl.g:1483:6: lv_name_2= RULE_ID
            {
            lv_name_2=(Token)input.LT(1);
            match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleTagMatch3341); 

            		createLeafNode(grammarAccess.getTagMatchAccess().getNameIDTerminalRuleCall_2_0(), "name"); 
            	

            	        if (current==null) {
            	            current = factory.create(grammarAccess.getTagMatchRule().getType().getClassifier());
            	            associateNodeWithAstElement(currentNode, current);
            	        }
            	        
            	        try {
            	       		set(current, "name", lv_name_2, "ID", lastConsumedNode);
            	        } catch (ValueConverterException vce) {
            				handleValueConverterException(vce);
            	        }
            	    

            }


            }


            }

             resetLookahead(); 
                	lastConsumedNode = currentNode;
                
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end ruleTagMatch


 

    public static final BitSet FOLLOW_ruleSystem_in_entryRuleSystem73 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleSystem83 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureModelImport_in_ruleSystem142 = new BitSet(new long[]{0x0000000010000802L});
    public static final BitSet FOLLOW_ruleEntity_in_ruleSystem181 = new BitSet(new long[]{0x0000000010000802L});
    public static final BitSet FOLLOW_ruleEntity_in_entryRuleEntity219 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleEntity229 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePointcut_in_ruleEntity288 = new BitSet(new long[]{0x0000000000000800L});
    public static final BitSet FOLLOW_11_in_ruleEntity302 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleEntity324 = new BitSet(new long[]{0x0000000008709000L});
    public static final BitSet FOLLOW_ruleTagsClause_in_ruleEntity366 = new BitSet(new long[]{0x0000000000709000L});
    public static final BitSet FOLLOW_ruleFeatureClause_in_ruleEntity405 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_12_in_ruleEntity419 = new BitSet(new long[]{0x0000000000002010L});
    public static final BitSet FOLLOW_ruleAttribute_in_ruleEntity453 = new BitSet(new long[]{0x0000000000002010L});
    public static final BitSet FOLLOW_13_in_ruleEntity467 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAttribute_in_entryRuleAttribute500 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleAttribute510 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleAttribute557 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_14_in_ruleAttribute574 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleAttribute596 = new BitSet(new long[]{0x0000000000708002L});
    public static final BitSet FOLLOW_ruleFeatureClause_in_ruleAttribute638 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureClause_in_entryRuleFeatureClause676 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeatureClause686 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureAndList_in_ruleFeatureClause733 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureOrList_in_ruleFeatureClause760 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureExpression_in_ruleFeatureClause787 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeature_in_ruleFeatureClause814 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureAndList_in_entryRuleFeatureAndList846 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeatureAndList856 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_15_in_ruleFeatureAndList890 = new BitSet(new long[]{0x0000000000030000L});
    public static final BitSet FOLLOW_16_in_ruleFeatureAndList911 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_ruleFeatureAndList934 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleFeatureAndList956 = new BitSet(new long[]{0x00000000000C0000L});
    public static final BitSet FOLLOW_18_in_ruleFeatureAndList974 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleFeatureAndList996 = new BitSet(new long[]{0x00000000000C0000L});
    public static final BitSet FOLLOW_19_in_ruleFeatureAndList1015 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureOrList_in_entryRuleFeatureOrList1048 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeatureOrList1058 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_20_in_ruleFeatureOrList1092 = new BitSet(new long[]{0x0000000000030000L});
    public static final BitSet FOLLOW_16_in_ruleFeatureOrList1113 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_ruleFeatureOrList1136 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleFeatureOrList1158 = new BitSet(new long[]{0x00000000000C0000L});
    public static final BitSet FOLLOW_18_in_ruleFeatureOrList1176 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleFeatureOrList1198 = new BitSet(new long[]{0x00000000000C0000L});
    public static final BitSet FOLLOW_19_in_ruleFeatureOrList1217 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureExpression_in_entryRuleFeatureExpression1250 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeatureExpression1260 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_21_in_ruleFeatureExpression1294 = new BitSet(new long[]{0x0000000000030000L});
    public static final BitSet FOLLOW_16_in_ruleFeatureExpression1315 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_ruleFeatureExpression1338 = new BitSet(new long[]{0x0000000002020010L});
    public static final BitSet FOLLOW_ruleOrExpression_in_ruleFeatureExpression1372 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_19_in_ruleFeatureExpression1385 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeature_in_entryRuleFeature1418 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeature1428 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_22_in_ruleFeature1462 = new BitSet(new long[]{0x0000000000010010L});
    public static final BitSet FOLLOW_16_in_ruleFeature1483 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleFeature1519 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleOrExpression_in_entryRuleOrExpression1560 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleOrExpression1570 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAndExpression_in_ruleOrExpression1629 = new BitSet(new long[]{0x0000000000800002L});
    public static final BitSet FOLLOW_23_in_ruleOrExpression1643 = new BitSet(new long[]{0x0000000002020010L});
    public static final BitSet FOLLOW_ruleAndExpression_in_ruleOrExpression1677 = new BitSet(new long[]{0x0000000000800002L});
    public static final BitSet FOLLOW_ruleAndExpression_in_entryRuleAndExpression1716 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleAndExpression1726 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleOperand_in_ruleAndExpression1785 = new BitSet(new long[]{0x0000000001000002L});
    public static final BitSet FOLLOW_24_in_ruleAndExpression1799 = new BitSet(new long[]{0x0000000002020010L});
    public static final BitSet FOLLOW_ruleOperand_in_ruleAndExpression1833 = new BitSet(new long[]{0x0000000001000002L});
    public static final BitSet FOLLOW_ruleOperand_in_entryRuleOperand1872 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleOperand1882 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_25_in_ruleOperand1928 = new BitSet(new long[]{0x0000000000020010L});
    public static final BitSet FOLLOW_ruleAtom_in_ruleOperand1976 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAtom_in_entryRuleAtom2013 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleAtom2023 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleAtom2070 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_17_in_ruleAtom2094 = new BitSet(new long[]{0x0000000002020010L});
    public static final BitSet FOLLOW_ruleOrExpression_in_ruleAtom2128 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_19_in_ruleAtom2141 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureModelImport_in_entryRuleFeatureModelImport2175 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeatureModelImport2185 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_26_in_ruleFeatureModelImport2219 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_RULE_STRING_in_ruleFeatureModelImport2241 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleTagsClause_in_entryRuleTagsClause2282 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleTagsClause2292 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_27_in_ruleTagsClause2326 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_ruleTagsClause2335 = new BitSet(new long[]{0x0000000000080010L});
    public static final BitSet FOLLOW_ruleTag_in_ruleTagsClause2369 = new BitSet(new long[]{0x0000000000080010L});
    public static final BitSet FOLLOW_19_in_ruleTagsClause2383 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleTag_in_entryRuleTag2416 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleTag2426 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleTag2472 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePointcut_in_entryRulePointcut2512 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRulePointcut2522 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_28_in_rulePointcut2556 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_12_in_rulePointcut2565 = new BitSet(new long[]{0x0000000460002000L});
    public static final BitSet FOLLOW_ruleMatch_in_rulePointcut2599 = new BitSet(new long[]{0x0000000460002000L});
    public static final BitSet FOLLOW_13_in_rulePointcut2613 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleMatch_in_entryRuleMatch2646 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleMatch2656 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAllMatch_in_ruleMatch2703 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExactNameMatch_in_ruleMatch2730 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleStartsWithNameMatch_in_ruleMatch2757 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEndsWithNameMatch_in_ruleMatch2784 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleTagMatch_in_ruleMatch2811 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAllMatch_in_entryRuleAllMatch2843 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleAllMatch2853 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_29_in_ruleAllMatch2886 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExactNameMatch_in_entryRuleExactNameMatch2918 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleExactNameMatch2928 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_30_in_ruleExactNameMatch2962 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_31_in_ruleExactNameMatch2971 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleExactNameMatch2993 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleStartsWithNameMatch_in_entryRuleStartsWithNameMatch3034 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleStartsWithNameMatch3044 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_30_in_ruleStartsWithNameMatch3078 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_32_in_ruleStartsWithNameMatch3087 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleStartsWithNameMatch3109 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleEndsWithNameMatch_in_entryRuleEndsWithNameMatch3150 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleEndsWithNameMatch3160 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_30_in_ruleEndsWithNameMatch3194 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_33_in_ruleEndsWithNameMatch3203 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleEndsWithNameMatch3225 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleTagMatch_in_entryRuleTagMatch3266 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleTagMatch3276 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_34_in_ruleTagMatch3310 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_31_in_ruleTagMatch3319 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleTagMatch3341 = new BitSet(new long[]{0x0000000000000002L});

}