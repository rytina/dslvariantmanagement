/**
 * <copyright>
 * </copyright>
 *

 */
package org.xtext.example.myDsl;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tags Clause</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.example.myDsl.TagsClause#getTags <em>Tags</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.example.myDsl.MyDslPackage#getTagsClause()
 * @model
 * @generated
 */
public interface TagsClause extends EObject
{
  /**
   * Returns the value of the '<em><b>Tags</b></em>' containment reference list.
   * The list contents are of type {@link org.xtext.example.myDsl.Tag}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Tags</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Tags</em>' containment reference list.
   * @see org.xtext.example.myDsl.MyDslPackage#getTagsClause_Tags()
   * @model containment="true"
   * @generated
   */
  EList<Tag> getTags();

} // TagsClause
