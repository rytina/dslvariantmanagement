/**
 * <copyright>
 * </copyright>
 *

 */
package org.xtext.example.myDsl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.xtext.example.myDsl.MyDslFactory
 * @model kind="package"
 * @generated
 */
public interface MyDslPackage extends EPackage
{
  /**
   * The package name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNAME = "myDsl";

  /**
   * The package namespace URI.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_URI = "http://www.xtext.org/example/MyDsl";

  /**
   * The package namespace name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_PREFIX = "myDsl";

  /**
   * The singleton instance of the package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  MyDslPackage eINSTANCE = org.xtext.example.myDsl.impl.MyDslPackageImpl.init();

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.SystemImpl <em>System</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.SystemImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getSystem()
   * @generated
   */
  int SYSTEM = 0;

  /**
   * The feature id for the '<em><b>Feature Model</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SYSTEM__FEATURE_MODEL = 0;

  /**
   * The feature id for the '<em><b>Entities</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SYSTEM__ENTITIES = 1;

  /**
   * The number of structural features of the '<em>System</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int SYSTEM_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.EntityImpl <em>Entity</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.EntityImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getEntity()
   * @generated
   */
  int ENTITY = 1;

  /**
   * The feature id for the '<em><b>Pointcut</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTITY__POINTCUT = 0;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTITY__NAME = 1;

  /**
   * The feature id for the '<em><b>Tags</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTITY__TAGS = 2;

  /**
   * The feature id for the '<em><b>Feature Clause</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTITY__FEATURE_CLAUSE = 3;

  /**
   * The feature id for the '<em><b>Attributes</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTITY__ATTRIBUTES = 4;

  /**
   * The number of structural features of the '<em>Entity</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENTITY_FEATURE_COUNT = 5;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.AttributeImpl <em>Attribute</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.AttributeImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getAttribute()
   * @generated
   */
  int ATTRIBUTE = 2;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ATTRIBUTE__NAME = 0;

  /**
   * The feature id for the '<em><b>Type</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ATTRIBUTE__TYPE = 1;

  /**
   * The feature id for the '<em><b>Feature Clause</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ATTRIBUTE__FEATURE_CLAUSE = 2;

  /**
   * The number of structural features of the '<em>Attribute</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ATTRIBUTE_FEATURE_COUNT = 3;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.FeatureClauseImpl <em>Feature Clause</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.FeatureClauseImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getFeatureClause()
   * @generated
   */
  int FEATURE_CLAUSE = 3;

  /**
   * The feature id for the '<em><b>Retained</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FEATURE_CLAUSE__RETAINED = 0;

  /**
   * The number of structural features of the '<em>Feature Clause</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FEATURE_CLAUSE_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.FeatureAndListImpl <em>Feature And List</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.FeatureAndListImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getFeatureAndList()
   * @generated
   */
  int FEATURE_AND_LIST = 4;

  /**
   * The feature id for the '<em><b>Retained</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FEATURE_AND_LIST__RETAINED = FEATURE_CLAUSE__RETAINED;

  /**
   * The feature id for the '<em><b>Feature List</b></em>' attribute list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FEATURE_AND_LIST__FEATURE_LIST = FEATURE_CLAUSE_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Feature And List</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FEATURE_AND_LIST_FEATURE_COUNT = FEATURE_CLAUSE_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.FeatureOrListImpl <em>Feature Or List</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.FeatureOrListImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getFeatureOrList()
   * @generated
   */
  int FEATURE_OR_LIST = 5;

  /**
   * The feature id for the '<em><b>Retained</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FEATURE_OR_LIST__RETAINED = FEATURE_CLAUSE__RETAINED;

  /**
   * The feature id for the '<em><b>Feature List</b></em>' attribute list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FEATURE_OR_LIST__FEATURE_LIST = FEATURE_CLAUSE_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Feature Or List</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FEATURE_OR_LIST_FEATURE_COUNT = FEATURE_CLAUSE_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.FeatureExpressionImpl <em>Feature Expression</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.FeatureExpressionImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getFeatureExpression()
   * @generated
   */
  int FEATURE_EXPRESSION = 6;

  /**
   * The feature id for the '<em><b>Retained</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FEATURE_EXPRESSION__RETAINED = FEATURE_CLAUSE__RETAINED;

  /**
   * The feature id for the '<em><b>Expression</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FEATURE_EXPRESSION__EXPRESSION = FEATURE_CLAUSE_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Feature Expression</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FEATURE_EXPRESSION_FEATURE_COUNT = FEATURE_CLAUSE_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.FeatureImpl <em>Feature</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.FeatureImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getFeature()
   * @generated
   */
  int FEATURE = 7;

  /**
   * The feature id for the '<em><b>Retained</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FEATURE__RETAINED = FEATURE_CLAUSE__RETAINED;

  /**
   * The feature id for the '<em><b>Feature</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FEATURE__FEATURE = FEATURE_CLAUSE_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Feature</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FEATURE_FEATURE_COUNT = FEATURE_CLAUSE_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.OrExpressionImpl <em>Or Expression</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.OrExpressionImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getOrExpression()
   * @generated
   */
  int OR_EXPRESSION = 8;

  /**
   * The feature id for the '<em><b>Operands</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OR_EXPRESSION__OPERANDS = 0;

  /**
   * The number of structural features of the '<em>Or Expression</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OR_EXPRESSION_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.AndExpressionImpl <em>And Expression</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.AndExpressionImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getAndExpression()
   * @generated
   */
  int AND_EXPRESSION = 9;

  /**
   * The feature id for the '<em><b>Operands</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AND_EXPRESSION__OPERANDS = 0;

  /**
   * The number of structural features of the '<em>And Expression</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int AND_EXPRESSION_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.OperandImpl <em>Operand</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.OperandImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getOperand()
   * @generated
   */
  int OPERAND = 10;

  /**
   * The feature id for the '<em><b>Is Not</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OPERAND__IS_NOT = 0;

  /**
   * The feature id for the '<em><b>Expression</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OPERAND__EXPRESSION = 1;

  /**
   * The number of structural features of the '<em>Operand</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int OPERAND_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.AtomImpl <em>Atom</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.AtomImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getAtom()
   * @generated
   */
  int ATOM = 11;

  /**
   * The feature id for the '<em><b>Feature</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ATOM__FEATURE = 0;

  /**
   * The feature id for the '<em><b>Expression</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ATOM__EXPRESSION = 1;

  /**
   * The number of structural features of the '<em>Atom</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ATOM_FEATURE_COUNT = 2;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.FeatureModelImportImpl <em>Feature Model Import</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.FeatureModelImportImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getFeatureModelImport()
   * @generated
   */
  int FEATURE_MODEL_IMPORT = 12;

  /**
   * The feature id for the '<em><b>Import URI</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FEATURE_MODEL_IMPORT__IMPORT_URI = 0;

  /**
   * The number of structural features of the '<em>Feature Model Import</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int FEATURE_MODEL_IMPORT_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.TagsClauseImpl <em>Tags Clause</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.TagsClauseImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getTagsClause()
   * @generated
   */
  int TAGS_CLAUSE = 13;

  /**
   * The feature id for the '<em><b>Tags</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TAGS_CLAUSE__TAGS = 0;

  /**
   * The number of structural features of the '<em>Tags Clause</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TAGS_CLAUSE_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.TagImpl <em>Tag</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.TagImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getTag()
   * @generated
   */
  int TAG = 14;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TAG__NAME = 0;

  /**
   * The number of structural features of the '<em>Tag</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TAG_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.PointcutImpl <em>Pointcut</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.PointcutImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getPointcut()
   * @generated
   */
  int POINTCUT = 15;

  /**
   * The feature id for the '<em><b>Matches</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int POINTCUT__MATCHES = 0;

  /**
   * The number of structural features of the '<em>Pointcut</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int POINTCUT_FEATURE_COUNT = 1;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.MatchImpl <em>Match</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.MatchImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getMatch()
   * @generated
   */
  int MATCH = 16;

  /**
   * The number of structural features of the '<em>Match</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int MATCH_FEATURE_COUNT = 0;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.AllMatchImpl <em>All Match</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.AllMatchImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getAllMatch()
   * @generated
   */
  int ALL_MATCH = 17;

  /**
   * The number of structural features of the '<em>All Match</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ALL_MATCH_FEATURE_COUNT = MATCH_FEATURE_COUNT + 0;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.ExactNameMatchImpl <em>Exact Name Match</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.ExactNameMatchImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getExactNameMatch()
   * @generated
   */
  int EXACT_NAME_MATCH = 18;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXACT_NAME_MATCH__NAME = MATCH_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Exact Name Match</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int EXACT_NAME_MATCH_FEATURE_COUNT = MATCH_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.StartsWithNameMatchImpl <em>Starts With Name Match</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.StartsWithNameMatchImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getStartsWithNameMatch()
   * @generated
   */
  int STARTS_WITH_NAME_MATCH = 19;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STARTS_WITH_NAME_MATCH__NAME = MATCH_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Starts With Name Match</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int STARTS_WITH_NAME_MATCH_FEATURE_COUNT = MATCH_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.EndsWithNameMatchImpl <em>Ends With Name Match</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.EndsWithNameMatchImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getEndsWithNameMatch()
   * @generated
   */
  int ENDS_WITH_NAME_MATCH = 20;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENDS_WITH_NAME_MATCH__NAME = MATCH_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Ends With Name Match</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ENDS_WITH_NAME_MATCH_FEATURE_COUNT = MATCH_FEATURE_COUNT + 1;

  /**
   * The meta object id for the '{@link org.xtext.example.myDsl.impl.TagMatchImpl <em>Tag Match</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.xtext.example.myDsl.impl.TagMatchImpl
   * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getTagMatch()
   * @generated
   */
  int TAG_MATCH = 21;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TAG_MATCH__NAME = MATCH_FEATURE_COUNT + 0;

  /**
   * The number of structural features of the '<em>Tag Match</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int TAG_MATCH_FEATURE_COUNT = MATCH_FEATURE_COUNT + 1;


  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.System <em>System</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>System</em>'.
   * @see org.xtext.example.myDsl.System
   * @generated
   */
  EClass getSystem();

  /**
   * Returns the meta object for the containment reference '{@link org.xtext.example.myDsl.System#getFeatureModel <em>Feature Model</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Feature Model</em>'.
   * @see org.xtext.example.myDsl.System#getFeatureModel()
   * @see #getSystem()
   * @generated
   */
  EReference getSystem_FeatureModel();

  /**
   * Returns the meta object for the containment reference list '{@link org.xtext.example.myDsl.System#getEntities <em>Entities</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Entities</em>'.
   * @see org.xtext.example.myDsl.System#getEntities()
   * @see #getSystem()
   * @generated
   */
  EReference getSystem_Entities();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.Entity <em>Entity</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Entity</em>'.
   * @see org.xtext.example.myDsl.Entity
   * @generated
   */
  EClass getEntity();

  /**
   * Returns the meta object for the containment reference '{@link org.xtext.example.myDsl.Entity#getPointcut <em>Pointcut</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Pointcut</em>'.
   * @see org.xtext.example.myDsl.Entity#getPointcut()
   * @see #getEntity()
   * @generated
   */
  EReference getEntity_Pointcut();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.example.myDsl.Entity#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.example.myDsl.Entity#getName()
   * @see #getEntity()
   * @generated
   */
  EAttribute getEntity_Name();

  /**
   * Returns the meta object for the containment reference '{@link org.xtext.example.myDsl.Entity#getTags <em>Tags</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Tags</em>'.
   * @see org.xtext.example.myDsl.Entity#getTags()
   * @see #getEntity()
   * @generated
   */
  EReference getEntity_Tags();

  /**
   * Returns the meta object for the containment reference '{@link org.xtext.example.myDsl.Entity#getFeatureClause <em>Feature Clause</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Feature Clause</em>'.
   * @see org.xtext.example.myDsl.Entity#getFeatureClause()
   * @see #getEntity()
   * @generated
   */
  EReference getEntity_FeatureClause();

  /**
   * Returns the meta object for the containment reference list '{@link org.xtext.example.myDsl.Entity#getAttributes <em>Attributes</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Attributes</em>'.
   * @see org.xtext.example.myDsl.Entity#getAttributes()
   * @see #getEntity()
   * @generated
   */
  EReference getEntity_Attributes();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.Attribute <em>Attribute</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Attribute</em>'.
   * @see org.xtext.example.myDsl.Attribute
   * @generated
   */
  EClass getAttribute();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.example.myDsl.Attribute#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.example.myDsl.Attribute#getName()
   * @see #getAttribute()
   * @generated
   */
  EAttribute getAttribute_Name();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.example.myDsl.Attribute#getType <em>Type</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Type</em>'.
   * @see org.xtext.example.myDsl.Attribute#getType()
   * @see #getAttribute()
   * @generated
   */
  EAttribute getAttribute_Type();

  /**
   * Returns the meta object for the containment reference '{@link org.xtext.example.myDsl.Attribute#getFeatureClause <em>Feature Clause</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Feature Clause</em>'.
   * @see org.xtext.example.myDsl.Attribute#getFeatureClause()
   * @see #getAttribute()
   * @generated
   */
  EReference getAttribute_FeatureClause();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.FeatureClause <em>Feature Clause</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Feature Clause</em>'.
   * @see org.xtext.example.myDsl.FeatureClause
   * @generated
   */
  EClass getFeatureClause();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.example.myDsl.FeatureClause#isRetained <em>Retained</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Retained</em>'.
   * @see org.xtext.example.myDsl.FeatureClause#isRetained()
   * @see #getFeatureClause()
   * @generated
   */
  EAttribute getFeatureClause_Retained();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.FeatureAndList <em>Feature And List</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Feature And List</em>'.
   * @see org.xtext.example.myDsl.FeatureAndList
   * @generated
   */
  EClass getFeatureAndList();

  /**
   * Returns the meta object for the attribute list '{@link org.xtext.example.myDsl.FeatureAndList#getFeatureList <em>Feature List</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute list '<em>Feature List</em>'.
   * @see org.xtext.example.myDsl.FeatureAndList#getFeatureList()
   * @see #getFeatureAndList()
   * @generated
   */
  EAttribute getFeatureAndList_FeatureList();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.FeatureOrList <em>Feature Or List</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Feature Or List</em>'.
   * @see org.xtext.example.myDsl.FeatureOrList
   * @generated
   */
  EClass getFeatureOrList();

  /**
   * Returns the meta object for the attribute list '{@link org.xtext.example.myDsl.FeatureOrList#getFeatureList <em>Feature List</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute list '<em>Feature List</em>'.
   * @see org.xtext.example.myDsl.FeatureOrList#getFeatureList()
   * @see #getFeatureOrList()
   * @generated
   */
  EAttribute getFeatureOrList_FeatureList();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.FeatureExpression <em>Feature Expression</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Feature Expression</em>'.
   * @see org.xtext.example.myDsl.FeatureExpression
   * @generated
   */
  EClass getFeatureExpression();

  /**
   * Returns the meta object for the containment reference '{@link org.xtext.example.myDsl.FeatureExpression#getExpression <em>Expression</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Expression</em>'.
   * @see org.xtext.example.myDsl.FeatureExpression#getExpression()
   * @see #getFeatureExpression()
   * @generated
   */
  EReference getFeatureExpression_Expression();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.Feature <em>Feature</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Feature</em>'.
   * @see org.xtext.example.myDsl.Feature
   * @generated
   */
  EClass getFeature();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.example.myDsl.Feature#getFeature <em>Feature</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Feature</em>'.
   * @see org.xtext.example.myDsl.Feature#getFeature()
   * @see #getFeature()
   * @generated
   */
  EAttribute getFeature_Feature();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.OrExpression <em>Or Expression</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Or Expression</em>'.
   * @see org.xtext.example.myDsl.OrExpression
   * @generated
   */
  EClass getOrExpression();

  /**
   * Returns the meta object for the containment reference list '{@link org.xtext.example.myDsl.OrExpression#getOperands <em>Operands</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Operands</em>'.
   * @see org.xtext.example.myDsl.OrExpression#getOperands()
   * @see #getOrExpression()
   * @generated
   */
  EReference getOrExpression_Operands();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.AndExpression <em>And Expression</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>And Expression</em>'.
   * @see org.xtext.example.myDsl.AndExpression
   * @generated
   */
  EClass getAndExpression();

  /**
   * Returns the meta object for the containment reference list '{@link org.xtext.example.myDsl.AndExpression#getOperands <em>Operands</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Operands</em>'.
   * @see org.xtext.example.myDsl.AndExpression#getOperands()
   * @see #getAndExpression()
   * @generated
   */
  EReference getAndExpression_Operands();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.Operand <em>Operand</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Operand</em>'.
   * @see org.xtext.example.myDsl.Operand
   * @generated
   */
  EClass getOperand();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.example.myDsl.Operand#isIsNot <em>Is Not</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Is Not</em>'.
   * @see org.xtext.example.myDsl.Operand#isIsNot()
   * @see #getOperand()
   * @generated
   */
  EAttribute getOperand_IsNot();

  /**
   * Returns the meta object for the containment reference '{@link org.xtext.example.myDsl.Operand#getExpression <em>Expression</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Expression</em>'.
   * @see org.xtext.example.myDsl.Operand#getExpression()
   * @see #getOperand()
   * @generated
   */
  EReference getOperand_Expression();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.Atom <em>Atom</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Atom</em>'.
   * @see org.xtext.example.myDsl.Atom
   * @generated
   */
  EClass getAtom();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.example.myDsl.Atom#getFeature <em>Feature</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Feature</em>'.
   * @see org.xtext.example.myDsl.Atom#getFeature()
   * @see #getAtom()
   * @generated
   */
  EAttribute getAtom_Feature();

  /**
   * Returns the meta object for the containment reference '{@link org.xtext.example.myDsl.Atom#getExpression <em>Expression</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Expression</em>'.
   * @see org.xtext.example.myDsl.Atom#getExpression()
   * @see #getAtom()
   * @generated
   */
  EReference getAtom_Expression();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.FeatureModelImport <em>Feature Model Import</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Feature Model Import</em>'.
   * @see org.xtext.example.myDsl.FeatureModelImport
   * @generated
   */
  EClass getFeatureModelImport();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.example.myDsl.FeatureModelImport#getImportURI <em>Import URI</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Import URI</em>'.
   * @see org.xtext.example.myDsl.FeatureModelImport#getImportURI()
   * @see #getFeatureModelImport()
   * @generated
   */
  EAttribute getFeatureModelImport_ImportURI();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.TagsClause <em>Tags Clause</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Tags Clause</em>'.
   * @see org.xtext.example.myDsl.TagsClause
   * @generated
   */
  EClass getTagsClause();

  /**
   * Returns the meta object for the containment reference list '{@link org.xtext.example.myDsl.TagsClause#getTags <em>Tags</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Tags</em>'.
   * @see org.xtext.example.myDsl.TagsClause#getTags()
   * @see #getTagsClause()
   * @generated
   */
  EReference getTagsClause_Tags();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.Tag <em>Tag</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Tag</em>'.
   * @see org.xtext.example.myDsl.Tag
   * @generated
   */
  EClass getTag();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.example.myDsl.Tag#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.example.myDsl.Tag#getName()
   * @see #getTag()
   * @generated
   */
  EAttribute getTag_Name();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.Pointcut <em>Pointcut</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Pointcut</em>'.
   * @see org.xtext.example.myDsl.Pointcut
   * @generated
   */
  EClass getPointcut();

  /**
   * Returns the meta object for the containment reference list '{@link org.xtext.example.myDsl.Pointcut#getMatches <em>Matches</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Matches</em>'.
   * @see org.xtext.example.myDsl.Pointcut#getMatches()
   * @see #getPointcut()
   * @generated
   */
  EReference getPointcut_Matches();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.Match <em>Match</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Match</em>'.
   * @see org.xtext.example.myDsl.Match
   * @generated
   */
  EClass getMatch();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.AllMatch <em>All Match</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>All Match</em>'.
   * @see org.xtext.example.myDsl.AllMatch
   * @generated
   */
  EClass getAllMatch();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.ExactNameMatch <em>Exact Name Match</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Exact Name Match</em>'.
   * @see org.xtext.example.myDsl.ExactNameMatch
   * @generated
   */
  EClass getExactNameMatch();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.example.myDsl.ExactNameMatch#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.example.myDsl.ExactNameMatch#getName()
   * @see #getExactNameMatch()
   * @generated
   */
  EAttribute getExactNameMatch_Name();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.StartsWithNameMatch <em>Starts With Name Match</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Starts With Name Match</em>'.
   * @see org.xtext.example.myDsl.StartsWithNameMatch
   * @generated
   */
  EClass getStartsWithNameMatch();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.example.myDsl.StartsWithNameMatch#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.example.myDsl.StartsWithNameMatch#getName()
   * @see #getStartsWithNameMatch()
   * @generated
   */
  EAttribute getStartsWithNameMatch_Name();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.EndsWithNameMatch <em>Ends With Name Match</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Ends With Name Match</em>'.
   * @see org.xtext.example.myDsl.EndsWithNameMatch
   * @generated
   */
  EClass getEndsWithNameMatch();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.example.myDsl.EndsWithNameMatch#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.example.myDsl.EndsWithNameMatch#getName()
   * @see #getEndsWithNameMatch()
   * @generated
   */
  EAttribute getEndsWithNameMatch_Name();

  /**
   * Returns the meta object for class '{@link org.xtext.example.myDsl.TagMatch <em>Tag Match</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Tag Match</em>'.
   * @see org.xtext.example.myDsl.TagMatch
   * @generated
   */
  EClass getTagMatch();

  /**
   * Returns the meta object for the attribute '{@link org.xtext.example.myDsl.TagMatch#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.xtext.example.myDsl.TagMatch#getName()
   * @see #getTagMatch()
   * @generated
   */
  EAttribute getTagMatch_Name();

  /**
   * Returns the factory that creates the instances of the model.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the factory that creates the instances of the model.
   * @generated
   */
  MyDslFactory getMyDslFactory();

  /**
   * <!-- begin-user-doc -->
   * Defines literals for the meta objects that represent
   * <ul>
   *   <li>each class,</li>
   *   <li>each feature of each class,</li>
   *   <li>each enum,</li>
   *   <li>and each data type</li>
   * </ul>
   * <!-- end-user-doc -->
   * @generated
   */
  interface Literals
  {
    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.SystemImpl <em>System</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.SystemImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getSystem()
     * @generated
     */
    EClass SYSTEM = eINSTANCE.getSystem();

    /**
     * The meta object literal for the '<em><b>Feature Model</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference SYSTEM__FEATURE_MODEL = eINSTANCE.getSystem_FeatureModel();

    /**
     * The meta object literal for the '<em><b>Entities</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference SYSTEM__ENTITIES = eINSTANCE.getSystem_Entities();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.EntityImpl <em>Entity</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.EntityImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getEntity()
     * @generated
     */
    EClass ENTITY = eINSTANCE.getEntity();

    /**
     * The meta object literal for the '<em><b>Pointcut</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference ENTITY__POINTCUT = eINSTANCE.getEntity_Pointcut();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ENTITY__NAME = eINSTANCE.getEntity_Name();

    /**
     * The meta object literal for the '<em><b>Tags</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference ENTITY__TAGS = eINSTANCE.getEntity_Tags();

    /**
     * The meta object literal for the '<em><b>Feature Clause</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference ENTITY__FEATURE_CLAUSE = eINSTANCE.getEntity_FeatureClause();

    /**
     * The meta object literal for the '<em><b>Attributes</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference ENTITY__ATTRIBUTES = eINSTANCE.getEntity_Attributes();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.AttributeImpl <em>Attribute</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.AttributeImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getAttribute()
     * @generated
     */
    EClass ATTRIBUTE = eINSTANCE.getAttribute();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ATTRIBUTE__NAME = eINSTANCE.getAttribute_Name();

    /**
     * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ATTRIBUTE__TYPE = eINSTANCE.getAttribute_Type();

    /**
     * The meta object literal for the '<em><b>Feature Clause</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference ATTRIBUTE__FEATURE_CLAUSE = eINSTANCE.getAttribute_FeatureClause();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.FeatureClauseImpl <em>Feature Clause</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.FeatureClauseImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getFeatureClause()
     * @generated
     */
    EClass FEATURE_CLAUSE = eINSTANCE.getFeatureClause();

    /**
     * The meta object literal for the '<em><b>Retained</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute FEATURE_CLAUSE__RETAINED = eINSTANCE.getFeatureClause_Retained();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.FeatureAndListImpl <em>Feature And List</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.FeatureAndListImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getFeatureAndList()
     * @generated
     */
    EClass FEATURE_AND_LIST = eINSTANCE.getFeatureAndList();

    /**
     * The meta object literal for the '<em><b>Feature List</b></em>' attribute list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute FEATURE_AND_LIST__FEATURE_LIST = eINSTANCE.getFeatureAndList_FeatureList();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.FeatureOrListImpl <em>Feature Or List</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.FeatureOrListImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getFeatureOrList()
     * @generated
     */
    EClass FEATURE_OR_LIST = eINSTANCE.getFeatureOrList();

    /**
     * The meta object literal for the '<em><b>Feature List</b></em>' attribute list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute FEATURE_OR_LIST__FEATURE_LIST = eINSTANCE.getFeatureOrList_FeatureList();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.FeatureExpressionImpl <em>Feature Expression</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.FeatureExpressionImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getFeatureExpression()
     * @generated
     */
    EClass FEATURE_EXPRESSION = eINSTANCE.getFeatureExpression();

    /**
     * The meta object literal for the '<em><b>Expression</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference FEATURE_EXPRESSION__EXPRESSION = eINSTANCE.getFeatureExpression_Expression();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.FeatureImpl <em>Feature</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.FeatureImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getFeature()
     * @generated
     */
    EClass FEATURE = eINSTANCE.getFeature();

    /**
     * The meta object literal for the '<em><b>Feature</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute FEATURE__FEATURE = eINSTANCE.getFeature_Feature();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.OrExpressionImpl <em>Or Expression</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.OrExpressionImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getOrExpression()
     * @generated
     */
    EClass OR_EXPRESSION = eINSTANCE.getOrExpression();

    /**
     * The meta object literal for the '<em><b>Operands</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference OR_EXPRESSION__OPERANDS = eINSTANCE.getOrExpression_Operands();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.AndExpressionImpl <em>And Expression</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.AndExpressionImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getAndExpression()
     * @generated
     */
    EClass AND_EXPRESSION = eINSTANCE.getAndExpression();

    /**
     * The meta object literal for the '<em><b>Operands</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference AND_EXPRESSION__OPERANDS = eINSTANCE.getAndExpression_Operands();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.OperandImpl <em>Operand</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.OperandImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getOperand()
     * @generated
     */
    EClass OPERAND = eINSTANCE.getOperand();

    /**
     * The meta object literal for the '<em><b>Is Not</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute OPERAND__IS_NOT = eINSTANCE.getOperand_IsNot();

    /**
     * The meta object literal for the '<em><b>Expression</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference OPERAND__EXPRESSION = eINSTANCE.getOperand_Expression();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.AtomImpl <em>Atom</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.AtomImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getAtom()
     * @generated
     */
    EClass ATOM = eINSTANCE.getAtom();

    /**
     * The meta object literal for the '<em><b>Feature</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ATOM__FEATURE = eINSTANCE.getAtom_Feature();

    /**
     * The meta object literal for the '<em><b>Expression</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference ATOM__EXPRESSION = eINSTANCE.getAtom_Expression();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.FeatureModelImportImpl <em>Feature Model Import</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.FeatureModelImportImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getFeatureModelImport()
     * @generated
     */
    EClass FEATURE_MODEL_IMPORT = eINSTANCE.getFeatureModelImport();

    /**
     * The meta object literal for the '<em><b>Import URI</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute FEATURE_MODEL_IMPORT__IMPORT_URI = eINSTANCE.getFeatureModelImport_ImportURI();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.TagsClauseImpl <em>Tags Clause</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.TagsClauseImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getTagsClause()
     * @generated
     */
    EClass TAGS_CLAUSE = eINSTANCE.getTagsClause();

    /**
     * The meta object literal for the '<em><b>Tags</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference TAGS_CLAUSE__TAGS = eINSTANCE.getTagsClause_Tags();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.TagImpl <em>Tag</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.TagImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getTag()
     * @generated
     */
    EClass TAG = eINSTANCE.getTag();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute TAG__NAME = eINSTANCE.getTag_Name();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.PointcutImpl <em>Pointcut</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.PointcutImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getPointcut()
     * @generated
     */
    EClass POINTCUT = eINSTANCE.getPointcut();

    /**
     * The meta object literal for the '<em><b>Matches</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference POINTCUT__MATCHES = eINSTANCE.getPointcut_Matches();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.MatchImpl <em>Match</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.MatchImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getMatch()
     * @generated
     */
    EClass MATCH = eINSTANCE.getMatch();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.AllMatchImpl <em>All Match</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.AllMatchImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getAllMatch()
     * @generated
     */
    EClass ALL_MATCH = eINSTANCE.getAllMatch();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.ExactNameMatchImpl <em>Exact Name Match</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.ExactNameMatchImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getExactNameMatch()
     * @generated
     */
    EClass EXACT_NAME_MATCH = eINSTANCE.getExactNameMatch();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute EXACT_NAME_MATCH__NAME = eINSTANCE.getExactNameMatch_Name();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.StartsWithNameMatchImpl <em>Starts With Name Match</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.StartsWithNameMatchImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getStartsWithNameMatch()
     * @generated
     */
    EClass STARTS_WITH_NAME_MATCH = eINSTANCE.getStartsWithNameMatch();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute STARTS_WITH_NAME_MATCH__NAME = eINSTANCE.getStartsWithNameMatch_Name();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.EndsWithNameMatchImpl <em>Ends With Name Match</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.EndsWithNameMatchImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getEndsWithNameMatch()
     * @generated
     */
    EClass ENDS_WITH_NAME_MATCH = eINSTANCE.getEndsWithNameMatch();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ENDS_WITH_NAME_MATCH__NAME = eINSTANCE.getEndsWithNameMatch_Name();

    /**
     * The meta object literal for the '{@link org.xtext.example.myDsl.impl.TagMatchImpl <em>Tag Match</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.xtext.example.myDsl.impl.TagMatchImpl
     * @see org.xtext.example.myDsl.impl.MyDslPackageImpl#getTagMatch()
     * @generated
     */
    EClass TAG_MATCH = eINSTANCE.getTagMatch();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute TAG_MATCH__NAME = eINSTANCE.getTagMatch_Name();

  }

} //MyDslPackage
