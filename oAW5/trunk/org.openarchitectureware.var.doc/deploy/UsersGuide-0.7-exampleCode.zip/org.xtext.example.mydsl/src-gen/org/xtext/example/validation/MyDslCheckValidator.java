
package org.xtext.example.validation;

import java.util.ArrayList;
import java.util.List;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.xtext.validation.CheckType;

public class MyDslCheckValidator extends org.eclipse.xtext.check.AbstractCheckValidator {

	public MyDslCheckValidator() {
		configure();
	}
	
	protected void configure() {
		addCheckFile("org::xtext::example::validation::MyDslFastChecks", CheckType.FAST);
		addCheckFile("org::xtext::example::validation::MyDslChecks", CheckType.NORMAL);
		addCheckFile("org::xtext::example::validation::MyDslExpensiveChecks", CheckType.EXPENSIVE);
	}
	
	@Override
	protected List<? extends EPackage> getEPackages() {
	    List<EPackage> result = new ArrayList<EPackage>();
	    result.add(org.xtext.example.myDsl.MyDslPackage.eINSTANCE);
		return result;
	}
	
}
