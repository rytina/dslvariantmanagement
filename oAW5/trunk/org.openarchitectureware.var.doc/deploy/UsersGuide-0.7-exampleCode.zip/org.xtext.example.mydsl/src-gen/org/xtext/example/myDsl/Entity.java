/**
 * <copyright>
 * </copyright>
 *

 */
package org.xtext.example.myDsl;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Entity</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.example.myDsl.Entity#getPointcut <em>Pointcut</em>}</li>
 *   <li>{@link org.xtext.example.myDsl.Entity#getName <em>Name</em>}</li>
 *   <li>{@link org.xtext.example.myDsl.Entity#getTags <em>Tags</em>}</li>
 *   <li>{@link org.xtext.example.myDsl.Entity#getFeatureClause <em>Feature Clause</em>}</li>
 *   <li>{@link org.xtext.example.myDsl.Entity#getAttributes <em>Attributes</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.example.myDsl.MyDslPackage#getEntity()
 * @model
 * @generated
 */
public interface Entity extends EObject
{
  /**
   * Returns the value of the '<em><b>Pointcut</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Pointcut</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Pointcut</em>' containment reference.
   * @see #setPointcut(Pointcut)
   * @see org.xtext.example.myDsl.MyDslPackage#getEntity_Pointcut()
   * @model containment="true"
   * @generated
   */
  Pointcut getPointcut();

  /**
   * Sets the value of the '{@link org.xtext.example.myDsl.Entity#getPointcut <em>Pointcut</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Pointcut</em>' containment reference.
   * @see #getPointcut()
   * @generated
   */
  void setPointcut(Pointcut value);

  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see org.xtext.example.myDsl.MyDslPackage#getEntity_Name()
   * @model
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link org.xtext.example.myDsl.Entity#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

  /**
   * Returns the value of the '<em><b>Tags</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Tags</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Tags</em>' containment reference.
   * @see #setTags(TagsClause)
   * @see org.xtext.example.myDsl.MyDslPackage#getEntity_Tags()
   * @model containment="true"
   * @generated
   */
  TagsClause getTags();

  /**
   * Sets the value of the '{@link org.xtext.example.myDsl.Entity#getTags <em>Tags</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Tags</em>' containment reference.
   * @see #getTags()
   * @generated
   */
  void setTags(TagsClause value);

  /**
   * Returns the value of the '<em><b>Feature Clause</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Feature Clause</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Feature Clause</em>' containment reference.
   * @see #setFeatureClause(FeatureClause)
   * @see org.xtext.example.myDsl.MyDslPackage#getEntity_FeatureClause()
   * @model containment="true"
   * @generated
   */
  FeatureClause getFeatureClause();

  /**
   * Sets the value of the '{@link org.xtext.example.myDsl.Entity#getFeatureClause <em>Feature Clause</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Feature Clause</em>' containment reference.
   * @see #getFeatureClause()
   * @generated
   */
  void setFeatureClause(FeatureClause value);

  /**
   * Returns the value of the '<em><b>Attributes</b></em>' containment reference list.
   * The list contents are of type {@link org.xtext.example.myDsl.Attribute}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Attributes</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Attributes</em>' containment reference list.
   * @see org.xtext.example.myDsl.MyDslPackage#getEntity_Attributes()
   * @model containment="true"
   * @generated
   */
  EList<Attribute> getAttributes();

} // Entity
