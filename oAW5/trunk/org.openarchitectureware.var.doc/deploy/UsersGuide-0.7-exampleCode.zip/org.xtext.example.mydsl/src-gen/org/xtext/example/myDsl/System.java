/**
 * <copyright>
 * </copyright>
 *

 */
package org.xtext.example.myDsl;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>System</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.example.myDsl.System#getFeatureModel <em>Feature Model</em>}</li>
 *   <li>{@link org.xtext.example.myDsl.System#getEntities <em>Entities</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.example.myDsl.MyDslPackage#getSystem()
 * @model
 * @generated
 */
public interface System extends EObject
{
  /**
   * Returns the value of the '<em><b>Feature Model</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Feature Model</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Feature Model</em>' containment reference.
   * @see #setFeatureModel(FeatureModelImport)
   * @see org.xtext.example.myDsl.MyDslPackage#getSystem_FeatureModel()
   * @model containment="true"
   * @generated
   */
  FeatureModelImport getFeatureModel();

  /**
   * Sets the value of the '{@link org.xtext.example.myDsl.System#getFeatureModel <em>Feature Model</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Feature Model</em>' containment reference.
   * @see #getFeatureModel()
   * @generated
   */
  void setFeatureModel(FeatureModelImport value);

  /**
   * Returns the value of the '<em><b>Entities</b></em>' containment reference list.
   * The list contents are of type {@link org.xtext.example.myDsl.Entity}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Entities</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Entities</em>' containment reference list.
   * @see org.xtext.example.myDsl.MyDslPackage#getSystem_Entities()
   * @model containment="true"
   * @generated
   */
  EList<Entity> getEntities();

} // System
