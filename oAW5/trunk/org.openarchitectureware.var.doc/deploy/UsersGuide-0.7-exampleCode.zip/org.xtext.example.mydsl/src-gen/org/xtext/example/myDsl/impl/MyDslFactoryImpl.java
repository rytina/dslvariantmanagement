/**
 * <copyright>
 * </copyright>
 *

 */
package org.xtext.example.myDsl.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import org.xtext.example.myDsl.AllMatch;
import org.xtext.example.myDsl.AndExpression;
import org.xtext.example.myDsl.Atom;
import org.xtext.example.myDsl.Attribute;
import org.xtext.example.myDsl.EndsWithNameMatch;
import org.xtext.example.myDsl.Entity;
import org.xtext.example.myDsl.ExactNameMatch;
import org.xtext.example.myDsl.Feature;
import org.xtext.example.myDsl.FeatureAndList;
import org.xtext.example.myDsl.FeatureClause;
import org.xtext.example.myDsl.FeatureExpression;
import org.xtext.example.myDsl.FeatureModelImport;
import org.xtext.example.myDsl.FeatureOrList;
import org.xtext.example.myDsl.Match;
import org.xtext.example.myDsl.MyDslFactory;
import org.xtext.example.myDsl.MyDslPackage;
import org.xtext.example.myDsl.Operand;
import org.xtext.example.myDsl.OrExpression;
import org.xtext.example.myDsl.Pointcut;
import org.xtext.example.myDsl.StartsWithNameMatch;
import org.xtext.example.myDsl.Tag;
import org.xtext.example.myDsl.TagMatch;
import org.xtext.example.myDsl.TagsClause;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class MyDslFactoryImpl extends EFactoryImpl implements MyDslFactory
{
  /**
   * Creates the default factory implementation.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static MyDslFactory init()
  {
    try
    {
      MyDslFactory theMyDslFactory = (MyDslFactory)EPackage.Registry.INSTANCE.getEFactory("http://www.xtext.org/example/MyDsl"); 
      if (theMyDslFactory != null)
      {
        return theMyDslFactory;
      }
    }
    catch (Exception exception)
    {
      EcorePlugin.INSTANCE.log(exception);
    }
    return new MyDslFactoryImpl();
  }

  /**
   * Creates an instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MyDslFactoryImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public EObject create(EClass eClass)
  {
    switch (eClass.getClassifierID())
    {
      case MyDslPackage.SYSTEM: return createSystem();
      case MyDslPackage.ENTITY: return createEntity();
      case MyDslPackage.ATTRIBUTE: return createAttribute();
      case MyDslPackage.FEATURE_CLAUSE: return createFeatureClause();
      case MyDslPackage.FEATURE_AND_LIST: return createFeatureAndList();
      case MyDslPackage.FEATURE_OR_LIST: return createFeatureOrList();
      case MyDslPackage.FEATURE_EXPRESSION: return createFeatureExpression();
      case MyDslPackage.FEATURE: return createFeature();
      case MyDslPackage.OR_EXPRESSION: return createOrExpression();
      case MyDslPackage.AND_EXPRESSION: return createAndExpression();
      case MyDslPackage.OPERAND: return createOperand();
      case MyDslPackage.ATOM: return createAtom();
      case MyDslPackage.FEATURE_MODEL_IMPORT: return createFeatureModelImport();
      case MyDslPackage.TAGS_CLAUSE: return createTagsClause();
      case MyDslPackage.TAG: return createTag();
      case MyDslPackage.POINTCUT: return createPointcut();
      case MyDslPackage.MATCH: return createMatch();
      case MyDslPackage.ALL_MATCH: return createAllMatch();
      case MyDslPackage.EXACT_NAME_MATCH: return createExactNameMatch();
      case MyDslPackage.STARTS_WITH_NAME_MATCH: return createStartsWithNameMatch();
      case MyDslPackage.ENDS_WITH_NAME_MATCH: return createEndsWithNameMatch();
      case MyDslPackage.TAG_MATCH: return createTagMatch();
      default:
        throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public org.xtext.example.myDsl.System createSystem()
  {
    SystemImpl system = new SystemImpl();
    return system;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Entity createEntity()
  {
    EntityImpl entity = new EntityImpl();
    return entity;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Attribute createAttribute()
  {
    AttributeImpl attribute = new AttributeImpl();
    return attribute;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FeatureClause createFeatureClause()
  {
    FeatureClauseImpl featureClause = new FeatureClauseImpl();
    return featureClause;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FeatureAndList createFeatureAndList()
  {
    FeatureAndListImpl featureAndList = new FeatureAndListImpl();
    return featureAndList;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FeatureOrList createFeatureOrList()
  {
    FeatureOrListImpl featureOrList = new FeatureOrListImpl();
    return featureOrList;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FeatureExpression createFeatureExpression()
  {
    FeatureExpressionImpl featureExpression = new FeatureExpressionImpl();
    return featureExpression;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Feature createFeature()
  {
    FeatureImpl feature = new FeatureImpl();
    return feature;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public OrExpression createOrExpression()
  {
    OrExpressionImpl orExpression = new OrExpressionImpl();
    return orExpression;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AndExpression createAndExpression()
  {
    AndExpressionImpl andExpression = new AndExpressionImpl();
    return andExpression;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Operand createOperand()
  {
    OperandImpl operand = new OperandImpl();
    return operand;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Atom createAtom()
  {
    AtomImpl atom = new AtomImpl();
    return atom;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FeatureModelImport createFeatureModelImport()
  {
    FeatureModelImportImpl featureModelImport = new FeatureModelImportImpl();
    return featureModelImport;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TagsClause createTagsClause()
  {
    TagsClauseImpl tagsClause = new TagsClauseImpl();
    return tagsClause;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Tag createTag()
  {
    TagImpl tag = new TagImpl();
    return tag;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Pointcut createPointcut()
  {
    PointcutImpl pointcut = new PointcutImpl();
    return pointcut;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Match createMatch()
  {
    MatchImpl match = new MatchImpl();
    return match;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AllMatch createAllMatch()
  {
    AllMatchImpl allMatch = new AllMatchImpl();
    return allMatch;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public ExactNameMatch createExactNameMatch()
  {
    ExactNameMatchImpl exactNameMatch = new ExactNameMatchImpl();
    return exactNameMatch;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public StartsWithNameMatch createStartsWithNameMatch()
  {
    StartsWithNameMatchImpl startsWithNameMatch = new StartsWithNameMatchImpl();
    return startsWithNameMatch;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EndsWithNameMatch createEndsWithNameMatch()
  {
    EndsWithNameMatchImpl endsWithNameMatch = new EndsWithNameMatchImpl();
    return endsWithNameMatch;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TagMatch createTagMatch()
  {
    TagMatchImpl tagMatch = new TagMatchImpl();
    return tagMatch;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public MyDslPackage getMyDslPackage()
  {
    return (MyDslPackage)getEPackage();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @deprecated
   * @generated
   */
  @Deprecated
  public static MyDslPackage getPackage()
  {
    return MyDslPackage.eINSTANCE;
  }

} //MyDslFactoryImpl
