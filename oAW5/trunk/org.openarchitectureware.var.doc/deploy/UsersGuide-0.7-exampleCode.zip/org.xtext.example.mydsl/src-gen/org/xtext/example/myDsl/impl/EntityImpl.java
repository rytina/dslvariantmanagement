/**
 * <copyright>
 * </copyright>
 *

 */
package org.xtext.example.myDsl.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.xtext.example.myDsl.Attribute;
import org.xtext.example.myDsl.Entity;
import org.xtext.example.myDsl.FeatureClause;
import org.xtext.example.myDsl.MyDslPackage;
import org.xtext.example.myDsl.Pointcut;
import org.xtext.example.myDsl.TagsClause;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Entity</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.xtext.example.myDsl.impl.EntityImpl#getPointcut <em>Pointcut</em>}</li>
 *   <li>{@link org.xtext.example.myDsl.impl.EntityImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.xtext.example.myDsl.impl.EntityImpl#getTags <em>Tags</em>}</li>
 *   <li>{@link org.xtext.example.myDsl.impl.EntityImpl#getFeatureClause <em>Feature Clause</em>}</li>
 *   <li>{@link org.xtext.example.myDsl.impl.EntityImpl#getAttributes <em>Attributes</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EntityImpl extends MinimalEObjectImpl.Container implements Entity
{
  /**
   * The cached value of the '{@link #getPointcut() <em>Pointcut</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPointcut()
   * @generated
   * @ordered
   */
  protected Pointcut pointcut;

  /**
   * The default value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected static final String NAME_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getName()
   * @generated
   * @ordered
   */
  protected String name = NAME_EDEFAULT;

  /**
   * The cached value of the '{@link #getTags() <em>Tags</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getTags()
   * @generated
   * @ordered
   */
  protected TagsClause tags;

  /**
   * The cached value of the '{@link #getFeatureClause() <em>Feature Clause</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getFeatureClause()
   * @generated
   * @ordered
   */
  protected FeatureClause featureClause;

  /**
   * The cached value of the '{@link #getAttributes() <em>Attributes</em>}' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getAttributes()
   * @generated
   * @ordered
   */
  protected EList<Attribute> attributes;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EntityImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return MyDslPackage.Literals.ENTITY;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Pointcut getPointcut()
  {
    return pointcut;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetPointcut(Pointcut newPointcut, NotificationChain msgs)
  {
    Pointcut oldPointcut = pointcut;
    pointcut = newPointcut;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, MyDslPackage.ENTITY__POINTCUT, oldPointcut, newPointcut);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPointcut(Pointcut newPointcut)
  {
    if (newPointcut != pointcut)
    {
      NotificationChain msgs = null;
      if (pointcut != null)
        msgs = ((InternalEObject)pointcut).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - MyDslPackage.ENTITY__POINTCUT, null, msgs);
      if (newPointcut != null)
        msgs = ((InternalEObject)newPointcut).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - MyDslPackage.ENTITY__POINTCUT, null, msgs);
      msgs = basicSetPointcut(newPointcut, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MyDslPackage.ENTITY__POINTCUT, newPointcut, newPointcut));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getName()
  {
    return name;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setName(String newName)
  {
    String oldName = name;
    name = newName;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MyDslPackage.ENTITY__NAME, oldName, name));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TagsClause getTags()
  {
    return tags;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetTags(TagsClause newTags, NotificationChain msgs)
  {
    TagsClause oldTags = tags;
    tags = newTags;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, MyDslPackage.ENTITY__TAGS, oldTags, newTags);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setTags(TagsClause newTags)
  {
    if (newTags != tags)
    {
      NotificationChain msgs = null;
      if (tags != null)
        msgs = ((InternalEObject)tags).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - MyDslPackage.ENTITY__TAGS, null, msgs);
      if (newTags != null)
        msgs = ((InternalEObject)newTags).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - MyDslPackage.ENTITY__TAGS, null, msgs);
      msgs = basicSetTags(newTags, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MyDslPackage.ENTITY__TAGS, newTags, newTags));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FeatureClause getFeatureClause()
  {
    return featureClause;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetFeatureClause(FeatureClause newFeatureClause, NotificationChain msgs)
  {
    FeatureClause oldFeatureClause = featureClause;
    featureClause = newFeatureClause;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, MyDslPackage.ENTITY__FEATURE_CLAUSE, oldFeatureClause, newFeatureClause);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setFeatureClause(FeatureClause newFeatureClause)
  {
    if (newFeatureClause != featureClause)
    {
      NotificationChain msgs = null;
      if (featureClause != null)
        msgs = ((InternalEObject)featureClause).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - MyDslPackage.ENTITY__FEATURE_CLAUSE, null, msgs);
      if (newFeatureClause != null)
        msgs = ((InternalEObject)newFeatureClause).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - MyDslPackage.ENTITY__FEATURE_CLAUSE, null, msgs);
      msgs = basicSetFeatureClause(newFeatureClause, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, MyDslPackage.ENTITY__FEATURE_CLAUSE, newFeatureClause, newFeatureClause));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList<Attribute> getAttributes()
  {
    if (attributes == null)
    {
      attributes = new EObjectContainmentEList<Attribute>(Attribute.class, this, MyDslPackage.ENTITY__ATTRIBUTES);
    }
    return attributes;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case MyDslPackage.ENTITY__POINTCUT:
        return basicSetPointcut(null, msgs);
      case MyDslPackage.ENTITY__TAGS:
        return basicSetTags(null, msgs);
      case MyDslPackage.ENTITY__FEATURE_CLAUSE:
        return basicSetFeatureClause(null, msgs);
      case MyDslPackage.ENTITY__ATTRIBUTES:
        return ((InternalEList<?>)getAttributes()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case MyDslPackage.ENTITY__POINTCUT:
        return getPointcut();
      case MyDslPackage.ENTITY__NAME:
        return getName();
      case MyDslPackage.ENTITY__TAGS:
        return getTags();
      case MyDslPackage.ENTITY__FEATURE_CLAUSE:
        return getFeatureClause();
      case MyDslPackage.ENTITY__ATTRIBUTES:
        return getAttributes();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @SuppressWarnings("unchecked")
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case MyDslPackage.ENTITY__POINTCUT:
        setPointcut((Pointcut)newValue);
        return;
      case MyDslPackage.ENTITY__NAME:
        setName((String)newValue);
        return;
      case MyDslPackage.ENTITY__TAGS:
        setTags((TagsClause)newValue);
        return;
      case MyDslPackage.ENTITY__FEATURE_CLAUSE:
        setFeatureClause((FeatureClause)newValue);
        return;
      case MyDslPackage.ENTITY__ATTRIBUTES:
        getAttributes().clear();
        getAttributes().addAll((Collection<? extends Attribute>)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case MyDslPackage.ENTITY__POINTCUT:
        setPointcut((Pointcut)null);
        return;
      case MyDslPackage.ENTITY__NAME:
        setName(NAME_EDEFAULT);
        return;
      case MyDslPackage.ENTITY__TAGS:
        setTags((TagsClause)null);
        return;
      case MyDslPackage.ENTITY__FEATURE_CLAUSE:
        setFeatureClause((FeatureClause)null);
        return;
      case MyDslPackage.ENTITY__ATTRIBUTES:
        getAttributes().clear();
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case MyDslPackage.ENTITY__POINTCUT:
        return pointcut != null;
      case MyDslPackage.ENTITY__NAME:
        return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
      case MyDslPackage.ENTITY__TAGS:
        return tags != null;
      case MyDslPackage.ENTITY__FEATURE_CLAUSE:
        return featureClause != null;
      case MyDslPackage.ENTITY__ATTRIBUTES:
        return attributes != null && !attributes.isEmpty();
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (name: ");
    result.append(name);
    result.append(')');
    return result.toString();
  }

} //EntityImpl
