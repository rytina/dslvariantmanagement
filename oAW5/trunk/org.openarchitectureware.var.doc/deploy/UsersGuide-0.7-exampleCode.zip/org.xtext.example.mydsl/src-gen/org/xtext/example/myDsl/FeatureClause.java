/**
 * <copyright>
 * </copyright>
 *

 */
package org.xtext.example.myDsl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Feature Clause</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.example.myDsl.FeatureClause#isRetained <em>Retained</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.example.myDsl.MyDslPackage#getFeatureClause()
 * @model
 * @generated
 */
public interface FeatureClause extends EObject
{
  /**
   * Returns the value of the '<em><b>Retained</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Retained</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Retained</em>' attribute.
   * @see #setRetained(boolean)
   * @see org.xtext.example.myDsl.MyDslPackage#getFeatureClause_Retained()
   * @model
   * @generated
   */
  boolean isRetained();

  /**
   * Sets the value of the '{@link org.xtext.example.myDsl.FeatureClause#isRetained <em>Retained</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Retained</em>' attribute.
   * @see #isRetained()
   * @generated
   */
  void setRetained(boolean value);

} // FeatureClause
