/**
 * <copyright>
 * </copyright>
 *

 */
package org.xtext.example.myDsl;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>All Match</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.example.myDsl.MyDslPackage#getAllMatch()
 * @model
 * @generated
 */
public interface AllMatch extends Match
{
} // AllMatch
